import React, { useState } from 'react';
import { 
  DollarSign, Star, Crown, Gift, TrendingUp, Users, 
  CreditCard, Settings, ChevronRight, Check, X, Sparkles,
  Lock, Unlock, Heart, Zap, Award, Target
} from 'lucide-react';

interface MonetizationPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

const MonetizationPanel: React.FC<MonetizationPanelProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'subscriptions' | 'tips' | 'settings'>('overview');
  const [creatorMode, setCreatorMode] = useState(false);
  const [selectedTier, setSelectedTier] = useState<string | null>(null);

  // Demo data
  const earnings = {
    total: 2847.50,
    pending: 425.00,
    thisMonth: 892.30,
    subscribers: 156,
    tips: 1245.20,
    growth: 23.5
  };

  const subscriptionTiers = [
    {
      id: 'basic',
      name: 'Supporter',
      price: 4.99,
      color: 'from-blue-500 to-blue-600',
      features: ['Early access to posts', 'Supporter badge', 'Monthly Q&A']
    },
    {
      id: 'premium',
      name: 'Premium',
      price: 9.99,
      color: 'from-purple-500 to-purple-600',
      features: ['All Supporter perks', 'Exclusive content', 'Direct messages', 'Behind the scenes']
    },
    {
      id: 'vip',
      name: 'VIP',
      price: 24.99,
      color: 'from-yellow-500 to-orange-500',
      features: ['All Premium perks', '1-on-1 video calls', 'Custom content requests', 'Priority support']
    }
  ];

  const recentTransactions = [
    { id: 1, type: 'subscription', user: 'Sarah M.', amount: 9.99, tier: 'Premium', time: '2h ago' },
    { id: 2, type: 'tip', user: 'John D.', amount: 25.00, message: 'Love your content!', time: '5h ago' },
    { id: 3, type: 'subscription', user: 'Mike R.', amount: 4.99, tier: 'Supporter', time: '1d ago' },
    { id: 4, type: 'tip', user: 'Emma W.', amount: 10.00, message: 'Keep it up!', time: '2d ago' },
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden animate-fadeIn">
        {/* Header */}
        <div className="bg-gradient-to-r from-green-600 to-emerald-600 p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center">
                <DollarSign className="w-8 h-8" />
              </div>
              <div>
                <h2 className="font-bold text-2xl">Monetization</h2>
                <p className="text-green-100">Earn money from your content</p>
              </div>
            </div>
            <button 
              onClick={onClose}
              className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-4 gap-4 mt-6">
            <div className="bg-white/10 rounded-xl p-4">
              <p className="text-green-100 text-sm">Total Earnings</p>
              <p className="text-2xl font-bold">${earnings.total.toFixed(2)}</p>
            </div>
            <div className="bg-white/10 rounded-xl p-4">
              <p className="text-green-100 text-sm">This Month</p>
              <p className="text-2xl font-bold">${earnings.thisMonth.toFixed(2)}</p>
            </div>
            <div className="bg-white/10 rounded-xl p-4">
              <p className="text-green-100 text-sm">Subscribers</p>
              <p className="text-2xl font-bold">{earnings.subscribers}</p>
            </div>
            <div className="bg-white/10 rounded-xl p-4">
              <p className="text-green-100 text-sm">Growth</p>
              <p className="text-2xl font-bold text-green-300">+{earnings.growth}%</p>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-2 mt-6">
            {[
              { id: 'overview', label: 'Overview', icon: TrendingUp },
              { id: 'subscriptions', label: 'Subscriptions', icon: Crown },
              { id: 'tips', label: 'Tips', icon: Gift },
              { id: 'settings', label: 'Settings', icon: Settings }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ${
                  activeTab === tab.id 
                    ? 'bg-white text-green-600' 
                    : 'bg-white/20 text-white hover:bg-white/30'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Creator Mode Toggle */}
              {!creatorMode && (
                <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl p-6 border border-purple-100">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                        <Sparkles className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-bold text-gray-900">Enable Creator Mode</h3>
                        <p className="text-sm text-gray-600">Start earning from your content today</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setCreatorMode(true)}
                      className="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-xl font-semibold hover:opacity-90 transition-opacity"
                    >
                      Get Started
                    </button>
                  </div>
                </div>
              )}

              {/* Recent Activity */}
              <div>
                <h3 className="font-bold text-gray-900 mb-4">Recent Activity</h3>
                <div className="space-y-3">
                  {recentTransactions.map((tx) => (
                    <div key={tx.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          tx.type === 'subscription' ? 'bg-purple-100' : 'bg-green-100'
                        }`}>
                          {tx.type === 'subscription' ? (
                            <Crown className={`w-5 h-5 ${tx.type === 'subscription' ? 'text-purple-600' : 'text-green-600'}`} />
                          ) : (
                            <Gift className="w-5 h-5 text-green-600" />
                          )}
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{tx.user}</p>
                          <p className="text-sm text-gray-500">
                            {tx.type === 'subscription' ? `Subscribed to ${tx.tier}` : tx.message}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-green-600">+${tx.amount.toFixed(2)}</p>
                        <p className="text-xs text-gray-500">{tx.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Earnings Chart Placeholder */}
              <div className="bg-gray-50 rounded-xl p-6">
                <h3 className="font-bold text-gray-900 mb-4">Earnings Overview</h3>
                <div className="h-48 flex items-end justify-between gap-2">
                  {[65, 45, 78, 52, 89, 67, 95].map((height, idx) => (
                    <div key={idx} className="flex-1 flex flex-col items-center gap-2">
                      <div 
                        className="w-full bg-gradient-to-t from-green-500 to-emerald-400 rounded-t-lg transition-all hover:opacity-80"
                        style={{ height: `${height}%` }}
                      />
                      <span className="text-xs text-gray-500">
                        {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][idx]}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'subscriptions' && (
            <div className="space-y-6">
              <div className="grid grid-cols-3 gap-4">
                {subscriptionTiers.map((tier) => (
                  <div 
                    key={tier.id}
                    className={`rounded-2xl overflow-hidden border-2 transition-all cursor-pointer ${
                      selectedTier === tier.id ? 'border-green-500 shadow-lg' : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setSelectedTier(tier.id)}
                  >
                    <div className={`bg-gradient-to-br ${tier.color} p-4 text-white`}>
                      <Crown className="w-8 h-8 mb-2" />
                      <h4 className="font-bold text-xl">{tier.name}</h4>
                      <p className="text-3xl font-bold">${tier.price}<span className="text-sm font-normal">/mo</span></p>
                    </div>
                    <div className="p-4 bg-white">
                      <ul className="space-y-2">
                        {tier.features.map((feature, idx) => (
                          <li key={idx} className="flex items-center gap-2 text-sm text-gray-600">
                            <Check className="w-4 h-4 text-green-500" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-blue-50 rounded-xl p-4 border border-blue-100">
                <div className="flex items-start gap-3">
                  <Zap className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <p className="font-medium text-blue-900">Pro Tip</p>
                    <p className="text-sm text-blue-700">Offer exclusive content to your subscribers to increase retention and attract new supporters.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'tips' && (
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-6 border border-green-100">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-gray-900 text-xl">Tips Received</h3>
                    <p className="text-3xl font-bold text-green-600 mt-2">${earnings.tips.toFixed(2)}</p>
                    <p className="text-sm text-gray-500 mt-1">From 47 supporters</p>
                  </div>
                  <Gift className="w-16 h-16 text-green-300" />
                </div>
              </div>

              <div>
                <h3 className="font-bold text-gray-900 mb-4">Tip Settings</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                    <div className="flex items-center gap-3">
                      <Heart className="w-5 h-5 text-pink-500" />
                      <div>
                        <p className="font-medium text-gray-900">Enable Tips</p>
                        <p className="text-sm text-gray-500">Allow followers to send you tips</p>
                      </div>
                    </div>
                    <button className="w-12 h-6 bg-green-500 rounded-full relative">
                      <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full" />
                    </button>
                  </div>
                  
                  <div className="p-4 bg-gray-50 rounded-xl">
                    <p className="font-medium text-gray-900 mb-3">Suggested Tip Amounts</p>
                    <div className="flex gap-2">
                      {[5, 10, 25, 50, 100].map((amount) => (
                        <button
                          key={amount}
                          className="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm font-medium hover:border-green-500 hover:text-green-600 transition-colors"
                        >
                          ${amount}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="space-y-6">
              <div>
                <h3 className="font-bold text-gray-900 mb-4">Payout Settings</h3>
                <div className="space-y-4">
                  <div className="p-4 bg-gray-50 rounded-xl">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <CreditCard className="w-5 h-5 text-gray-600" />
                        <div>
                          <p className="font-medium text-gray-900">Payment Method</p>
                          <p className="text-sm text-gray-500">Bank Account ending in ****4242</p>
                        </div>
                      </div>
                      <button className="text-blue-600 text-sm font-medium hover:underline">
                        Change
                      </button>
                    </div>
                  </div>

                  <div className="p-4 bg-gray-50 rounded-xl">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-gray-900">Pending Payout</p>
                        <p className="text-2xl font-bold text-green-600">${earnings.pending.toFixed(2)}</p>
                      </div>
                      <button className="px-4 py-2 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition-colors">
                        Request Payout
                      </button>
                    </div>
                  </div>

                  <div className="p-4 bg-gray-50 rounded-xl">
                    <p className="font-medium text-gray-900 mb-3">Payout Schedule</p>
                    <div className="flex gap-2">
                      {['Weekly', 'Bi-weekly', 'Monthly'].map((schedule) => (
                        <button
                          key={schedule}
                          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                            schedule === 'Monthly' 
                              ? 'bg-green-600 text-white' 
                              : 'bg-white border border-gray-200 hover:border-green-500'
                          }`}
                        >
                          {schedule}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-bold text-gray-900 mb-4">Tax Information</h3>
                <div className="p-4 bg-yellow-50 rounded-xl border border-yellow-100">
                  <div className="flex items-start gap-3">
                    <Target className="w-5 h-5 text-yellow-600 mt-0.5" />
                    <div>
                      <p className="font-medium text-yellow-900">Tax Forms Required</p>
                      <p className="text-sm text-yellow-700">Please submit your W-9 form to continue receiving payouts.</p>
                      <button className="mt-2 text-sm font-medium text-yellow-800 hover:underline">
                        Submit Tax Form
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MonetizationPanel;
