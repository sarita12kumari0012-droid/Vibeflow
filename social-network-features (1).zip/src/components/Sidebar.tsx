import React from 'react';
import { currentUser, groups, trendingTopics, suggestedFriends, users } from '../data/socialData';
import { 
  Home, Users, PlayCircle, Store, Calendar, Bookmark, 
  Clock, Flag, Heart, Settings, ChevronDown, UserPlus,
  TrendingUp, Hash, MoreHorizontal, MessageCircle, Bot, DollarSign,
  Sparkles, Crown, Gift, Zap, BarChart3, PieChart, Megaphone,
  Film, Gamepad2, Video, MapPin, Shield
} from 'lucide-react';


interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenAI?: () => void;
  onOpenMonetization?: () => void;
  onOpenAnalytics?: () => void;
  onOpenAdMonetization?: () => void;
}

const LeftSidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, onOpenAI, onOpenMonetization, onOpenAnalytics, onOpenAdMonetization }) => {
  const [showMore, setShowMore] = React.useState(false);

  const mainMenuItems = [
    { id: 'profile', icon: () => (
      <img src={currentUser.avatar} alt="" className="w-7 h-7 rounded-full object-cover" />
    ), label: currentUser.name },
    { id: 'friends', icon: Users, label: 'Friends' },
    { id: 'groups', icon: Users, label: 'Groups' },
    { id: 'marketplace', icon: Store, label: 'Marketplace' },
    { id: 'watch', icon: PlayCircle, label: 'Watch' },
    { id: 'reels', icon: Film, label: 'Reels', badge: 'New' },
    { id: 'events', icon: Calendar, label: 'Events' },
    { id: 'gaming', icon: Gamepad2, label: 'Gaming' }
  ];

  const moreMenuItems = [
    { id: 'memories', icon: Clock, label: 'Memories' },
    { id: 'saved', icon: Bookmark, label: 'Saved' },
    { id: 'pages', icon: Flag, label: 'Pages' },
    { id: 'favorites', icon: Heart, label: 'Favorites' },
    { id: 'live', icon: Video, label: 'Live Video', badge: 'Live' },
    { id: 'nearby', icon: MapPin, label: 'Nearby Friends' },
    { id: 'settings', icon: Settings, label: 'Settings & Privacy' },
    { id: 'admin', icon: Shield, label: 'Admin Panel', badge: 'Admin' }
  ];

  const shortcuts = groups.slice(0, 3);

  return (
    <aside className="w-[280px] h-[calc(100vh-56px)] sticky top-14 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-transparent py-4 pr-2">
      <nav className="space-y-1">
        {mainMenuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center gap-3 px-2 py-2.5 rounded-lg transition-colors ${
              activeTab === item.id 
                ? 'bg-blue-50 text-blue-600' 
                : 'hover:bg-gray-100 text-gray-700'
            }`}
          >
            {typeof item.icon === 'function' ? (
              <item.icon />
            ) : (
              <div className={`w-7 h-7 rounded-full flex items-center justify-center ${
                activeTab === item.id ? 'bg-blue-100' : 'bg-gray-100'
              }`}>
                <item.icon className="w-4 h-4" />
              </div>
            )}
            <span className="font-medium">{item.label}</span>
            {item.badge && (
              <span className={`ml-auto text-xs px-2 py-0.5 rounded-full ${
                item.badge === 'Live' 
                  ? 'bg-red-100 text-red-600' 
                  : 'bg-blue-100 text-blue-600'
              }`}>
                {item.badge}
              </span>
            )}
          </button>
        ))}

        {/* More Items */}
        {showMore && moreMenuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center gap-3 px-2 py-2.5 rounded-lg transition-colors ${
              activeTab === item.id 
                ? 'bg-blue-50 text-blue-600' 
                : 'hover:bg-gray-100 text-gray-700'
            }`}
          >
            <div className={`w-7 h-7 rounded-full flex items-center justify-center ${
              activeTab === item.id ? 'bg-blue-100' : item.id === 'admin' ? 'bg-red-100' : 'bg-gray-100'
            }`}>
              <item.icon className={`w-4 h-4 ${item.id === 'admin' ? 'text-red-600' : ''}`} />
            </div>
            <span className="font-medium">{item.label}</span>
            {item.badge && (
              <span className={`ml-auto text-xs px-2 py-0.5 rounded-full ${
                item.badge === 'Live' ? 'bg-red-100 text-red-600' : 
                item.badge === 'Admin' ? 'bg-red-100 text-red-600' :
                'bg-blue-100 text-blue-600'
              }`}>
                {item.badge}
              </span>
            )}
          </button>
        ))}

        <button 
          onClick={() => setShowMore(!showMore)}
          className="w-full flex items-center gap-3 px-2 py-2.5 rounded-lg hover:bg-gray-100 text-gray-700 transition-colors"
        >
          <div className="w-7 h-7 rounded-full bg-gray-200 flex items-center justify-center">
            <ChevronDown className={`w-4 h-4 transition-transform ${showMore ? 'rotate-180' : ''}`} />
          </div>
          <span className="font-medium">{showMore ? 'See less' : 'See more'}</span>
        </button>
      </nav>

      {/* AI & Creator Tools */}
      <div className="mt-4 pt-4 border-t border-gray-200">
        <h3 className="font-semibold text-gray-500 text-sm px-2 mb-2">Creator Tools</h3>
        <div className="space-y-1">
          <button 
            onClick={onOpenAI}
            className="w-full flex items-center gap-3 px-2 py-2.5 rounded-lg hover:bg-violet-50 text-gray-700 transition-colors group"
          >
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-violet-500 to-purple-500 flex items-center justify-center">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <span className="font-medium group-hover:text-violet-600">AI Assistant</span>
            <span className="ml-auto text-xs bg-violet-100 text-violet-600 px-2 py-0.5 rounded-full">New</span>
          </button>
          <button 
            onClick={onOpenAnalytics}
            className="w-full flex items-center gap-3 px-2 py-2.5 rounded-lg hover:bg-blue-50 text-gray-700 transition-colors group"
          >
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
              <BarChart3 className="w-4 h-4 text-white" />
            </div>
            <span className="font-medium group-hover:text-blue-600">Analytics</span>
            <span className="ml-auto text-xs bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full">Pro</span>
          </button>
          <button 
            onClick={onOpenMonetization}
            className="w-full flex items-center gap-3 px-2 py-2.5 rounded-lg hover:bg-green-50 text-gray-700 transition-colors group"
          >
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center">
              <DollarSign className="w-4 h-4 text-white" />
            </div>
            <span className="font-medium group-hover:text-green-600">Monetization</span>
          </button>
          <button 
            onClick={onOpenAdMonetization}
            className="w-full flex items-center gap-3 px-2 py-2.5 rounded-lg hover:bg-yellow-50 text-gray-700 transition-colors group"
          >
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-yellow-500 to-orange-500 flex items-center justify-center">
              <Megaphone className="w-4 h-4 text-white" />
            </div>
            <span className="font-medium group-hover:text-yellow-600">Ad Revenue</span>
            <span className="ml-auto text-xs bg-yellow-100 text-yellow-600 px-2 py-0.5 rounded-full">Earn</span>
          </button>
          <button className="w-full flex items-center gap-3 px-2 py-2.5 rounded-lg hover:bg-amber-50 text-gray-700 transition-colors group">
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-amber-500 to-yellow-500 flex items-center justify-center">
              <Crown className="w-4 h-4 text-white" />
            </div>
            <span className="font-medium group-hover:text-amber-600">Subscriptions</span>
          </button>
          <button className="w-full flex items-center gap-3 px-2 py-2.5 rounded-lg hover:bg-pink-50 text-gray-700 transition-colors group">
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-pink-500 to-rose-500 flex items-center justify-center">
              <Gift className="w-4 h-4 text-white" />
            </div>
            <span className="font-medium group-hover:text-pink-600">Tips & Gifts</span>
          </button>
        </div>
      </div>

      {/* Shortcuts */}
      <div className="mt-4 pt-4 border-t border-gray-200">
        <div className="flex items-center justify-between px-2 mb-2">
          <h3 className="font-semibold text-gray-500 text-sm">Your shortcuts</h3>
          <button className="text-sm text-blue-500 hover:underline">Edit</button>
        </div>
        <div className="space-y-1">
          {shortcuts.map((group) => (
            <button
              key={group.id}
              className="w-full flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <img 
                src={group.cover}
                alt={group.name}
                className="w-8 h-8 rounded-lg object-cover"
              />
              <span className="font-medium text-gray-700 text-sm truncate">{group.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className="mt-4 pt-4 border-t border-gray-200 px-2">
        <p className="text-xs text-gray-400 leading-relaxed">
          Privacy · Terms · Advertising · Ad Choices · Cookies · More · Socialite © 2025
        </p>
      </div>
    </aside>
  );
};

const RightSidebar: React.FC = () => {
  const onlineFriends = users.filter(u => u.isOnline && u.id !== currentUser.id);

  return (
    <aside className="w-[280px] h-[calc(100vh-56px)] sticky top-14 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-300 scrollbar-track-transparent py-4 pl-2">
      {/* Premium Banner */}
      <div className="mb-4 p-4 bg-gradient-to-r from-violet-600 to-purple-600 rounded-xl text-white">
        <div className="flex items-center gap-2 mb-2">
          <Zap className="w-5 h-5" />
          <span className="font-bold">Go Premium</span>
        </div>
        <p className="text-sm text-white/80 mb-3">Unlock AI tools, analytics & monetization</p>
        <button className="w-full py-2 bg-white text-violet-600 rounded-lg font-semibold text-sm hover:bg-violet-50 transition-colors">
          Upgrade Now
        </button>
      </div>

      {/* Sponsored */}
      <div className="mb-4">
        <h3 className="font-semibold text-gray-500 text-sm px-2 mb-2">Sponsored</h3>
        <div className="space-y-3">
          {[1, 2].map((i) => (
            <a
              key={i}
              href="#"
              className="flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <img 
                src={groups[i].cover}
                alt="Ad"
                className="w-28 h-28 rounded-lg object-cover"
              />
              <div>
                <p className="font-medium text-gray-900 text-sm">Premium Membership</p>
                <p className="text-xs text-gray-500">socialite.com/premium</p>
              </div>
            </a>
          ))}
        </div>
      </div>

      {/* Trending */}
      <div className="mb-4 pt-4 border-t border-gray-200">
        <div className="flex items-center justify-between px-2 mb-2">
          <h3 className="font-semibold text-gray-500 text-sm flex items-center gap-1">
            <TrendingUp className="w-4 h-4" />
            Trending
          </h3>
        </div>
        <div className="space-y-1">
          {trendingTopics.slice(0, 5).map((topic, idx) => (
            <button
              key={idx}
              className="w-full flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-gray-100 transition-colors text-left"
            >
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg flex items-center justify-center">
                <Hash className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="font-medium text-gray-900 text-sm">{topic.tag}</p>
                <p className="text-xs text-gray-500">{topic.posts}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Friend Suggestions */}
      <div className="mb-4 pt-4 border-t border-gray-200">
        <div className="flex items-center justify-between px-2 mb-2">
          <h3 className="font-semibold text-gray-500 text-sm">People you may know</h3>
          <button className="text-sm text-blue-500 hover:underline">See all</button>
        </div>
        <div className="space-y-2">
          {suggestedFriends.map((friend) => (
            <div
              key={friend.id}
              className="flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <img 
                src={friend.avatar}
                alt={friend.name}
                className="w-10 h-10 rounded-full object-cover"
              />
              <div className="flex-1 min-w-0">
                <p className="font-medium text-gray-900 text-sm truncate">{friend.name}</p>
                <p className="text-xs text-gray-500">{friend.mutualFriends} mutual friends</p>
              </div>
              <button className="px-3 py-1.5 bg-blue-500 text-white text-xs font-medium rounded-md hover:bg-blue-600 transition-colors flex items-center gap-1">
                <UserPlus className="w-3 h-3" />
                Add
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Online Friends */}
      <div className="pt-4 border-t border-gray-200">
        <div className="flex items-center justify-between px-2 mb-2">
          <h3 className="font-semibold text-gray-500 text-sm">Contacts</h3>
          <div className="flex items-center gap-2">
            <button className="w-7 h-7 rounded-full hover:bg-gray-100 flex items-center justify-center">
              <MessageCircle className="w-4 h-4 text-gray-500" />
            </button>
            <button className="w-7 h-7 rounded-full hover:bg-gray-100 flex items-center justify-center">
              <MoreHorizontal className="w-4 h-4 text-gray-500" />
            </button>
          </div>
        </div>
        <div className="space-y-1">
          {onlineFriends.map((friend) => (
            <button
              key={friend.id}
              className="w-full flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <div className="relative">
                <img 
                  src={friend.avatar}
                  alt={friend.name}
                  className="w-9 h-9 rounded-full object-cover"
                />
                <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white" />
              </div>
              <span className="font-medium text-gray-700 text-sm">{friend.name}</span>
            </button>
          ))}
        </div>
      </div>
    </aside>
  );
};

export { LeftSidebar, RightSidebar };
