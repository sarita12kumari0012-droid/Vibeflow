import React, { useState, useEffect } from 'react';
import {
  X, DollarSign, TrendingUp, Eye, MousePointer, Settings, Check,
  AlertCircle, CheckCircle, XCircle, Zap, Target, Shield, Globe,
  Play, Image, Layout, Ban, ChevronRight, RefreshCw, Download,
  CreditCard, Clock, BarChart3, PieChart, Users, Award, Sparkles,
  ToggleLeft, ToggleRight, Info, ExternalLink
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart as RechartsPie,
  Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';

interface AdMonetizationProps {
  isOpen: boolean;
  onClose: () => void;
}

interface AdSettings {
  user_id: string;
  ads_enabled: boolean;
  eligible: boolean;
  feed_ads: boolean;
  story_ads: boolean;
  profile_ads: boolean;
  video_ads: boolean;
  banner_ads: boolean;
  native_ads: boolean;
  video_ad_format: boolean;
  allowed_categories: string[];
  blocked_categories: string[];
  cpm_rate: number;
  cpc_rate: number;
  revenue_share: number;
  total_impressions: number;
  total_clicks: number;
  total_earnings: number;
  pending_earnings: number;
  paid_earnings: number;
}

interface EligibilityResult {
  eligible: boolean;
  requirements: {
    minFollowers: number;
    minWatchHours: number;
    minPosts: number;
    accountAge: number;
  };
  userStats: {
    followers: number;
    watchHours: number;
    posts: number;
    accountAgeDays: number;
    hasViolations: boolean;
  };
  message: string;
}

const ALL_CATEGORIES = [
  { id: 'technology', name: 'Technology', icon: '💻' },
  { id: 'lifestyle', name: 'Lifestyle', icon: '🌟' },
  { id: 'entertainment', name: 'Entertainment', icon: '🎬' },
  { id: 'fashion', name: 'Fashion', icon: '👗' },
  { id: 'food', name: 'Food & Dining', icon: '🍕' },
  { id: 'travel', name: 'Travel', icon: '✈️' },
  { id: 'gaming', name: 'Gaming', icon: '🎮' },
  { id: 'sports', name: 'Sports', icon: '⚽' },
  { id: 'education', name: 'Education', icon: '📚' },
  { id: 'finance', name: 'Finance', icon: '💰' },
  { id: 'health', name: 'Health & Wellness', icon: '💪' },
  { id: 'automotive', name: 'Automotive', icon: '🚗' },
  { id: 'beauty', name: 'Beauty', icon: '💄' },
  { id: 'pets', name: 'Pets', icon: '🐕' },
];

const AdMonetization: React.FC<AdMonetizationProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'eligibility' | 'settings' | 'analytics' | 'payouts'>('overview');
  const [settings, setSettings] = useState<AdSettings | null>(null);
  const [eligibility, setEligibility] = useState<EligibilityResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [checking, setChecking] = useState(false);
  const [saving, setSaving] = useState(false);
  const [analytics, setAnalytics] = useState<any>(null);
  const [payouts, setPayouts] = useState<any[]>([]);
  const [analyticsRange, setAnalyticsRange] = useState('30d');

  const userId = 'demo_user_123'; // In real app, get from auth context

  useEffect(() => {
    if (isOpen) {
      loadSettings();
      loadAnalytics();
      loadPayouts();
    }
  }, [isOpen]);

  const loadSettings = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('ad-monetization', {
        body: { action: 'get_settings', userId }
      });
      if (data) setSettings(data);
    } catch (error) {
      console.error('Error loading settings:', error);
    }
    setLoading(false);
  };

  const loadAnalytics = async () => {
    try {
      const { data } = await supabase.functions.invoke('ad-monetization', {
        body: { action: 'get_analytics', userId, data: { period: analyticsRange } }
      });
      if (data) setAnalytics(data);
    } catch (error) {
      console.error('Error loading analytics:', error);
    }
  };

  const loadPayouts = async () => {
    try {
      const { data } = await supabase.functions.invoke('ad-monetization', {
        body: { action: 'get_payouts', userId }
      });
      if (data) setPayouts(data);
    } catch (error) {
      console.error('Error loading payouts:', error);
    }
  };

  const checkEligibility = async () => {
    setChecking(true);
    try {
      const { data } = await supabase.functions.invoke('ad-monetization', {
        body: { action: 'check_eligibility', userId, data: {} }
      });
      if (data) {
        setEligibility(data);
        loadSettings(); // Refresh settings after eligibility check
      }
    } catch (error) {
      console.error('Error checking eligibility:', error);
    }
    setChecking(false);
  };

  const toggleAds = async () => {
    setSaving(true);
    try {
      const action = settings?.ads_enabled ? 'disable_ads' : 'enable_ads';
      const { data } = await supabase.functions.invoke('ad-monetization', {
        body: { action, userId }
      });
      if (data?.success) {
        loadSettings();
      } else {
        alert(data?.message || 'Failed to update ads status');
      }
    } catch (error) {
      console.error('Error toggling ads:', error);
    }
    setSaving(false);
  };

  const updateSettings = async (updates: Partial<AdSettings>) => {
    setSaving(true);
    try {
      await supabase.functions.invoke('ad-monetization', {
        body: { action: 'update_settings', userId, data: updates }
      });
      setSettings(prev => prev ? { ...prev, ...updates } : null);
    } catch (error) {
      console.error('Error updating settings:', error);
    }
    setSaving(false);
  };

  const requestPayout = async () => {
    if (!settings || settings.pending_earnings < 100) {
      alert('Minimum payout amount is $100');
      return;
    }
    
    try {
      const { data } = await supabase.functions.invoke('ad-monetization', {
        body: { 
          action: 'request_payout', 
          userId, 
          data: { amount: settings.pending_earnings, payoutMethod: 'bank_transfer' } 
        }
      });
      if (data?.success) {
        alert(data.message);
        loadSettings();
        loadPayouts();
      } else {
        alert(data?.message || 'Failed to request payout');
      }
    } catch (error) {
      console.error('Error requesting payout:', error);
    }
  };

  const toggleCategory = (categoryId: string, isBlocked: boolean) => {
    if (!settings) return;
    
    let newBlocked = [...settings.blocked_categories];
    let newAllowed = [...settings.allowed_categories];
    
    if (isBlocked) {
      // Unblock - add to allowed, remove from blocked
      newBlocked = newBlocked.filter(c => c !== categoryId);
      if (!newAllowed.includes(categoryId)) newAllowed.push(categoryId);
    } else {
      // Block - add to blocked, remove from allowed
      if (!newBlocked.includes(categoryId)) newBlocked.push(categoryId);
      newAllowed = newAllowed.filter(c => c !== categoryId);
    }
    
    updateSettings({ blocked_categories: newBlocked, allowed_categories: newAllowed });
  };

  if (!isOpen) return null;

  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Status Banner */}
      {settings?.eligible ? (
        settings.ads_enabled ? (
          <div className="bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl p-6 text-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center">
                  <CheckCircle className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Ads Are Active</h3>
                  <p className="text-green-100">You're earning from ad impressions on your content</p>
                </div>
              </div>
              <button
                onClick={toggleAds}
                disabled={saving}
                className="px-6 py-3 bg-white/20 hover:bg-white/30 rounded-xl font-semibold transition-colors"
              >
                {saving ? 'Updating...' : 'Disable Ads'}
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl p-6 text-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center">
                  <Zap className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Ready to Monetize!</h3>
                  <p className="text-blue-100">You're eligible! Enable ads to start earning</p>
                </div>
              </div>
              <button
                onClick={toggleAds}
                disabled={saving}
                className="px-6 py-3 bg-white text-blue-600 rounded-xl font-semibold hover:bg-blue-50 transition-colors"
              >
                {saving ? 'Enabling...' : 'Enable Ads'}
              </button>
            </div>
          </div>
        )
      ) : (
        <div className="bg-gradient-to-r from-yellow-500 to-orange-500 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center">
                <AlertCircle className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-xl font-bold">Not Yet Eligible</h3>
                <p className="text-yellow-100">Meet the requirements to start earning from ads</p>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('eligibility')}
              className="px-6 py-3 bg-white text-orange-600 rounded-xl font-semibold hover:bg-orange-50 transition-colors"
            >
              Check Requirements
            </button>
          </div>
        </div>
      )}

      {/* Quick Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Total Earnings</p>
              <p className="text-2xl font-bold text-gray-900">${(settings?.total_earnings || 0).toFixed(2)}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Impressions</p>
              <p className="text-2xl font-bold text-gray-900">{formatNumber(settings?.total_impressions || 0)}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center">
              <Eye className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Clicks</p>
              <p className="text-2xl font-bold text-gray-900">{formatNumber(settings?.total_clicks || 0)}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
              <MousePointer className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Pending</p>
              <p className="text-2xl font-bold text-green-600">${(settings?.pending_earnings || 0).toFixed(2)}</p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-xl flex items-center justify-center">
              <Clock className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Revenue Rates */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Your Revenue Rates</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-blue-50 rounded-xl">
            <div className="flex items-center gap-3 mb-2">
              <Eye className="w-5 h-5 text-blue-600" />
              <span className="font-medium text-gray-900">CPM Rate</span>
            </div>
            <p className="text-2xl font-bold text-blue-600">${settings?.cpm_rate?.toFixed(2) || '2.50'}</p>
            <p className="text-sm text-gray-500 mt-1">Per 1,000 impressions</p>
          </div>
          <div className="p-4 bg-purple-50 rounded-xl">
            <div className="flex items-center gap-3 mb-2">
              <MousePointer className="w-5 h-5 text-purple-600" />
              <span className="font-medium text-gray-900">CPC Rate</span>
            </div>
            <p className="text-2xl font-bold text-purple-600">${settings?.cpc_rate?.toFixed(2) || '0.15'}</p>
            <p className="text-sm text-gray-500 mt-1">Per click</p>
          </div>
          <div className="p-4 bg-green-50 rounded-xl">
            <div className="flex items-center gap-3 mb-2">
              <TrendingUp className="w-5 h-5 text-green-600" />
              <span className="font-medium text-gray-900">Revenue Share</span>
            </div>
            <p className="text-2xl font-bold text-green-600">{settings?.revenue_share || 55}%</p>
            <p className="text-sm text-gray-500 mt-1">Your share of ad revenue</p>
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">How Ad Monetization Works</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[
            { icon: Shield, title: 'Get Eligible', desc: 'Meet follower & content requirements' },
            { icon: Settings, title: 'Configure', desc: 'Choose ad placements & categories' },
            { icon: Eye, title: 'Earn', desc: 'Get paid for impressions & clicks' },
            { icon: CreditCard, title: 'Cash Out', desc: 'Request payout when balance hits $100' }
          ].map((step, idx) => (
            <div key={idx} className="flex items-start gap-3">
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center shadow-sm">
                <step.icon className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="font-medium text-gray-900">{step.title}</p>
                <p className="text-sm text-gray-500">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderEligibility = () => (
    <div className="space-y-6">
      {/* Check Eligibility Button */}
      <div className="bg-gradient-to-r from-indigo-500 to-purple-500 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-bold">Check Your Eligibility</h3>
            <p className="text-indigo-100 mt-1">We'll verify if you meet all requirements for ad monetization</p>
          </div>
          <button
            onClick={checkEligibility}
            disabled={checking}
            className="px-6 py-3 bg-white text-indigo-600 rounded-xl font-semibold hover:bg-indigo-50 transition-colors flex items-center gap-2"
          >
            {checking ? (
              <>
                <RefreshCw className="w-5 h-5 animate-spin" />
                Checking...
              </>
            ) : (
              <>
                <Shield className="w-5 h-5" />
                Check Now
              </>
            )}
          </button>
        </div>
      </div>

      {/* Eligibility Result */}
      {eligibility && (
        <div className={`rounded-xl p-6 ${eligibility.eligible ? 'bg-green-50 border border-green-200' : 'bg-yellow-50 border border-yellow-200'}`}>
          <div className="flex items-start gap-4">
            {eligibility.eligible ? (
              <CheckCircle className="w-8 h-8 text-green-500 flex-shrink-0" />
            ) : (
              <AlertCircle className="w-8 h-8 text-yellow-500 flex-shrink-0" />
            )}
            <div>
              <h4 className={`text-lg font-semibold ${eligibility.eligible ? 'text-green-800' : 'text-yellow-800'}`}>
                {eligibility.message}
              </h4>
              {eligibility.eligible && (
                <button
                  onClick={toggleAds}
                  className="mt-4 px-6 py-2 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition-colors"
                >
                  Enable Ads Now
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Requirements Grid */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Monetization Requirements</h3>
        <div className="space-y-4">
          {[
            {
              label: 'Minimum Followers',
              required: eligibility?.requirements?.minFollowers || 1000,
              current: eligibility?.userStats?.followers || 2500,
              icon: Users
            },
            {
              label: 'Watch Hours (Last 12 months)',
              required: eligibility?.requirements?.minWatchHours || 4000,
              current: eligibility?.userStats?.watchHours || 5200,
              icon: Clock
            },
            {
              label: 'Minimum Posts',
              required: eligibility?.requirements?.minPosts || 10,
              current: eligibility?.userStats?.posts || 45,
              icon: Layout
            },
            {
              label: 'Account Age (Days)',
              required: eligibility?.requirements?.accountAge || 30,
              current: eligibility?.userStats?.accountAgeDays || 180,
              icon: Award
            }
          ].map((req, idx) => {
            const met = req.current >= req.required;
            const progress = Math.min((req.current / req.required) * 100, 100);
            return (
              <div key={idx} className="p-4 bg-gray-50 rounded-xl">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <req.icon className={`w-5 h-5 ${met ? 'text-green-500' : 'text-gray-400'}`} />
                    <span className="font-medium text-gray-900">{req.label}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`font-semibold ${met ? 'text-green-600' : 'text-gray-600'}`}>
                      {formatNumber(req.current)} / {formatNumber(req.required)}
                    </span>
                    {met ? (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    ) : (
                      <XCircle className="w-5 h-5 text-gray-300" />
                    )}
                  </div>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full transition-all ${met ? 'bg-green-500' : 'bg-blue-500'}`}
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            );
          })}

          {/* Content Guidelines */}
          <div className="p-4 bg-gray-50 rounded-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Shield className="w-5 h-5 text-green-500" />
                <span className="font-medium text-gray-900">Content Guidelines Compliance</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-green-600">Compliant</span>
                <CheckCircle className="w-5 h-5 text-green-500" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tips to Qualify */}
      <div className="bg-blue-50 rounded-xl p-6 border border-blue-100">
        <div className="flex items-start gap-3">
          <Sparkles className="w-6 h-6 text-blue-500 flex-shrink-0" />
          <div>
            <h4 className="font-semibold text-blue-900">Tips to Qualify Faster</h4>
            <ul className="mt-2 space-y-2 text-sm text-blue-700">
              <li className="flex items-start gap-2">
                <ChevronRight className="w-4 h-4 mt-0.5 flex-shrink-0" />
                Post consistently - at least 3-4 times per week
              </li>
              <li className="flex items-start gap-2">
                <ChevronRight className="w-4 h-4 mt-0.5 flex-shrink-0" />
                Create engaging video content to boost watch hours
              </li>
              <li className="flex items-start gap-2">
                <ChevronRight className="w-4 h-4 mt-0.5 flex-shrink-0" />
                Engage with your audience to grow followers organically
              </li>
              <li className="flex items-start gap-2">
                <ChevronRight className="w-4 h-4 mt-0.5 flex-shrink-0" />
                Follow community guidelines to maintain compliance
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-6">
      {/* Ad Placements */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Ad Placements</h3>
        <p className="text-sm text-gray-500 mb-4">Choose where ads appear on your content</p>
        <div className="space-y-3">
          {[
            { key: 'feed_ads', label: 'Feed Ads', desc: 'Show ads between posts in your feed', icon: Layout },
            { key: 'story_ads', label: 'Story Ads', desc: 'Show ads between your stories', icon: Play },
            { key: 'video_ads', label: 'Video Ads', desc: 'Show pre-roll and mid-roll ads on videos', icon: Play },
            { key: 'profile_ads', label: 'Profile Ads', desc: 'Show banner ads on your profile page', icon: Users }
          ].map((placement) => (
            <div key={placement.key} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
              <div className="flex items-center gap-3">
                <placement.icon className="w-5 h-5 text-gray-600" />
                <div>
                  <p className="font-medium text-gray-900">{placement.label}</p>
                  <p className="text-sm text-gray-500">{placement.desc}</p>
                </div>
              </div>
              <button
                onClick={() => updateSettings({ [placement.key]: !settings?.[placement.key as keyof AdSettings] })}
                className={`w-12 h-6 rounded-full transition-colors relative ${
                  settings?.[placement.key as keyof AdSettings] ? 'bg-green-500' : 'bg-gray-300'
                }`}
              >
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                  settings?.[placement.key as keyof AdSettings] ? 'right-1' : 'left-1'
                }`} />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Ad Formats */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Ad Formats</h3>
        <p className="text-sm text-gray-500 mb-4">Select which ad formats to display</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { key: 'banner_ads', label: 'Banner Ads', desc: 'Standard display banners', icon: Image },
            { key: 'native_ads', label: 'Native Ads', desc: 'Ads that match your content style', icon: Layout },
            { key: 'video_ad_format', label: 'Video Ads', desc: 'Video advertisements', icon: Play }
          ].map((format) => (
            <div
              key={format.key}
              onClick={() => updateSettings({ [format.key]: !settings?.[format.key as keyof AdSettings] })}
              className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                settings?.[format.key as keyof AdSettings]
                  ? 'border-green-500 bg-green-50'
                  : 'border-gray-200 bg-white hover:border-gray-300'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <format.icon className={`w-6 h-6 ${settings?.[format.key as keyof AdSettings] ? 'text-green-600' : 'text-gray-400'}`} />
                {settings?.[format.key as keyof AdSettings] && (
                  <CheckCircle className="w-5 h-5 text-green-500" />
                )}
              </div>
              <p className="font-medium text-gray-900">{format.label}</p>
              <p className="text-sm text-gray-500">{format.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Ad Categories */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Ad Categories</h3>
        <p className="text-sm text-gray-500 mb-4">Choose which ad categories to show or block</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {ALL_CATEGORIES.map((category) => {
            const isBlocked = settings?.blocked_categories?.includes(category.id);
            return (
              <div
                key={category.id}
                onClick={() => toggleCategory(category.id, isBlocked)}
                className={`p-3 rounded-xl border cursor-pointer transition-all ${
                  isBlocked
                    ? 'border-red-200 bg-red-50'
                    : 'border-green-200 bg-green-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-lg">{category.icon}</span>
                  {isBlocked ? (
                    <Ban className="w-4 h-4 text-red-500" />
                  ) : (
                    <Check className="w-4 h-4 text-green-500" />
                  )}
                </div>
                <p className={`text-sm font-medium mt-1 ${isBlocked ? 'text-red-700' : 'text-green-700'}`}>
                  {category.name}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );

  const renderAnalytics = () => {
    // Sample data for charts
    const dailyData = analytics?.dailyData || [
      { date: 'Dec 1', impressions: 1200, clicks: 45, earnings: 3.20 },
      { date: 'Dec 2', impressions: 1450, clicks: 52, earnings: 3.85 },
      { date: 'Dec 3', impressions: 1680, clicks: 61, earnings: 4.45 },
      { date: 'Dec 4', impressions: 1320, clicks: 48, earnings: 3.50 },
      { date: 'Dec 5', impressions: 1890, clicks: 72, earnings: 5.10 },
      { date: 'Dec 6', impressions: 2100, clicks: 85, earnings: 5.75 },
      { date: 'Dec 7', impressions: 1950, clicks: 78, earnings: 5.30 }
    ];

    const placementData = [
      { name: 'Feed', value: 45, color: '#3b82f6' },
      { name: 'Stories', value: 30, color: '#8b5cf6' },
      { name: 'Videos', value: 20, color: '#ec4899' },
      { name: 'Profile', value: 5, color: '#f59e0b' }
    ];

    return (
      <div className="space-y-6">
        {/* Period Selector */}
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">Ad Performance</h3>
          <select
            value={analyticsRange}
            onChange={(e) => {
              setAnalyticsRange(e.target.value);
              loadAnalytics();
            }}
            className="px-4 py-2 bg-gray-100 border border-gray-200 rounded-lg text-sm"
          >
            <option value="7d">Last 7 days</option>
            <option value="30d">Last 30 days</option>
            <option value="90d">Last 90 days</option>
          </select>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
            <p className="text-sm text-gray-500">Impressions</p>
            <p className="text-2xl font-bold text-gray-900">{formatNumber(analytics?.summary?.totalImpressions || 11590)}</p>
            <p className="text-sm text-green-600 mt-1">+12.5% vs last period</p>
          </div>
          <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
            <p className="text-sm text-gray-500">Clicks</p>
            <p className="text-2xl font-bold text-gray-900">{formatNumber(analytics?.summary?.totalClicks || 441)}</p>
            <p className="text-sm text-green-600 mt-1">+8.3% vs last period</p>
          </div>
          <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
            <p className="text-sm text-gray-500">CTR</p>
            <p className="text-2xl font-bold text-gray-900">{analytics?.summary?.ctr || '3.8'}%</p>
            <p className="text-sm text-green-600 mt-1">+0.5% vs last period</p>
          </div>
          <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
            <p className="text-sm text-gray-500">Earnings</p>
            <p className="text-2xl font-bold text-green-600">${analytics?.summary?.totalEarnings || '31.15'}</p>
            <p className="text-sm text-green-600 mt-1">+15.2% vs last period</p>
          </div>
        </div>

        {/* Earnings Chart */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h4 className="font-semibold text-gray-900 mb-4">Daily Earnings</h4>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={dailyData}>
              <defs>
                <linearGradient id="colorEarnings" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#22c55e" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="date" stroke="#9ca3af" fontSize={12} />
              <YAxis stroke="#9ca3af" fontSize={12} tickFormatter={(v) => `$${v}`} />
              <Tooltip formatter={(value: number) => [`$${value.toFixed(2)}`, 'Earnings']} />
              <Area type="monotone" dataKey="earnings" stroke="#22c55e" strokeWidth={2} fill="url(#colorEarnings)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Performance by Placement */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
            <h4 className="font-semibold text-gray-900 mb-4">Impressions by Placement</h4>
            <ResponsiveContainer width="100%" height={250}>
              <RechartsPie>
                <Pie
                  data={placementData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={2}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}%`}
                >
                  {placementData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </RechartsPie>
            </ResponsiveContainer>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
            <h4 className="font-semibold text-gray-900 mb-4">Impressions & Clicks</h4>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={dailyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" stroke="#9ca3af" fontSize={12} />
                <YAxis stroke="#9ca3af" fontSize={12} />
                <Tooltip />
                <Bar dataKey="impressions" fill="#3b82f6" name="Impressions" radius={[4, 4, 0, 0]} />
                <Bar dataKey="clicks" fill="#8b5cf6" name="Clicks" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    );
  };

  const renderPayouts = () => (
    <div className="space-y-6">
      {/* Payout Summary */}
      <div className="bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-green-100">Available for Payout</p>
            <p className="text-4xl font-bold mt-1">${(settings?.pending_earnings || 0).toFixed(2)}</p>
            <p className="text-green-100 text-sm mt-2">Minimum payout: $100</p>
          </div>
          <button
            onClick={requestPayout}
            disabled={(settings?.pending_earnings || 0) < 100}
            className={`px-6 py-3 rounded-xl font-semibold transition-colors ${
              (settings?.pending_earnings || 0) >= 100
                ? 'bg-white text-green-600 hover:bg-green-50'
                : 'bg-white/30 text-white/70 cursor-not-allowed'
            }`}
          >
            Request Payout
          </button>
        </div>
      </div>

      {/* Earnings Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <p className="text-sm text-gray-500">Total Earned</p>
          <p className="text-2xl font-bold text-gray-900">${(settings?.total_earnings || 0).toFixed(2)}</p>
        </div>
        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <p className="text-sm text-gray-500">Pending</p>
          <p className="text-2xl font-bold text-yellow-600">${(settings?.pending_earnings || 0).toFixed(2)}</p>
        </div>
        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <p className="text-sm text-gray-500">Paid Out</p>
          <p className="text-2xl font-bold text-green-600">${(settings?.paid_earnings || 0).toFixed(2)}</p>
        </div>
      </div>

      {/* Payout History */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Payout History</h3>
        {payouts.length > 0 ? (
          <div className="space-y-3">
            {payouts.map((payout, idx) => (
              <div key={idx} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    payout.status === 'completed' ? 'bg-green-100' :
                    payout.status === 'processing' ? 'bg-blue-100' :
                    payout.status === 'failed' ? 'bg-red-100' : 'bg-yellow-100'
                  }`}>
                    {payout.status === 'completed' ? <CheckCircle className="w-5 h-5 text-green-600" /> :
                     payout.status === 'processing' ? <RefreshCw className="w-5 h-5 text-blue-600" /> :
                     payout.status === 'failed' ? <XCircle className="w-5 h-5 text-red-600" /> :
                     <Clock className="w-5 h-5 text-yellow-600" />}
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">${payout.amount.toFixed(2)}</p>
                    <p className="text-sm text-gray-500">{new Date(payout.requested_at).toLocaleDateString()}</p>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  payout.status === 'completed' ? 'bg-green-100 text-green-700' :
                  payout.status === 'processing' ? 'bg-blue-100 text-blue-700' :
                  payout.status === 'failed' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
                }`}>
                  {payout.status.charAt(0).toUpperCase() + payout.status.slice(1)}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <CreditCard className="w-12 h-12 mx-auto mb-3 text-gray-300" />
            <p>No payout history yet</p>
            <p className="text-sm">Request your first payout when you reach $100</p>
          </div>
        )}
      </div>

      {/* Payout Methods */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Payout Method</h3>
        <div className="p-4 bg-gray-50 rounded-xl flex items-center justify-between">
          <div className="flex items-center gap-3">
            <CreditCard className="w-6 h-6 text-gray-600" />
            <div>
              <p className="font-medium text-gray-900">Bank Transfer</p>
              <p className="text-sm text-gray-500">Account ending in ****4242</p>
            </div>
          </div>
          <button className="text-blue-600 text-sm font-medium hover:underline">
            Change
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
      <div className="bg-gray-50 rounded-2xl shadow-2xl w-full max-w-5xl max-h-[90vh] flex flex-col overflow-hidden animate-fadeIn">
        {/* Header */}
        <div className="bg-gradient-to-r from-yellow-500 to-orange-500 p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center">
                <DollarSign className="w-8 h-8" />
              </div>
              <div>
                <h2 className="font-bold text-2xl">Ad Monetization</h2>
                <p className="text-yellow-100">Earn money from ads on your content</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Tabs */}
          <div className="flex gap-2 mt-6 overflow-x-auto">
            {[
              { id: 'overview', label: 'Overview', icon: BarChart3 },
              { id: 'eligibility', label: 'Eligibility', icon: Shield },
              { id: 'settings', label: 'Settings', icon: Settings },
              { id: 'analytics', label: 'Analytics', icon: TrendingUp },
              { id: 'payouts', label: 'Payouts', icon: CreditCard }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-white text-orange-600'
                    : 'bg-white/20 text-white hover:bg-white/30'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <RefreshCw className="w-8 h-8 text-gray-400 animate-spin" />
            </div>
          ) : (
            <>
              {activeTab === 'overview' && renderOverview()}
              {activeTab === 'eligibility' && renderEligibility()}
              {activeTab === 'settings' && renderSettings()}
              {activeTab === 'analytics' && renderAnalytics()}
              {activeTab === 'payouts' && renderPayouts()}
            </>
          )}
        </div>
      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.2s ease-out;
        }
      `}</style>
    </div>
  );
};

export default AdMonetization;
