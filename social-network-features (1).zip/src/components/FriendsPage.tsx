import React, { useState } from 'react';
import { users, currentUser, suggestedFriends } from '../data/socialData';
import { 
  Search, UserPlus, UserMinus, MoreHorizontal, Check, X,
  Users, Clock, UserCheck, Settings, ChevronRight
} from 'lucide-react';

interface FriendsPageProps {
  onBack: () => void;
}

const FriendsPage: React.FC<FriendsPageProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState('suggestions');
  const [searchQuery, setSearchQuery] = useState('');
  const [friendRequests, setFriendRequests] = useState([
    { ...users[7], mutualFriends: 12, timestamp: '2 days ago' },
    { ...users[9], mutualFriends: 8, timestamp: '1 week ago' },
    { ...users[10], mutualFriends: 15, timestamp: '2 weeks ago' }
  ]);

  const tabs = [
    { id: 'home', label: 'Home', icon: Users },
    { id: 'requests', label: 'Friend Requests', icon: UserPlus, count: friendRequests.length },
    { id: 'suggestions', label: 'Suggestions', icon: UserCheck },
    { id: 'all', label: 'All Friends', icon: Users },
    { id: 'birthdays', label: 'Birthdays', icon: Clock }
  ];

  const allFriends = users.filter(u => u.id !== currentUser.id);

  const handleAcceptRequest = (userId: string) => {
    setFriendRequests(prev => prev.filter(r => r.id !== userId));
  };

  const handleDeclineRequest = (userId: string) => {
    setFriendRequests(prev => prev.filter(r => r.id !== userId));
  };

  const filteredFriends = allFriends.filter(friend =>
    friend.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm p-4 sticky top-20">
              <div className="flex items-center justify-between mb-4">
                <h1 className="text-2xl font-bold text-gray-900">Friends</h1>
                <button className="w-9 h-9 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors">
                  <Settings className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              {/* Navigation */}
              <nav className="space-y-1">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg transition-colors ${
                      activeTab === tab.id 
                        ? 'bg-blue-50 text-blue-600' 
                        : 'hover:bg-gray-100 text-gray-700'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-9 h-9 rounded-full flex items-center justify-center ${
                        activeTab === tab.id ? 'bg-blue-100' : 'bg-gray-100'
                      }`}>
                        <tab.icon className="w-5 h-5" />
                      </div>
                      <span className="font-medium">{tab.label}</span>
                    </div>
                    {tab.count && tab.count > 0 && (
                      <span className="w-6 h-6 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                        {tab.count}
                      </span>
                    )}
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Friend Requests */}
            {(activeTab === 'home' || activeTab === 'requests') && friendRequests.length > 0 && (
              <div className="bg-white rounded-xl shadow-sm p-4">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold text-gray-900">Friend Requests</h2>
                  <button className="text-blue-500 hover:underline">See all</button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {friendRequests.map((request) => (
                    <div key={request.id} className="border border-gray-200 rounded-xl overflow-hidden">
                      <img 
                        src={request.avatar}
                        alt={request.name}
                        className="w-full h-48 object-cover"
                      />
                      <div className="p-3">
                        <h3 className="font-semibold text-gray-900">{request.name}</h3>
                        <p className="text-sm text-gray-500 mb-1">{request.mutualFriends} mutual friends</p>
                        <p className="text-xs text-gray-400 mb-3">{request.timestamp}</p>
                        <div className="flex items-center gap-2">
                          <button 
                            onClick={() => handleAcceptRequest(request.id)}
                            className="flex-1 py-2 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors"
                          >
                            Confirm
                          </button>
                          <button 
                            onClick={() => handleDeclineRequest(request.id)}
                            className="flex-1 py-2 bg-gray-200 text-gray-700 rounded-lg font-medium hover:bg-gray-300 transition-colors"
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* People You May Know */}
            {(activeTab === 'home' || activeTab === 'suggestions') && (
              <div className="bg-white rounded-xl shadow-sm p-4">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold text-gray-900">People You May Know</h2>
                  <button className="text-blue-500 hover:underline">See all</button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {suggestedFriends.concat(
                    users.slice(4, 10).map(u => ({ ...u, mutualFriends: Math.floor(Math.random() * 20) + 1 }))
                  ).map((suggestion, idx) => (
                    <SuggestionCard key={`${suggestion.id}-${idx}`} user={suggestion} />
                  ))}
                </div>
              </div>
            )}

            {/* All Friends */}
            {activeTab === 'all' && (
              <div className="bg-white rounded-xl shadow-sm p-4">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold text-gray-900">All Friends</h2>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Search friends"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10 pr-4 py-2 bg-gray-100 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {filteredFriends.map((friend) => (
                    <div key={friend.id} className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="relative">
                        <img 
                          src={friend.avatar}
                          alt={friend.name}
                          className="w-14 h-14 rounded-full object-cover"
                        />
                        {friend.isOnline && (
                          <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 rounded-full border-2 border-white" />
                        )}
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900">{friend.name}</h3>
                        <p className="text-sm text-gray-500">{friend.followers.toLocaleString()} followers</p>
                      </div>
                      <button className="w-10 h-10 rounded-full hover:bg-gray-200 flex items-center justify-center">
                        <MoreHorizontal className="w-5 h-5 text-gray-500" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Birthdays */}
            {activeTab === 'birthdays' && (
              <div className="bg-white rounded-xl shadow-sm p-4">
                <h2 className="text-xl font-bold text-gray-900 mb-4">Birthdays</h2>
                
                {/* Today's Birthdays */}
                <div className="mb-6">
                  <h3 className="font-semibold text-gray-700 mb-3">Today's Birthdays</h3>
                  <div className="flex items-center gap-4 p-4 bg-gradient-to-r from-pink-50 to-purple-50 rounded-xl">
                    <div className="relative">
                      <img 
                        src={users[8].avatar}
                        alt={users[8].name}
                        className="w-16 h-16 rounded-full object-cover ring-4 ring-pink-200"
                      />
                      <span className="absolute -bottom-1 -right-1 text-2xl">🎂</span>
                    </div>
                    <div className="flex-1">
                      <p className="text-gray-900">
                        <span className="font-semibold">{users[8].name}</span>'s birthday is today!
                      </p>
                      <p className="text-sm text-gray-500">Write on their timeline to wish them a happy birthday.</p>
                    </div>
                    <button className="px-4 py-2 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors">
                      Post
                    </button>
                  </div>
                </div>

                {/* Upcoming Birthdays */}
                <div>
                  <h3 className="font-semibold text-gray-700 mb-3">Upcoming Birthdays</h3>
                  <div className="space-y-3">
                    {users.slice(0, 5).map((user, idx) => (
                      <div key={user.id} className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors">
                        <img 
                          src={user.avatar}
                          alt={user.name}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900">{user.name}</h4>
                          <p className="text-sm text-gray-500">December {15 + idx}, 2025</p>
                        </div>
                        <span className="text-2xl">🎁</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const SuggestionCard: React.FC<{ user: any }> = ({ user }) => {
  const [isAdded, setIsAdded] = useState(false);
  const [isRemoved, setIsRemoved] = useState(false);

  if (isRemoved) return null;

  return (
    <div className="border border-gray-200 rounded-xl overflow-hidden">
      <img 
        src={user.avatar}
        alt={user.name}
        className="w-full h-48 object-cover"
      />
      <div className="p-3">
        <h3 className="font-semibold text-gray-900">{user.name}</h3>
        <p className="text-sm text-gray-500 mb-3">{user.mutualFriends} mutual friends</p>
        {isAdded ? (
          <div className="flex items-center gap-2">
            <button className="flex-1 py-2 bg-gray-200 text-gray-700 rounded-lg font-medium flex items-center justify-center gap-2">
              <Check className="w-4 h-4" />
              Request Sent
            </button>
            <button 
              onClick={() => setIsAdded(false)}
              className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center hover:bg-gray-200 transition-colors"
            >
              <X className="w-4 h-4 text-gray-500" />
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setIsAdded(true)}
              className="flex-1 py-2 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors flex items-center justify-center gap-2"
            >
              <UserPlus className="w-4 h-4" />
              Add Friend
            </button>
            <button 
              onClick={() => setIsRemoved(true)}
              className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center hover:bg-gray-200 transition-colors"
            >
              <X className="w-4 h-4 text-gray-500" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default FriendsPage;
