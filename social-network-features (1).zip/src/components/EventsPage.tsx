import React, { useState } from 'react';
import { 
  ArrowLeft, Calendar, MapPin, Clock, Users, Plus, Search,
  Filter, ChevronRight, Star, Share2, Bookmark, MoreHorizontal,
  Video, Globe, Lock, CalendarDays, Sparkles
} from 'lucide-react';
import { users, currentUser } from '../data/socialData';

interface Event {
  id: string;
  title: string;
  description: string;
  cover: string;
  date: string;
  time: string;
  location: string;
  isOnline: boolean;
  host: typeof users[0];
  attendees: number;
  interested: number;
  category: string;
  isGoing: boolean;
  isInterested: boolean;
  price: string;
}

interface EventsPageProps {
  onBack: () => void;
}

const EventsPage: React.FC<EventsPageProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState('discover');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [events, setEvents] = useState<Event[]>([
    {
      id: 'e1',
      title: 'Tech Innovators Meetup 2025',
      description: 'Join us for an evening of networking, talks, and innovation. Meet industry leaders and fellow tech enthusiasts.',
      cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298773815_6b3b8d77.png',
      date: 'Sat, Dec 14',
      time: '6:00 PM - 9:00 PM',
      location: 'Tech Hub, San Francisco',
      isOnline: false,
      host: users[7],
      attendees: 234,
      interested: 567,
      category: 'Networking',
      isGoing: false,
      isInterested: true,
      price: 'Free'
    },
    {
      id: 'e2',
      title: 'Virtual Music Festival',
      description: 'Experience live performances from top artists around the world. Stream from anywhere!',
      cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681347_8aa2cbbc.png',
      date: 'Sun, Dec 15',
      time: '4:00 PM - 10:00 PM',
      location: 'Online Event',
      isOnline: true,
      host: users[5],
      attendees: 1250,
      interested: 3400,
      category: 'Music',
      isGoing: true,
      isInterested: false,
      price: '$15'
    },
    {
      id: 'e3',
      title: 'Photography Workshop',
      description: 'Learn advanced photography techniques from professional photographers. Bring your camera!',
      cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298743451_fdf3e0a7.png',
      date: 'Mon, Dec 16',
      time: '10:00 AM - 2:00 PM',
      location: 'Central Park, New York',
      isOnline: false,
      host: users[2],
      attendees: 45,
      interested: 120,
      category: 'Education',
      isGoing: false,
      isInterested: false,
      price: '$25'
    },
    {
      id: 'e4',
      title: 'Fitness Bootcamp',
      description: 'High-intensity workout session for all fitness levels. Get ready to sweat!',
      cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298770024_3c3895be.jpg',
      date: 'Tue, Dec 17',
      time: '7:00 AM - 8:30 AM',
      location: 'Beach Park, Miami',
      isOnline: false,
      host: users[3],
      attendees: 78,
      interested: 156,
      category: 'Sports',
      isGoing: false,
      isInterested: true,
      price: 'Free'
    },
    {
      id: 'e5',
      title: 'Fashion Week Preview',
      description: 'Exclusive preview of upcoming fashion trends. Meet designers and influencers.',
      cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681505_56062067.png',
      date: 'Wed, Dec 18',
      time: '7:00 PM - 11:00 PM',
      location: 'Grand Ballroom, Paris',
      isOnline: false,
      host: users[6],
      attendees: 320,
      interested: 890,
      category: 'Fashion',
      isGoing: false,
      isInterested: false,
      price: '$50'
    },
    {
      id: 'e6',
      title: 'Cooking Masterclass',
      description: 'Learn to cook gourmet dishes with celebrity chef. Ingredients provided!',
      cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298672761_8e473f6e.jpg',
      date: 'Thu, Dec 19',
      time: '5:00 PM - 8:00 PM',
      location: 'Culinary Institute, Chicago',
      isOnline: false,
      host: users[4],
      attendees: 24,
      interested: 89,
      category: 'Food',
      isGoing: true,
      isInterested: false,
      price: '$35'
    }
  ]);

  const categories = [
    { id: 'all', label: 'All Events', icon: CalendarDays },
    { id: 'networking', label: 'Networking', icon: Users },
    { id: 'music', label: 'Music', icon: Sparkles },
    { id: 'sports', label: 'Sports', icon: Star },
    { id: 'education', label: 'Education', icon: Globe },
    { id: 'food', label: 'Food & Drink', icon: Star }
  ];

  const tabs = [
    { id: 'discover', label: 'Discover' },
    { id: 'going', label: 'Going' },
    { id: 'interested', label: 'Interested' },
    { id: 'hosting', label: 'Hosting' },
    { id: 'past', label: 'Past' }
  ];

  const handleGoing = (eventId: string) => {
    setEvents(events.map(event => {
      if (event.id === eventId) {
        const wasGoing = event.isGoing;
        return {
          ...event,
          isGoing: !wasGoing,
          isInterested: false,
          attendees: wasGoing ? event.attendees - 1 : event.attendees + 1,
          interested: event.isInterested ? event.interested - 1 : event.interested
        };
      }
      return event;
    }));
  };

  const handleInterested = (eventId: string) => {
    setEvents(events.map(event => {
      if (event.id === eventId) {
        const wasInterested = event.isInterested;
        return {
          ...event,
          isInterested: !wasInterested,
          interested: wasInterested ? event.interested - 1 : event.interested + 1
        };
      }
      return event;
    }));
  };

  const filteredEvents = events.filter(event => {
    const matchesSearch = event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         event.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || 
                           event.category.toLowerCase() === selectedCategory;
    
    if (activeTab === 'going') return event.isGoing && matchesSearch && matchesCategory;
    if (activeTab === 'interested') return event.isInterested && matchesSearch && matchesCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <button 
                onClick={onBack}
                className="w-10 h-10 flex items-center justify-center hover:bg-gray-100 rounded-full transition-colors"
              >
                <ArrowLeft className="w-6 h-6 text-gray-700" />
              </button>
              <h1 className="text-2xl font-bold text-gray-900">Events</h1>
            </div>
            <button 
              onClick={() => setShowCreateModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors"
            >
              <Plus className="w-5 h-5" />
              Create Event
            </button>
          </div>

          {/* Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto pb-3">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 rounded-full font-medium text-sm whitespace-nowrap transition-colors ${
                  activeTab === tab.id
                    ? 'bg-blue-100 text-blue-600'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="flex gap-6">
          {/* Sidebar */}
          <aside className="hidden lg:block w-64 flex-shrink-0">
            {/* Search */}
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search events..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-white rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Categories */}
            <div className="bg-white rounded-xl shadow-sm p-4">
              <h3 className="font-semibold text-gray-900 mb-3">Categories</h3>
              <div className="space-y-1">
                {categories.map(cat => (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                      selectedCategory === cat.id
                        ? 'bg-blue-50 text-blue-600'
                        : 'text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <cat.icon className="w-5 h-5" />
                    <span className="font-medium text-sm">{cat.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Your Calendar */}
            <div className="bg-white rounded-xl shadow-sm p-4 mt-4">
              <h3 className="font-semibold text-gray-900 mb-3">Your Calendar</h3>
              <div className="text-center py-4">
                <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-2" />
                <p className="text-sm text-gray-500">Connect your calendar to sync events</p>
                <button className="mt-3 px-4 py-2 bg-blue-500 text-white text-sm rounded-lg font-medium hover:bg-blue-600 transition-colors">
                  Connect Calendar
                </button>
              </div>
            </div>
          </aside>

          {/* Main Content */}
          <main className="flex-1">
            {/* Featured Event */}
            {activeTab === 'discover' && filteredEvents[0] && (
              <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-6">
                <div className="relative h-64">
                  <img 
                    src={filteredEvents[0].cover}
                    alt={filteredEvents[0].title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                    <span className="px-3 py-1 bg-blue-500 rounded-full text-xs font-medium mb-3 inline-block">
                      Featured Event
                    </span>
                    <h2 className="text-2xl font-bold mb-2">{filteredEvents[0].title}</h2>
                    <div className="flex items-center gap-4 text-sm">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {filteredEvents[0].date}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        {filteredEvents[0].location}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Events Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredEvents.map(event => (
                <div key={event.id} className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow">
                  <div className="relative h-40">
                    <img 
                      src={event.cover}
                      alt={event.title}
                      className="w-full h-full object-cover"
                    />
                    {event.isOnline && (
                      <span className="absolute top-3 left-3 px-2 py-1 bg-purple-500 text-white text-xs rounded-full flex items-center gap-1">
                        <Video className="w-3 h-3" />
                        Online
                      </span>
                    )}
                    <span className="absolute top-3 right-3 px-2 py-1 bg-white/90 text-gray-900 text-xs font-medium rounded-full">
                      {event.price}
                    </span>
                  </div>
                  <div className="p-4">
                    <div className="flex items-center gap-2 text-sm text-red-500 font-medium mb-2">
                      <Calendar className="w-4 h-4" />
                      {event.date} · {event.time}
                    </div>
                    <h3 className="font-bold text-gray-900 mb-1 line-clamp-1">{event.title}</h3>
                    <p className="text-sm text-gray-500 flex items-center gap-1 mb-3">
                      <MapPin className="w-4 h-4" />
                      {event.location}
                    </p>
                    <div className="flex items-center gap-2 mb-3">
                      <div className="flex -space-x-2">
                        {[users[0], users[1], users[2]].map((user, idx) => (
                          <img 
                            key={idx}
                            src={user.avatar}
                            alt=""
                            className="w-6 h-6 rounded-full border-2 border-white object-cover"
                          />
                        ))}
                      </div>
                      <span className="text-xs text-gray-500">
                        {event.attendees} going · {event.interested} interested
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => handleGoing(event.id)}
                        className={`flex-1 py-2 rounded-lg font-medium text-sm transition-colors ${
                          event.isGoing
                            ? 'bg-blue-500 text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        {event.isGoing ? 'Going' : 'Go'}
                      </button>
                      <button 
                        onClick={() => handleInterested(event.id)}
                        className={`flex-1 py-2 rounded-lg font-medium text-sm transition-colors ${
                          event.isInterested
                            ? 'bg-yellow-100 text-yellow-700'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        {event.isInterested ? 'Interested' : 'Interested'}
                      </button>
                      <button className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center hover:bg-gray-200 transition-colors">
                        <Share2 className="w-5 h-5 text-gray-600" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {filteredEvents.length === 0 && (
              <div className="bg-white rounded-xl shadow-sm p-12 text-center">
                <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No events found</h3>
                <p className="text-gray-500 mb-4">Try adjusting your filters or search query</p>
                <button 
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('all');
                  }}
                  className="px-4 py-2 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors"
                >
                  Clear Filters
                </button>
              </div>
            )}
          </main>
        </div>
      </div>

      {/* Create Event Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowCreateModal(false)} />
          <div className="relative bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b px-6 py-4 flex items-center justify-between">
              <h2 className="text-xl font-bold">Create Event</h2>
              <button 
                onClick={() => setShowCreateModal(false)}
                className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200"
              >
                ×
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Event Name</label>
                <input 
                  type="text"
                  placeholder="Enter event name"
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                  <input 
                    type="date"
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Time</label>
                  <input 
                    type="time"
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                <div className="flex gap-2 mb-2">
                  <button className="flex-1 py-2 bg-blue-50 text-blue-600 rounded-lg font-medium text-sm flex items-center justify-center gap-2">
                    <MapPin className="w-4 h-4" />
                    In Person
                  </button>
                  <button className="flex-1 py-2 bg-gray-100 text-gray-600 rounded-lg font-medium text-sm flex items-center justify-center gap-2">
                    <Video className="w-4 h-4" />
                    Online
                  </button>
                </div>
                <input 
                  type="text"
                  placeholder="Add location"
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea 
                  placeholder="What's your event about?"
                  rows={4}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Privacy</label>
                <div className="flex gap-2">
                  <button className="flex-1 py-2 bg-blue-50 text-blue-600 rounded-lg font-medium text-sm flex items-center justify-center gap-2">
                    <Globe className="w-4 h-4" />
                    Public
                  </button>
                  <button className="flex-1 py-2 bg-gray-100 text-gray-600 rounded-lg font-medium text-sm flex items-center justify-center gap-2">
                    <Lock className="w-4 h-4" />
                    Private
                  </button>
                </div>
              </div>
              <button className="w-full py-3 bg-blue-500 text-white rounded-lg font-semibold hover:bg-blue-600 transition-colors">
                Create Event
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EventsPage;
