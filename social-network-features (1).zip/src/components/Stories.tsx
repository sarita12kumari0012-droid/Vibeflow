import React, { useState, useRef, useEffect } from 'react';
import { stories as demoStories, currentUser, Story } from '../data/socialData';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { Plus, ChevronLeft, ChevronRight, X, Heart, Send, Pause, Play, Eye, Loader2 } from 'lucide-react';

interface StoriesProps {
  onCreateStory: () => void;
}

interface DBStory {
  id: string;
  user_id: string;
  media_url: string;
  media_type: string;
  caption: string;
  background_color: string;
  views_count: number;
  created_at: string;
  user_profiles?: {
    user_id: string;
    username: string;
    full_name: string;
    avatar_url: string;
    is_verified: boolean;
  };
}

const Stories: React.FC<StoriesProps> = ({ onCreateStory }) => {
  const { isAuthenticated, profile } = useAuth();
  const [selectedStory, setSelectedStory] = useState<Story | null>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [progress, setProgress] = useState(0);
  const [dbStories, setDbStories] = useState<DBStory[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [replyText, setReplyText] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  // Combine demo stories with database stories
  const allStories = [...demoStories];

  // Load stories from database
  // Load stories from database
  useEffect(() => {
    loadStories();
  }, []);

  const loadStories = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase.functions.invoke('media-service', {
        body: { action: 'get_stories' }
      });

      if (error) {
        console.log('Stories service unavailable, using demo data');
        return;
      }
      
      if (data?.stories && Array.isArray(data.stories)) {
        // Handle both flat array and grouped stories
        const flatStories: DBStory[] = [];
        data.stories.forEach((item: any) => {
          if (item.stories) {
            // Grouped format
            item.stories.forEach((story: any) => {
              flatStories.push({ ...story, user_profiles: item.user });
            });
          } else {
            // Flat format
            flatStories.push(item);
          }
        });
        setDbStories(flatStories);
      }
    } catch (error) {
      console.log('Error loading stories, using demo data:', error);
    } finally {
      setIsLoading(false);
    }
  };



  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = direction === 'left' ? -200 : 200;
      scrollRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  const openStory = (story: Story) => {
    setSelectedStory(story);
    setProgress(0);
    setIsPaused(false);
  };

  const closeStory = () => {
    setSelectedStory(null);
    setProgress(0);
    setReplyText('');
  };

  const nextStory = () => {
    const currentIndex = allStories.findIndex(s => s.id === selectedStory?.id);
    if (currentIndex < allStories.length - 1) {
      setSelectedStory(allStories[currentIndex + 1]);
      setProgress(0);
    } else {
      closeStory();
    }
  };

  const prevStory = () => {
    const currentIndex = allStories.findIndex(s => s.id === selectedStory?.id);
    if (currentIndex > 0) {
      setSelectedStory(allStories[currentIndex - 1]);
      setProgress(0);
    }
  };

  // Handle tap on story - left side = previous, right side = next
  const handleStoryTap = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const tapX = e.clientX - rect.left;
    const screenWidth = rect.width;
    
    if (tapX < screenWidth / 3) {
      prevStory();
    } else if (tapX > (screenWidth * 2) / 3) {
      nextStory();
    } else {
      // Middle tap - pause/play
      setIsPaused(!isPaused);
    }
  };

  const handleSendReply = () => {
    if (replyText.trim()) {
      alert(`Reply sent: ${replyText}`);
      setReplyText('');
    }
  };

  // Auto-progress effect
  useEffect(() => {
    if (selectedStory && !isPaused) {
      const interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            nextStory();
            return 0;
          }
          return prev + 2;
        });
      }, 100);
      return () => clearInterval(interval);
    }
  }, [selectedStory, isPaused]);

  return (
    <>
      {/* Stories Bar */}
      <div className="bg-white rounded-xl shadow-sm p-4 mb-4 relative">
        <div className="flex items-center gap-3">
          {/* Create Story */}
          <button 
            onClick={onCreateStory}
            className="flex-shrink-0 flex flex-col items-center gap-1 group"
          >
            <div className="relative">
              <img 
                src={profile?.avatar_url || currentUser.avatar}
                alt="Create story"
                className="w-16 h-16 rounded-full object-cover ring-2 ring-gray-200"
              />
              <div className="absolute -bottom-1 -right-1 w-7 h-7 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center border-3 border-white group-hover:scale-110 transition-transform shadow-lg">
                <Plus className="w-4 h-4 text-white" />
              </div>
            </div>
            <span className="text-xs text-gray-600 font-medium">Your Story</span>
          </button>

          {/* Scroll Buttons */}
          <button 
            onClick={() => scroll('left')}
            className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-white shadow-lg rounded-full flex items-center justify-center z-10 hover:bg-gray-50 transition-colors"
          >
            <ChevronLeft className="w-5 h-5 text-gray-600" />
          </button>
          <button 
            onClick={() => scroll('right')}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-white shadow-lg rounded-full flex items-center justify-center z-10 hover:bg-gray-50 transition-colors"
          >
            <ChevronRight className="w-5 h-5 text-gray-600" />
          </button>

          {/* Stories */}
          <div 
            ref={scrollRef}
            className="flex items-center gap-3 overflow-x-auto scrollbar-hide scroll-smooth"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {/* Database Stories */}
            {dbStories.map((story) => (
              <button
                key={story.id}
                onClick={() => openStory({
                  id: story.id,
                  user: {
                    id: story.user_profiles?.user_id || story.user_id,
                    name: story.user_profiles?.full_name || 'User',
                    username: story.user_profiles?.username || 'user',
                    avatar: story.user_profiles?.avatar_url || '/placeholder.svg',
                    isVerified: story.user_profiles?.is_verified
                  },
                  media: story.media_url,
                  timestamp: new Date(story.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                  viewed: false
                })}
                className="flex-shrink-0 flex flex-col items-center gap-1 group"
              >
                <div className="p-0.5 rounded-full bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-600">
                  <div className="p-0.5 bg-white rounded-full">
                    <img 
                      src={story.user_profiles?.avatar_url || '/placeholder.svg'}
                      alt={story.user_profiles?.full_name || 'User'}
                      className="w-16 h-16 rounded-full object-cover group-hover:scale-105 transition-transform"
                    />
                  </div>
                </div>
                <span className="text-xs text-gray-600 max-w-[70px] truncate">
                  {story.user_profiles?.full_name?.split(' ')[0] || 'User'}
                </span>
              </button>
            ))}

            {/* Demo Stories */}
            {allStories.map((story) => (
              <button
                key={story.id}
                onClick={() => openStory(story)}
                className="flex-shrink-0 flex flex-col items-center gap-1 group"
              >
                <div className={`p-0.5 rounded-full ${story.viewed ? 'bg-gray-300' : 'bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-600'}`}>
                  <div className="p-0.5 bg-white rounded-full">
                    <img 
                      src={story.user.avatar}
                      alt={story.user.name}
                      className="w-16 h-16 rounded-full object-cover group-hover:scale-105 transition-transform"
                    />
                  </div>
                </div>
                <span className="text-xs text-gray-600 max-w-[70px] truncate">
                  {story.user.name.split(' ')[0]}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Story Viewer Modal */}
      {selectedStory && (
        <div className="fixed inset-0 bg-black z-50 flex items-center justify-center">
          {/* Close Button */}
          <button 
            onClick={closeStory}
            className="absolute top-4 right-4 w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white/30 transition-colors z-30"
          >
            <X className="w-6 h-6 text-white" />
          </button>

          {/* Story Content - Tap to navigate */}
          <div 
            className="relative w-full max-w-md h-[85vh] bg-gray-900 rounded-2xl overflow-hidden cursor-pointer select-none"
            onClick={handleStoryTap}
          >
            {/* Progress Bar */}
            <div className="absolute top-2 left-2 right-2 flex gap-1 z-20">
              {allStories.map((story, idx) => (
                <div key={story.id} className="flex-1 h-1 bg-white/30 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-white transition-all duration-100"
                    style={{ 
                      width: story.id === selectedStory.id 
                        ? `${progress}%` 
                        : allStories.findIndex(s => s.id === selectedStory.id) > idx 
                          ? '100%' 
                          : '0%' 
                    }}
                  />
                </div>
              ))}
            </div>

            {/* Header */}
            <div className="absolute top-6 left-4 right-4 flex items-center justify-between z-20">
              <div className="flex items-center gap-3">
                <img 
                  src={selectedStory.user.avatar}
                  alt={selectedStory.user.name}
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-white"
                />
                <div>
                  <div className="flex items-center gap-1">
                    <p className="text-white font-semibold text-sm">{selectedStory.user.name}</p>
                    {selectedStory.user.isVerified && (
                      <svg className="w-4 h-4 text-blue-400" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/>
                      </svg>
                    )}
                  </div>
                  <p className="text-white/70 text-xs">{selectedStory.timestamp}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsPaused(!isPaused);
                  }}
                  className="w-8 h-8 flex items-center justify-center bg-white/20 rounded-full"
                >
                  {isPaused ? (
                    <Play className="w-4 h-4 text-white" />
                  ) : (
                    <Pause className="w-4 h-4 text-white" />
                  )}
                </button>
              </div>
            </div>

            {/* Story Image/Video */}
            <img 
              src={selectedStory.media}
              alt="Story"
              className="w-full h-full object-cover"
            />

            {/* Tap zones indicator (subtle) */}
            <div className="absolute inset-0 flex pointer-events-none">
              <div className="w-1/3 h-full flex items-center justify-start pl-4 opacity-0 hover:opacity-100 transition-opacity">
                <ChevronLeft className="w-8 h-8 text-white/50" />
              </div>
              <div className="w-1/3 h-full" />
              <div className="w-1/3 h-full flex items-center justify-end pr-4 opacity-0 hover:opacity-100 transition-opacity">
                <ChevronRight className="w-8 h-8 text-white/50" />
              </div>
            </div>

            {/* Reaction Bar */}
            <div 
              className="absolute bottom-4 left-4 right-4 flex items-center gap-3 z-20"
              onClick={(e) => e.stopPropagation()}
            >
              <input 
                type="text"
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendReply()}
                placeholder="Reply to story..."
                className="flex-1 px-4 py-2.5 bg-white/20 backdrop-blur-sm rounded-full text-white placeholder-white/70 text-sm focus:outline-none focus:ring-2 focus:ring-white/50"
              />
              <button 
                onClick={() => alert('Liked!')}
                className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-red-500 transition-colors"
              >
                <Heart className="w-5 h-5 text-white" />
              </button>
              <button 
                onClick={handleSendReply}
                disabled={!replyText.trim()}
                className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-blue-500 transition-colors disabled:opacity-50"
              >
                <Send className="w-5 h-5 text-white" />
              </button>
            </div>

            {/* Views count */}
            <div className="absolute bottom-20 left-4 flex items-center gap-1 text-white/70 text-sm z-20">
              <Eye className="w-4 h-4" />
              <span>1.2K views</span>
            </div>
          </div>
        </div>
      )}

      <style>{`
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </>
  );
};

export default Stories;
