import React from 'react';
import AppLayout from '@/components/AppLayout';
import { AppProvider } from '@/contexts/AppContext';
import { AuthProvider } from '@/contexts/AuthContext';
import { NotificationProvider } from '@/contexts/NotificationContext';

const Index: React.FC = () => {
  return (
    <AuthProvider>
      <NotificationProvider>
        <AppProvider>
          <AppLayout />
        </AppProvider>
      </NotificationProvider>
    </AuthProvider>
  );
};

export default Index;
