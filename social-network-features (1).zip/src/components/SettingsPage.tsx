import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, Shield, Lock, Eye, Bell, Globe, Moon, Sun,
  Smartphone, Key, UserX, FileText, HelpCircle, LogOut,
  ChevronRight, Check, AlertTriangle, User, Camera, Mail,
  MapPin, Calendar, Link2, Facebook, Twitter, Instagram,
  Loader2, Save, X
} from 'lucide-react';
import { currentUser } from '../data/socialData';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';

interface SettingsPageProps {
  onBack: () => void;
}

interface UserSettings {
  dark_mode: boolean;
  two_factor_enabled: boolean;
  profile_locked: boolean;
  show_online_status: boolean;
  show_last_seen: boolean;
  show_read_receipts: boolean;
  notifications_enabled: boolean;
  email_notifications: boolean;
  push_notifications: boolean;
  profile_visibility: string;
  who_can_message: string;
  who_can_see_stories: string;
  accent_color: string;
  language: string;
}

const SettingsPage: React.FC<SettingsPageProps> = ({ onBack }) => {
  const { isAuthenticated, profile, updateProfile, signOut } = useAuth();
  const [activeSection, setActiveSection] = useState('general');
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState('');
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  
  // Settings state
  const [settings, setSettings] = useState<UserSettings>({
    dark_mode: false,
    two_factor_enabled: false,
    profile_locked: false,
    show_online_status: true,
    show_last_seen: true,
    show_read_receipts: true,
    notifications_enabled: true,
    email_notifications: true,
    push_notifications: true,
    profile_visibility: 'public',
    who_can_message: 'everyone',
    who_can_see_stories: 'friends',
    accent_color: 'blue',
    language: 'en'
  });

  // Profile form state
  const [profileForm, setProfileForm] = useState({
    full_name: '',
    username: '',
    bio: '',
    location: '',
    website: '',
    phone: ''
  });

  // Password form state
  const [passwordForm, setPasswordForm] = useState({
    current_password: '',
    new_password: '',
    confirm_password: ''
  });

  // Load settings on mount
  useEffect(() => {
    if (isAuthenticated) {
      loadSettings();
      if (profile) {
        setProfileForm({
          full_name: profile.full_name || '',
          username: profile.username || '',
          bio: profile.bio || '',
          location: profile.location || '',
          website: profile.website || '',
          phone: profile.phone || ''
        });
      }
    }
  }, [isAuthenticated, profile]);

  const loadSettings = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('settings-service', {
        body: { action: 'get_settings' }
      });

      if (error) throw error;
      if (data.settings) {
        setSettings(data.settings);
      }
    } catch (error) {
      console.error('Failed to load settings:', error);
    }
  };

  const saveSettings = async (newSettings: Partial<UserSettings>) => {
    setIsSaving(true);
    try {
      const { data, error } = await supabase.functions.invoke('settings-service', {
        body: { 
          action: 'update_settings',
          settings: { ...settings, ...newSettings }
        }
      });

      if (error) throw error;
      setSettings(data.settings);
      showSaveMessage('Settings saved!');
    } catch (error) {
      console.error('Failed to save settings:', error);
      showSaveMessage('Failed to save settings');
    } finally {
      setIsSaving(false);
    }
  };

  const saveProfile = async () => {
    setIsSaving(true);
    try {
      const { data, error } = await supabase.functions.invoke('settings-service', {
        body: { 
          action: 'update_profile',
          profile: profileForm
        }
      });

      if (error) throw error;
      if (updateProfile && data.profile) {
        updateProfile(data.profile);
      }
      showSaveMessage('Profile updated!');
    } catch (error) {
      console.error('Failed to save profile:', error);
      showSaveMessage('Failed to save profile');
    } finally {
      setIsSaving(false);
    }
  };

  const changePassword = async () => {
    if (passwordForm.new_password !== passwordForm.confirm_password) {
      alert('Passwords do not match');
      return;
    }

    setIsSaving(true);
    try {
      const { data, error } = await supabase.functions.invoke('settings-service', {
        body: { 
          action: 'change_password',
          current_password: passwordForm.current_password,
          new_password: passwordForm.new_password
        }
      });

      if (error) throw error;
      if (!data.success) throw new Error(data.error);
      
      setShowPasswordModal(false);
      setPasswordForm({ current_password: '', new_password: '', confirm_password: '' });
      showSaveMessage('Password changed successfully!');
    } catch (error: any) {
      alert(error.message || 'Failed to change password');
    } finally {
      setIsSaving(false);
    }
  };

  const deleteAccount = async () => {
    if (!confirm('Are you absolutely sure? This action cannot be undone.')) return;

    setIsSaving(true);
    try {
      const { error } = await supabase.functions.invoke('settings-service', {
        body: { action: 'delete_account' }
      });

      if (error) throw error;
      signOut();
      onBack();
    } catch (error) {
      console.error('Failed to delete account:', error);
      alert('Failed to delete account');
    } finally {
      setIsSaving(false);
    }
  };

  const showSaveMessage = (message: string) => {
    setSaveMessage(message);
    setTimeout(() => setSaveMessage(''), 3000);
  };

  const handleSettingChange = (key: keyof UserSettings, value: any) => {
    const newSettings = { [key]: value };
    setSettings(prev => ({ ...prev, ...newSettings }));
    saveSettings(newSettings);
  };

  const sections = [
    { id: 'general', label: 'General', icon: User },
    { id: 'privacy', label: 'Privacy', icon: Eye },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'appearance', label: 'Appearance', icon: Moon },
    { id: 'blocked', label: 'Blocked Users', icon: UserX },
    { id: 'help', label: 'Help & Support', icon: HelpCircle }
  ];

  const Toggle = ({ enabled, onChange, disabled = false }: { enabled: boolean; onChange: () => void; disabled?: boolean }) => (
    <button 
      onClick={onChange}
      disabled={disabled}
      className={`w-12 h-6 rounded-full relative transition-colors ${
        enabled ? 'bg-blue-500' : 'bg-gray-300'
      } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
    >
      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${
        enabled ? 'right-1' : 'left-1'
      }`} />
    </button>
  );

  const renderContent = () => {
    switch (activeSection) {
      case 'general':
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Profile Information</h3>
              <div className="bg-white rounded-xl shadow-sm p-4 space-y-4">
                {/* Profile Picture */}
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <img 
                      src={profile?.avatar_url || currentUser.avatar}
                      alt="Profile"
                      className="w-20 h-20 rounded-full object-cover"
                    />
                    <button className="absolute bottom-0 right-0 w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white">
                      <Camera className="w-4 h-4" />
                    </button>
                  </div>
                  <div>
                    <button className="px-4 py-2 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors">
                      Change Photo
                    </button>
                    <p className="text-sm text-gray-500 mt-1">JPG, PNG. Max 5MB</p>
                  </div>
                </div>

                {/* Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                  <input 
                    type="text"
                    value={profileForm.full_name}
                    onChange={(e) => setProfileForm(prev => ({ ...prev, full_name: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                {/* Username */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
                  <div className="flex">
                    <span className="px-4 py-2 bg-gray-100 border border-r-0 border-gray-200 rounded-l-lg text-gray-500">@</span>
                    <input 
                      type="text"
                      value={profileForm.username}
                      onChange={(e) => setProfileForm(prev => ({ ...prev, username: e.target.value }))}
                      className="flex-1 px-4 py-2 border border-gray-200 rounded-r-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                {/* Bio */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Bio</label>
                  <textarea 
                    value={profileForm.bio}
                    onChange={(e) => setProfileForm(prev => ({ ...prev, bio: e.target.value }))}
                    rows={3}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                  />
                </div>

                {/* Location */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input 
                      type="text"
                      value={profileForm.location}
                      onChange={(e) => setProfileForm(prev => ({ ...prev, location: e.target.value }))}
                      className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                {/* Website */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Website</label>
                  <div className="relative">
                    <Link2 className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input 
                      type="url"
                      value={profileForm.website}
                      onChange={(e) => setProfileForm(prev => ({ ...prev, website: e.target.value }))}
                      placeholder="https://yourwebsite.com"
                      className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                {/* Phone */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                  <input 
                    type="tel"
                    value={profileForm.phone}
                    onChange={(e) => setProfileForm(prev => ({ ...prev, phone: e.target.value }))}
                    placeholder="+1 (555) 000-0000"
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <button 
                  onClick={saveProfile}
                  disabled={isSaving}
                  className="w-full py-2.5 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                  Save Changes
                </button>
              </div>
            </div>

            {/* Connected Accounts */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Connected Accounts</h3>
              <div className="bg-white rounded-xl shadow-sm divide-y">
                {[
                  { icon: Facebook, name: 'Facebook', connected: true, color: 'text-blue-600' },
                  { icon: Twitter, name: 'Twitter', connected: false, color: 'text-sky-500' },
                  { icon: Instagram, name: 'Instagram', connected: true, color: 'text-pink-600' }
                ].map((account, idx) => (
                  <div key={idx} className="flex items-center justify-between p-4">
                    <div className="flex items-center gap-3">
                      <account.icon className={`w-6 h-6 ${account.color}`} />
                      <span className="font-medium text-gray-900">{account.name}</span>
                    </div>
                    <button className={`px-4 py-1.5 rounded-lg font-medium text-sm ${
                      account.connected 
                        ? 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        : 'bg-blue-500 text-white hover:bg-blue-600'
                    }`}>
                      {account.connected ? 'Disconnect' : 'Connect'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 'privacy':
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Profile Privacy</h3>
              <div className="bg-white rounded-xl shadow-sm divide-y">
                <div className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <p className="font-medium text-gray-900">Profile Visibility</p>
                      <p className="text-sm text-gray-500">Who can see your profile</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {['public', 'friends', 'private'].map(option => (
                      <button
                        key={option}
                        onClick={() => handleSettingChange('profile_visibility', option)}
                        className={`py-2 rounded-lg font-medium text-sm capitalize ${
                          settings.profile_visibility === option
                            ? 'bg-blue-500 text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <p className="font-medium text-gray-900">Who Can Message You</p>
                      <p className="text-sm text-gray-500">Control who can send you messages</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {['everyone', 'friends', 'nobody'].map(option => (
                      <button
                        key={option}
                        onClick={() => handleSettingChange('who_can_message', option)}
                        className={`py-2 rounded-lg font-medium text-sm capitalize ${
                          settings.who_can_message === option
                            ? 'bg-blue-500 text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <p className="font-medium text-gray-900">Story Visibility</p>
                      <p className="text-sm text-gray-500">Who can see your stories</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {['everyone', 'friends', 'close-friends'].map(option => (
                      <button
                        key={option}
                        onClick={() => handleSettingChange('who_can_see_stories', option)}
                        className={`py-2 rounded-lg font-medium text-sm capitalize ${
                          settings.who_can_see_stories === option
                            ? 'bg-blue-500 text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        {option.replace('-', ' ')}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Activity Status</h3>
              <div className="bg-white rounded-xl shadow-sm divide-y">
                <div className="flex items-center justify-between p-4">
                  <div>
                    <p className="font-medium text-gray-900">Show Online Status</p>
                    <p className="text-sm text-gray-500">Let others see when you're online</p>
                  </div>
                  <Toggle 
                    enabled={settings.show_online_status} 
                    onChange={() => handleSettingChange('show_online_status', !settings.show_online_status)} 
                  />
                </div>
                <div className="flex items-center justify-between p-4">
                  <div>
                    <p className="font-medium text-gray-900">Show Last Seen</p>
                    <p className="text-sm text-gray-500">Let others see when you were last active</p>
                  </div>
                  <Toggle 
                    enabled={settings.show_last_seen} 
                    onChange={() => handleSettingChange('show_last_seen', !settings.show_last_seen)} 
                  />
                </div>
                <div className="flex items-center justify-between p-4">
                  <div>
                    <p className="font-medium text-gray-900">Read Receipts</p>
                    <p className="text-sm text-gray-500">Let others know when you've read their messages</p>
                  </div>
                  <Toggle 
                    enabled={settings.show_read_receipts} 
                    onChange={() => handleSettingChange('show_read_receipts', !settings.show_read_receipts)} 
                  />
                </div>
              </div>
            </div>
          </div>
        );

      case 'security':
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Account Security</h3>
              <div className="bg-white rounded-xl shadow-sm divide-y">
                <div className="flex items-center justify-between p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <Key className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">Two-Factor Authentication</p>
                      <p className="text-sm text-gray-500">Add an extra layer of security</p>
                    </div>
                  </div>
                  <Toggle 
                    enabled={settings.two_factor_enabled} 
                    onChange={() => handleSettingChange('two_factor_enabled', !settings.two_factor_enabled)} 
                  />
                </div>

                <div className="flex items-center justify-between p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                      <Lock className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">Lock Profile</p>
                      <p className="text-sm text-gray-500">Only friends can see your full profile</p>
                    </div>
                  </div>
                  <Toggle 
                    enabled={settings.profile_locked} 
                    onChange={() => handleSettingChange('profile_locked', !settings.profile_locked)} 
                  />
                </div>

                <button className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                      <Smartphone className="w-5 h-5 text-green-600" />
                    </div>
                    <div className="text-left">
                      <p className="font-medium text-gray-900">Active Sessions</p>
                      <p className="text-sm text-gray-500">Manage your logged in devices</p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </button>

                <button 
                  onClick={() => setShowPasswordModal(true)}
                  className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                      <Key className="w-5 h-5 text-orange-600" />
                    </div>
                    <div className="text-left">
                      <p className="font-medium text-gray-900">Change Password</p>
                      <p className="text-sm text-gray-500">Update your password regularly</p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </button>
              </div>
            </div>

            {/* Security Checkup */}
            <div className="bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl p-6 text-white">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                  <Shield className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-lg">Security Checkup</h3>
                  <p className="text-green-100">Your account is secure</p>
                </div>
              </div>
              <div className="space-y-2">
                {[
                  'Strong password set',
                  'Email verified',
                  'Phone number added'
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-sm">
                    <Check className="w-4 h-4" />
                    {item}
                  </div>
                ))}
              </div>
              <button className="mt-4 px-4 py-2 bg-white text-green-600 rounded-lg font-medium hover:bg-green-50 transition-colors">
                Run Full Checkup
              </button>
            </div>
          </div>
        );

      case 'notifications':
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Notification Preferences</h3>
              <div className="bg-white rounded-xl shadow-sm divide-y">
                <div className="flex items-center justify-between p-4">
                  <div>
                    <p className="font-medium text-gray-900">All Notifications</p>
                    <p className="text-sm text-gray-500">Master toggle for all notifications</p>
                  </div>
                  <Toggle 
                    enabled={settings.notifications_enabled} 
                    onChange={() => handleSettingChange('notifications_enabled', !settings.notifications_enabled)} 
                  />
                </div>
                <div className="flex items-center justify-between p-4">
                  <div>
                    <p className="font-medium text-gray-900">Email Notifications</p>
                    <p className="text-sm text-gray-500">Receive updates via email</p>
                  </div>
                  <Toggle 
                    enabled={settings.email_notifications} 
                    onChange={() => handleSettingChange('email_notifications', !settings.email_notifications)}
                    disabled={!settings.notifications_enabled}
                  />
                </div>
                <div className="flex items-center justify-between p-4">
                  <div>
                    <p className="font-medium text-gray-900">Push Notifications</p>
                    <p className="text-sm text-gray-500">Receive push notifications on your device</p>
                  </div>
                  <Toggle 
                    enabled={settings.push_notifications} 
                    onChange={() => handleSettingChange('push_notifications', !settings.push_notifications)}
                    disabled={!settings.notifications_enabled}
                  />
                </div>
              </div>
            </div>
          </div>
        );

      case 'appearance':
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Theme</h3>
              <div className="bg-white rounded-xl shadow-sm p-4">
                <div className="grid grid-cols-3 gap-4">
                  {[
                    { id: 'light', label: 'Light', icon: Sun },
                    { id: 'dark', label: 'Dark', icon: Moon },
                    { id: 'system', label: 'System', icon: Smartphone }
                  ].map(theme => (
                    <button
                      key={theme.id}
                      onClick={() => handleSettingChange('dark_mode', theme.id === 'dark')}
                      className={`p-4 rounded-xl border-2 transition-colors ${
                        (theme.id === 'dark' && settings.dark_mode) || (theme.id === 'light' && !settings.dark_mode)
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <theme.icon className={`w-8 h-8 mx-auto mb-2 ${
                        (theme.id === 'dark' && settings.dark_mode) || (theme.id === 'light' && !settings.dark_mode)
                          ? 'text-blue-500'
                          : 'text-gray-400'
                      }`} />
                      <p className="font-medium text-gray-900">{theme.label}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Accent Color</h3>
              <div className="bg-white rounded-xl shadow-sm p-4">
                <div className="flex gap-3">
                  {[
                    { color: 'bg-blue-500', name: 'blue' },
                    { color: 'bg-purple-500', name: 'purple' },
                    { color: 'bg-pink-500', name: 'pink' },
                    { color: 'bg-green-500', name: 'green' },
                    { color: 'bg-orange-500', name: 'orange' },
                    { color: 'bg-red-500', name: 'red' }
                  ].map((item) => (
                    <button
                      key={item.name}
                      onClick={() => handleSettingChange('accent_color', item.name)}
                      className={`w-10 h-10 rounded-full ${item.color} ${
                        settings.accent_color === item.name ? 'ring-2 ring-offset-2 ring-blue-500' : ''
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        );

      case 'blocked':
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Blocked Users</h3>
              <div className="bg-white rounded-xl shadow-sm p-8 text-center">
                <UserX className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h4 className="text-lg font-semibold text-gray-900 mb-2">No Blocked Users</h4>
                <p className="text-gray-500 mb-4">When you block someone, they won't be able to see your profile or contact you.</p>
              </div>
            </div>
          </div>
        );

      case 'help':
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Help & Support</h3>
              <div className="bg-white rounded-xl shadow-sm divide-y">
                {[
                  { icon: HelpCircle, label: 'Help Center', desc: 'Find answers to common questions' },
                  { icon: FileText, label: 'Terms of Service', desc: 'Read our terms and conditions' },
                  { icon: Shield, label: 'Privacy Policy', desc: 'Learn how we protect your data' },
                  { icon: Mail, label: 'Contact Support', desc: 'Get help from our team' }
                ].map((item, idx) => (
                  <button key={idx} className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                        <item.icon className="w-5 h-5 text-gray-600" />
                      </div>
                      <div className="text-left">
                        <p className="font-medium text-gray-900">{item.label}</p>
                        <p className="text-sm text-gray-500">{item.desc}</p>
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-gray-400" />
                  </button>
                ))}
              </div>
            </div>

            {/* Logout Button */}
            <button 
              onClick={signOut}
              className="w-full flex items-center justify-center gap-2 p-4 bg-gray-100 rounded-xl text-gray-700 font-medium hover:bg-gray-200 transition-colors"
            >
              <LogOut className="w-5 h-5" />
              Log Out
            </button>

            {/* Danger Zone */}
            <div>
              <h3 className="text-lg font-semibold text-red-600 mb-4">Danger Zone</h3>
              <div className="bg-red-50 border border-red-200 rounded-xl p-4">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-6 h-6 text-red-500 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-red-900">Delete Account</p>
                    <p className="text-sm text-red-700 mb-3">Once you delete your account, there is no going back. Please be certain.</p>
                    <button 
                      onClick={() => setShowDeleteModal(true)}
                      className="px-4 py-2 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 transition-colors"
                    >
                      Delete My Account
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Save Message Toast */}
      {saveMessage && (
        <div className="fixed top-4 right-4 z-50 bg-green-500 text-white px-4 py-2 rounded-lg shadow-lg flex items-center gap-2 animate-fadeIn">
          <Check className="w-4 h-4" />
          {saveMessage}
        </div>
      )}

      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-5xl mx-auto px-4">
          <div className="flex items-center h-16">
            <button 
              onClick={onBack}
              className="w-10 h-10 flex items-center justify-center hover:bg-gray-100 rounded-full transition-colors mr-4"
            >
              <ArrowLeft className="w-6 h-6 text-gray-700" />
            </button>
            <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-6">
        <div className="flex gap-6">
          {/* Sidebar */}
          <aside className="w-64 flex-shrink-0 hidden md:block">
            <div className="bg-white rounded-xl shadow-sm p-2 sticky top-24">
              {sections.map(section => (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    activeSection === section.id
                      ? 'bg-blue-50 text-blue-600'
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <section.icon className="w-5 h-5" />
                  <span className="font-medium">{section.label}</span>
                </button>
              ))}
            </div>
          </aside>

          {/* Main Content */}
          <main className="flex-1">
            {/* Mobile Section Selector */}
            <div className="md:hidden mb-4">
              <select 
                value={activeSection}
                onChange={(e) => setActiveSection(e.target.value)}
                className="w-full px-4 py-3 bg-white rounded-xl shadow-sm border-0 font-medium focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {sections.map(section => (
                  <option key={section.id} value={section.id}>{section.label}</option>
                ))}
              </select>
            </div>

            {renderContent()}
          </main>
        </div>
      </div>

      {/* Password Change Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold">Change Password</h3>
              <button onClick={() => setShowPasswordModal(false)} className="p-2 hover:bg-gray-100 rounded-full">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Current Password</label>
                <input 
                  type="password"
                  value={passwordForm.current_password}
                  onChange={(e) => setPasswordForm(prev => ({ ...prev, current_password: e.target.value }))}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">New Password</label>
                <input 
                  type="password"
                  value={passwordForm.new_password}
                  onChange={(e) => setPasswordForm(prev => ({ ...prev, new_password: e.target.value }))}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Confirm New Password</label>
                <input 
                  type="password"
                  value={passwordForm.confirm_password}
                  onChange={(e) => setPasswordForm(prev => ({ ...prev, confirm_password: e.target.value }))}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <button 
                onClick={changePassword}
                disabled={isSaving}
                className="w-full py-2.5 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isSaving && <Loader2 className="w-4 h-4 animate-spin" />}
                Change Password
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Account Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl w-full max-w-md p-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertTriangle className="w-8 h-8 text-red-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Delete Account?</h3>
              <p className="text-gray-500 mb-6">This action cannot be undone. All your data will be permanently deleted.</p>
              <div className="flex gap-3">
                <button 
                  onClick={() => setShowDeleteModal(false)}
                  className="flex-1 py-2.5 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200"
                >
                  Cancel
                </button>
                <button 
                  onClick={deleteAccount}
                  disabled={isSaving}
                  className="flex-1 py-2.5 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {isSaving && <Loader2 className="w-4 h-4 animate-spin" />}
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(-10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.3s ease-out;
        }
      `}</style>
    </div>
  );
};

export default SettingsPage;
