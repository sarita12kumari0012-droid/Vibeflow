import React, { useState, useEffect } from 'react';
import { currentUser, notifications, conversations } from '../data/socialData';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Search, Home, Users, PlayCircle, Store, Bell, MessageCircle, 
  Menu, Plus, ChevronDown, Settings, HelpCircle, Moon, LogOut, 
  User, Bot, DollarSign, Volume2, VolumeX, Film, Gamepad2, Shield
} from 'lucide-react';


interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenMessages: () => void;
  onOpenNotifications: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  onOpenAuth: () => void;
}

const Header: React.FC<HeaderProps> = ({ 
  activeTab, 
  setActiveTab, 
  onOpenMessages, 
  onOpenNotifications,
  searchQuery,
  setSearchQuery,
  onOpenAuth
}) => {
  const { user, profile, isAuthenticated, signOut } = useAuth();
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showCreateMenu, setShowCreateMenu] = useState(false);
  const [notificationBadge, setNotificationBadge] = useState(0);
  const [messageBadge, setMessageBadge] = useState(0);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Initialize badges
  useEffect(() => {
    const unreadNotifications = notifications.filter(n => !n.read).length;
    const unreadMessages = conversations.reduce((acc, c) => acc + c.unreadCount, 0);
    setNotificationBadge(unreadNotifications);
    setMessageBadge(unreadMessages);
  }, []);

  // Simulate real-time notification updates
  useEffect(() => {
    if (!isAuthenticated) return;

    const interval = setInterval(() => {
      // Randomly add notifications for demo
      if (Math.random() > 0.95) {
        setNotificationBadge(prev => prev + 1);
        if (soundEnabled) {
          playNotificationSound();
        }
      }
    }, 10000);

    return () => clearInterval(interval);
  }, [isAuthenticated, soundEnabled]);

  const playNotificationSound = () => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.value = 800;
      oscillator.type = 'sine';
      
      gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2);
      
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.2);
    } catch (e) {
      console.log('Could not play notification sound');
    }
  };

  const navItems = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'friends', icon: Users, label: 'Friends' },
    { id: 'watch', icon: PlayCircle, label: 'Watch' },
    { id: 'reels', icon: Film, label: 'Reels' },
    { id: 'marketplace', icon: Store, label: 'Marketplace' },
    { id: 'gaming', icon: Gamepad2, label: 'Gaming' }
  ];


  const handleSignOut = async () => {
    await signOut();
    setShowProfileMenu(false);
  };

  const handleNotificationClick = () => {
    onOpenNotifications();
    setNotificationBadge(0);
  };

  const handleMessagesClick = () => {
    onOpenMessages();
    setMessageBadge(0);
  };

  // Get display user info (authenticated user or demo user)
  const displayUser = isAuthenticated && profile ? {
    name: profile.full_name || 'User',
    username: profile.username || 'user',
    avatar: profile.avatar_url || currentUser.avatar,
    email: profile.email
  } : currentUser;

  return (
    <header className="fixed top-0 left-0 right-0 bg-white shadow-sm z-50 border-b border-gray-100">
      <div className="max-w-[1920px] mx-auto px-4 h-14 flex items-center justify-between">
        {/* Left Section - Logo & Search */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center cursor-pointer" onClick={() => setActiveTab('home')}>
            <span className="text-white font-bold text-xl">S</span>
          </div>
          <div className="relative hidden sm:block">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search Socialite"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-60 pl-10 pr-4 py-2 bg-gray-100 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
            />
          </div>
        </div>

        {/* Center Section - Navigation */}
        <nav className="hidden md:flex items-center justify-center flex-1 max-w-xl mx-4">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex-1 flex items-center justify-center py-3 px-6 rounded-lg transition-all relative group ${
                activeTab === item.id 
                  ? 'text-blue-500' 
                  : 'text-gray-500 hover:bg-gray-100'
              }`}
            >
              <item.icon className="w-6 h-6" />
              {activeTab === item.id && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-500" />
              )}
              <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 bg-gray-800 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                {item.label}
              </span>
            </button>
          ))}
        </nav>

        {/* Right Section - Actions */}
        <div className="flex items-center gap-2">
          {isAuthenticated ? (
            <>
              {/* Create Button */}
              <div className="relative">
                <button 
                  onClick={() => setShowCreateMenu(!showCreateMenu)}
                  className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors"
                >
                  <Plus className="w-5 h-5 text-gray-700" />
                </button>
                {showCreateMenu && (
                  <div className="absolute right-0 top-12 w-72 bg-white rounded-xl shadow-xl border border-gray-100 py-2 animate-fadeIn">
                    <div className="px-4 py-2 border-b border-gray-100">
                      <h3 className="font-semibold text-gray-900">Create</h3>
                    </div>
                    {[
                      { icon: '📝', label: 'Post', desc: 'Share what\'s on your mind' },
                      { icon: '📖', label: 'Story', desc: 'Share a photo or video' },
                      { icon: '🎬', label: 'Reel', desc: 'Create a short video' },
                      { icon: '📅', label: 'Event', desc: 'Organize a gathering' },
                      { icon: '👥', label: 'Group', desc: 'Connect with people' }
                    ].map((item, idx) => (
                      <button 
                        key={idx}
                        onClick={() => setShowCreateMenu(false)}
                        className="w-full px-4 py-2 flex items-center gap-3 hover:bg-gray-50 transition-colors"
                      >
                        <span className="text-2xl">{item.icon}</span>
                        <div className="text-left">
                          <p className="font-medium text-gray-900">{item.label}</p>
                          <p className="text-xs text-gray-500">{item.desc}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Messages */}
              <button 
                onClick={handleMessagesClick}
                className="relative w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors"
              >
                <MessageCircle className="w-5 h-5 text-gray-700" />
                {messageBadge > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[20px] h-5 px-1 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-medium animate-pulse">
                    {messageBadge > 9 ? '9+' : messageBadge}
                  </span>
                )}
              </button>

              {/* Notifications */}
              <button 
                onClick={handleNotificationClick}
                className="relative w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors"
              >
                <Bell className="w-5 h-5 text-gray-700" />
                {notificationBadge > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[20px] h-5 px-1 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-medium animate-pulse">
                    {notificationBadge > 9 ? '9+' : notificationBadge}
                  </span>
                )}
              </button>

              {/* Profile */}
              <div className="relative">
                <button 
                  onClick={() => setShowProfileMenu(!showProfileMenu)}
                  className="flex items-center gap-1 p-1 rounded-full hover:bg-gray-100 transition-colors"
                >
                  <img 
                    src={displayUser.avatar} 
                    alt={displayUser.name}
                    className="w-9 h-9 rounded-full object-cover ring-2 ring-gray-100"
                  />
                  <ChevronDown className="w-4 h-4 text-gray-500 hidden sm:block" />
                </button>
                {showProfileMenu && (
                  <div className="absolute right-0 top-12 w-80 bg-white rounded-xl shadow-xl border border-gray-100 py-2 animate-fadeIn">
                    <div className="px-4 py-3 border-b border-gray-100">
                      <div className="flex items-center gap-3">
                        <img 
                          src={displayUser.avatar} 
                          alt={displayUser.name}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                        <div>
                          <p className="font-semibold text-gray-900">{displayUser.name}</p>
                          <p className="text-sm text-gray-500">@{displayUser.username}</p>
                          {profile?.email && (
                            <p className="text-xs text-green-600 flex items-center gap-1 mt-1">
                              <Shield className="w-3 h-3" />
                              Verified Account
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="py-2">
                      <button 
                        onClick={() => {
                          setActiveTab('profile');
                          setShowProfileMenu(false);
                        }}
                        className="w-full px-4 py-2 flex items-center gap-3 hover:bg-gray-50 transition-colors"
                      >
                        <div className="w-9 h-9 bg-gray-100 rounded-full flex items-center justify-center">
                          <User className="w-5 h-5 text-gray-700" />
                        </div>
                        <span className="font-medium text-gray-900">View Profile</span>
                      </button>
                      
                      {/* Sound Toggle */}
                      <button 
                        onClick={() => setSoundEnabled(!soundEnabled)}
                        className="w-full px-4 py-2 flex items-center justify-between hover:bg-gray-50 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 bg-gray-100 rounded-full flex items-center justify-center">
                            {soundEnabled ? (
                              <Volume2 className="w-5 h-5 text-gray-700" />
                            ) : (
                              <VolumeX className="w-5 h-5 text-gray-700" />
                            )}
                          </div>
                          <span className="font-medium text-gray-900">Notification Sound</span>
                        </div>
                        <div className={`w-10 h-6 rounded-full relative transition-colors ${
                          soundEnabled ? 'bg-blue-500' : 'bg-gray-300'
                        }`}>
                          <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${
                            soundEnabled ? 'right-1' : 'left-1'
                          }`} />
                        </div>
                      </button>

                      {[
                        { icon: Settings, label: 'Settings & Privacy', tab: 'settings' },
                        { icon: HelpCircle, label: 'Help & Support', tab: null },
                        { icon: Moon, label: 'Display & Accessibility', tab: null }
                      ].map((item, idx) => (
                        <button 
                          key={idx}
                          onClick={() => {
                            if (item.tab) {
                              setActiveTab(item.tab);
                            }
                            setShowProfileMenu(false);
                          }}
                          className="w-full px-4 py-2 flex items-center gap-3 hover:bg-gray-50 transition-colors"
                        >
                          <div className="w-9 h-9 bg-gray-100 rounded-full flex items-center justify-center">
                            <item.icon className="w-5 h-5 text-gray-700" />
                          </div>
                          <span className="font-medium text-gray-900">{item.label}</span>
                        </button>
                      ))}
                      <div className="border-t border-gray-100 mt-2 pt-2">
                        <button 
                          onClick={handleSignOut}
                          className="w-full px-4 py-2 flex items-center gap-3 hover:bg-gray-50 transition-colors text-red-600"
                        >
                          <div className="w-9 h-9 bg-red-50 rounded-full flex items-center justify-center">
                            <LogOut className="w-5 h-5" />
                          </div>
                          <span className="font-medium">Log Out</span>
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </>
          ) : (
            <>
              {/* Sign In Button */}
              <button 
                onClick={onOpenAuth}
                className="px-4 py-2 text-blue-500 font-medium hover:bg-blue-50 rounded-lg transition-colors"
              >
                Sign In
              </button>
              <button 
                onClick={onOpenAuth}
                className="px-4 py-2 bg-blue-500 text-white font-medium rounded-lg hover:bg-blue-600 transition-colors"
              >
                Sign Up
              </button>
            </>
          )}
        </div>
      </div>

      {/* Mobile Navigation */}
      <nav className="md:hidden flex items-center justify-around border-t border-gray-100 bg-white">
        {navItems.slice(0, 5).map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`flex-1 flex items-center justify-center py-3 ${
              activeTab === item.id ? 'text-blue-500' : 'text-gray-500'
            }`}
          >
            <item.icon className="w-6 h-6" />
          </button>
        ))}
      </nav>

      {/* Animation styles */}
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(-10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.2s ease-out;
        }
      `}</style>
    </header>
  );
};

export default Header;
