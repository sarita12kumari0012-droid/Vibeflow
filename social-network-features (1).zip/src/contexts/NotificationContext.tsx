import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from './AuthContext';
import { toast } from '@/components/ui/use-toast';

export interface Notification {
  id: string;
  user_id: string;
  type: 'like' | 'comment' | 'friend_request' | 'message' | 'mention' | 'follow' | 'tip' | 'subscription' | 'system';
  title: string;
  message?: string;
  data?: Record<string, any>;
  read: boolean;
  created_at: string;
  sender_id?: string;
  sender_name?: string;
  sender_avatar?: string;
  action_url?: string;
}

export interface NotificationSettings {
  notification_sound: boolean;
  notification_likes: boolean;
  notification_comments: boolean;
  notification_friend_requests: boolean;
  notification_messages: boolean;
  notification_mentions: boolean;
  notification_follows: boolean;
  email_notifications: boolean;
  push_notifications: boolean;
}

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  settings: NotificationSettings;
  isLoading: boolean;
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
  markAsRead: (notificationId: string) => Promise<void>;
  markAllAsRead: () => Promise<void>;
  deleteNotification: (notificationId: string) => Promise<void>;
  clearAllNotifications: () => Promise<void>;
  updateSettings: (newSettings: Partial<NotificationSettings>) => Promise<void>;
  sendNotification: (notification: Omit<Notification, 'id' | 'created_at' | 'read'>) => Promise<void>;
  refreshNotifications: () => Promise<void>;
}

const defaultSettings: NotificationSettings = {
  notification_sound: true,
  notification_likes: true,
  notification_comments: true,
  notification_friend_requests: true,
  notification_messages: true,
  notification_mentions: true,
  notification_follows: true,
  email_notifications: true,
  push_notifications: true,
};

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};

// Notification sound
const playNotificationSound = () => {
  try {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.frequency.value = 800;
    oscillator.type = 'sine';
    
    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.3);
  } catch (e) {
    console.log('Could not play notification sound');
  }
};

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isAuthenticated } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [settings, setSettings] = useState<NotificationSettings>(defaultSettings);
  const [isLoading, setIsLoading] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const lastNotificationCount = useRef(0);
  const pollingInterval = useRef<NodeJS.Timeout | null>(null);

  const userId = user?.id || 'demo-user';

  // Fetch notifications
  const fetchNotifications = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;

      const newNotifications = data || [];
      
      // Check for new notifications and play sound
      if (newNotifications.length > lastNotificationCount.current && lastNotificationCount.current > 0) {
        const newCount = newNotifications.filter(n => !n.read).length;
        const oldUnreadCount = notifications.filter(n => !n.read).length;
        
        if (newCount > oldUnreadCount && soundEnabled && settings.notification_sound) {
          playNotificationSound();
          
          // Show toast for new notification
          const latestNew = newNotifications[0];
          if (latestNew && !latestNew.read) {
            toast({
              title: latestNew.title,
              description: latestNew.message,
            });
          }
        }
      }
      
      lastNotificationCount.current = newNotifications.length;
      setNotifications(newNotifications);
    } catch (error) {
      console.error('Error fetching notifications:', error);
    }
  }, [userId, soundEnabled, settings.notification_sound, notifications]);

  // Fetch user settings
  const fetchSettings = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('user_settings')
        .select('*')
        .eq('user_id', userId)
        .single();

      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setSettings({
          notification_sound: data.notification_sound ?? true,
          notification_likes: data.notification_likes ?? true,
          notification_comments: data.notification_comments ?? true,
          notification_friend_requests: data.notification_friend_requests ?? true,
          notification_messages: data.notification_messages ?? true,
          notification_mentions: data.notification_mentions ?? true,
          notification_follows: data.notification_follows ?? true,
          email_notifications: data.email_notifications ?? true,
          push_notifications: data.push_notifications ?? true,
        });
        setSoundEnabled(data.notification_sound ?? true);
      }
    } catch (error) {
      console.error('Error fetching settings:', error);
    }
  }, [userId]);

  // Initialize and set up polling
  useEffect(() => {
    if (isAuthenticated) {
      setIsLoading(true);
      Promise.all([fetchNotifications(), fetchSettings()]).finally(() => {
        setIsLoading(false);
      });

      // Set up polling for real-time updates (every 10 seconds)
      pollingInterval.current = setInterval(fetchNotifications, 10000);

      return () => {
        if (pollingInterval.current) {
          clearInterval(pollingInterval.current);
        }
      };
    }
  }, [isAuthenticated, fetchNotifications, fetchSettings]);

  // Mark single notification as read
  const markAsRead = async (notificationId: string) => {
    try {
      await supabase
        .from('notifications')
        .update({ read: true })
        .eq('id', notificationId);

      setNotifications(prev =>
        prev.map(n => (n.id === notificationId ? { ...n, read: true } : n))
      );
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };

  // Mark all as read
  const markAllAsRead = async () => {
    try {
      await supabase
        .from('notifications')
        .update({ read: true })
        .eq('user_id', userId)
        .eq('read', false);

      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    } catch (error) {
      console.error('Error marking all as read:', error);
    }
  };

  // Delete notification
  const deleteNotification = async (notificationId: string) => {
    try {
      await supabase
        .from('notifications')
        .delete()
        .eq('id', notificationId);

      setNotifications(prev => prev.filter(n => n.id !== notificationId));
    } catch (error) {
      console.error('Error deleting notification:', error);
    }
  };

  // Clear all notifications
  const clearAllNotifications = async () => {
    try {
      await supabase
        .from('notifications')
        .delete()
        .eq('user_id', userId);

      setNotifications([]);
    } catch (error) {
      console.error('Error clearing notifications:', error);
    }
  };

  // Update settings
  const updateSettings = async (newSettings: Partial<NotificationSettings>) => {
    try {
      const updatedSettings = { ...settings, ...newSettings };
      
      await supabase
        .from('user_settings')
        .upsert({
          user_id: userId,
          ...updatedSettings,
          updated_at: new Date().toISOString(),
        });

      setSettings(updatedSettings);
      if (newSettings.notification_sound !== undefined) {
        setSoundEnabled(newSettings.notification_sound);
      }
    } catch (error) {
      console.error('Error updating settings:', error);
    }
  };

  // Send notification
  const sendNotification = async (notification: Omit<Notification, 'id' | 'created_at' | 'read'>) => {
    try {
      const { error } = await supabase
        .from('notifications')
        .insert({
          ...notification,
          read: false,
          created_at: new Date().toISOString(),
        });

      if (error) throw error;
      
      // Refresh to get the new notification
      await fetchNotifications();
    } catch (error) {
      console.error('Error sending notification:', error);
    }
  };

  // Refresh notifications
  const refreshNotifications = async () => {
    await fetchNotifications();
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        unreadCount,
        settings,
        isLoading,
        soundEnabled,
        setSoundEnabled,
        markAsRead,
        markAllAsRead,
        deleteNotification,
        clearAllNotifications,
        updateSettings,
        sendNotification,
        refreshNotifications,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};
