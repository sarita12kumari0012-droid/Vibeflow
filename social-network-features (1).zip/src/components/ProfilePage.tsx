import React, { useState, useRef } from 'react';
import { currentUser, posts, users, badges } from '../data/socialData';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { 
  Camera, Edit, MoreHorizontal, UserPlus, MessageCircle, 
  MapPin, Briefcase, GraduationCap, Heart, Calendar,
  Grid, Image, Film, Bookmark, Settings, ChevronDown,
  Users, Globe, Lock, Link, Phone, Mail, Clock, Archive,
  Shield, Eye, EyeOff, Bell, BellOff, UserX, Flag,
  Share2, Download, Trash2, X, Check, Plus, Search,
  Video, Music, FileText, Star, Award, Zap, Crown,
  Activity, TrendingUp, BarChart3, Gift, Coffee, Home,
  Smile, Frown, Meh, ThumbsUp, MessageSquare, Send, Loader2,
  Upload, QrCode, Copy, ExternalLink
} from 'lucide-react';
import PostCard from './PostCard';

interface ProfilePageProps {
  userId?: string;
  onBack: () => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ userId, onBack }) => {
  const { isAuthenticated, profile, updateProfile } = useAuth();
  const [activeTab, setActiveTab] = useState('posts');
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [showMoreOptions, setShowMoreOptions] = useState(false);
  const [showActivityLog, setShowActivityLog] = useState(false);
  const [showArchive, setShowArchive] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);
  const [isFriend, setIsFriend] = useState(false);
  const [showStoryArchive, setShowStoryArchive] = useState(false);
  const [showShareProfile, setShowShareProfile] = useState(false);
  const [showQRCode, setShowQRCode] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const coverInputRef = useRef<HTMLInputElement>(null);
  
  const [editForm, setEditForm] = useState({
    full_name: profile?.full_name || '',
    username: profile?.username || '',
    bio: profile?.bio || '',
    location: profile?.location || '',
    website: profile?.website || '',
    phone: profile?.phone || '',
    work: '',
    education: '',
    relationship_status: 'Single'
  });
  
  // Get current user based on auth state
  const authUser = isAuthenticated && profile ? {
    id: profile.user_id,
    name: profile.full_name || 'User',
    username: profile.username || 'user',
    avatar: profile.avatar_url || currentUser.avatar,
    coverPhoto: profile.cover_photo || currentUser.coverPhoto,
    bio: profile.bio || '',
    location: profile.location || '',
    joinDate: profile.created_at ? new Date(profile.created_at).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) : 'January 2020',
    followers: profile.followers_count || 0,
    following: profile.following_count || 0,
    isOnline: profile.is_online,
    isVerified: profile.is_verified
  } : currentUser;

  const user = userId ? users.find(u => u.id === userId) || authUser : authUser;
  const isOwnProfile = !userId || (isAuthenticated && profile?.user_id === userId);
  const userPosts = posts.filter(p => p.user.id === user.id);

  const tabs = [
    { id: 'posts', label: 'Posts', icon: Grid },
    { id: 'about', label: 'About', icon: Users },
    { id: 'friends', label: 'Friends', icon: Users },
    { id: 'photos', label: 'Photos', icon: Image },
    { id: 'videos', label: 'Videos', icon: Film },
    { id: 'reels', label: 'Reels', icon: Film },
    { id: 'check-ins', label: 'Check-ins', icon: MapPin },
    { id: 'sports', label: 'Sports', icon: Activity },
    { id: 'music', label: 'Music', icon: Music },
    { id: 'movies', label: 'Movies', icon: Film },
  ];


  const photos = [
    'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298743451_fdf3e0a7.png',
    'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298748674_67ccb172.png',
    'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298672761_8e473f6e.jpg',
    'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298687191_91fbdc32.png',
    'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681505_56062067.png',
    'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298743519_6c3f2456.jpg'
  ];

  const friends = users.filter(u => u.id !== user.id).slice(0, 9);

  const activityLog = [
    { id: '1', type: 'post', action: 'You created a post', time: '2 hours ago', icon: FileText },
    { id: '2', type: 'like', action: 'You liked Jane\'s photo', time: '3 hours ago', icon: Heart },
    { id: '3', type: 'comment', action: 'You commented on a post', time: '5 hours ago', icon: MessageCircle },
    { id: '4', type: 'friend', action: 'You became friends with Bob', time: '1 day ago', icon: Users },
    { id: '5', type: 'share', action: 'You shared a video', time: '2 days ago', icon: Share2 },
    { id: '6', type: 'story', action: 'You added to your story', time: '3 days ago', icon: Clock },
  ];

  const storyArchive = [
    { id: '1', image: photos[0], date: 'Dec 10, 2024', views: 234 },
    { id: '2', image: photos[1], date: 'Dec 8, 2024', views: 189 },
    { id: '3', image: photos[2], date: 'Dec 5, 2024', views: 456 },
    { id: '4', image: photos[3], date: 'Dec 1, 2024', views: 321 },
  ];

  const lifeEvents = [
    { id: '1', type: 'work', title: 'Started new job at Tech Corp', date: 'Jan 2024', icon: Briefcase },
    { id: '2', type: 'education', title: 'Graduated from University', date: 'May 2023', icon: GraduationCap },
    { id: '3', type: 'relationship', title: 'In a relationship', date: 'Feb 2023', icon: Heart },
    { id: '4', type: 'home', title: 'Moved to San Francisco', date: 'Dec 2022', icon: Home },
  ];

  // Handle avatar upload
  const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !isAuthenticated) return;

    setIsUploading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Not authenticated');

      const fileName = `${Date.now()}_avatar_${file.name}`;
      const { data, error } = await supabase.storage
        .from('media')
        .upload(`avatars/${session.user.id}/${fileName}`, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (error) throw error;

      const { data: { publicUrl } } = supabase.storage
        .from('media')
        .getPublicUrl(`avatars/${session.user.id}/${fileName}`);

      // Update profile
      await supabase.functions.invoke('settings-service', {
        body: {
          action: 'update_profile',
          profile: { avatar_url: publicUrl }
        }
      });

      if (updateProfile) {
        updateProfile({ ...profile, avatar_url: publicUrl });
      }
    } catch (error) {
      console.error('Avatar upload error:', error);
      alert('Failed to upload avatar');
    } finally {
      setIsUploading(false);
    }
  };

  // Handle cover photo upload
  const handleCoverUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !isAuthenticated) return;

    setIsUploading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Not authenticated');

      const fileName = `${Date.now()}_cover_${file.name}`;
      const { data, error } = await supabase.storage
        .from('media')
        .upload(`covers/${session.user.id}/${fileName}`, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (error) throw error;

      const { data: { publicUrl } } = supabase.storage
        .from('media')
        .getPublicUrl(`covers/${session.user.id}/${fileName}`);

      // Update profile
      await supabase.functions.invoke('settings-service', {
        body: {
          action: 'update_profile',
          profile: { cover_photo: publicUrl }
        }
      });

      if (updateProfile) {
        updateProfile({ ...profile, cover_photo: publicUrl });
      }
    } catch (error) {
      console.error('Cover upload error:', error);
      alert('Failed to upload cover photo');
    } finally {
      setIsUploading(false);
    }
  };

  // Save profile changes
  const handleSaveProfile = async () => {
    if (!isAuthenticated) return;

    setIsSaving(true);
    try {
      const { data, error } = await supabase.functions.invoke('settings-service', {
        body: {
          action: 'update_profile',
          profile: {
            full_name: editForm.full_name,
            username: editForm.username,
            bio: editForm.bio,
            location: editForm.location,
            website: editForm.website,
            phone: editForm.phone
          }
        }
      });

      if (error) throw error;

      if (updateProfile && data.profile) {
        updateProfile(data.profile);
      }
      setShowEditProfile(false);
      alert('Profile updated successfully!');
    } catch (error) {
      console.error('Save profile error:', error);
      alert('Failed to save profile');
    } finally {
      setIsSaving(false);
    }
  };

  // Copy profile link
  const copyProfileLink = () => {
    const link = `https://socialite.app/profile/${user.username}`;
    navigator.clipboard.writeText(link);
    alert('Profile link copied!');
  };

  // Edit Profile Modal
  const EditProfileModal = () => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 p-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900">Edit Profile</h2>
          <button onClick={() => setShowEditProfile(false)} className="p-2 hover:bg-gray-100 rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-4 space-y-6">
          {/* Profile Picture */}
          <div className="text-center">
            <div className="relative inline-block">
              <img src={profile?.avatar_url || user.avatar} alt="" className="w-32 h-32 rounded-full object-cover" />
              <button 
                onClick={() => avatarInputRef.current?.click()}
                disabled={isUploading}
                className="absolute bottom-0 right-0 w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center hover:bg-gray-300 disabled:opacity-50"
              >
                {isUploading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Camera className="w-5 h-5" />}
              </button>
              <input 
                ref={avatarInputRef}
                type="file"
                accept="image/*"
                onChange={handleAvatarUpload}
                className="hidden"
              />
            </div>
            <p className="text-sm text-blue-500 mt-2 cursor-pointer hover:underline" onClick={() => avatarInputRef.current?.click()}>
              Edit profile picture
            </p>
          </div>

          {/* Cover Photo */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Cover Photo</label>
            <div 
              onClick={() => coverInputRef.current?.click()}
              className="h-32 bg-gray-100 rounded-lg flex items-center justify-center cursor-pointer hover:bg-gray-200 relative overflow-hidden"
            >
              {profile?.cover_photo ? (
                <img src={profile.cover_photo} alt="Cover" className="w-full h-full object-cover" />
              ) : (
                <div className="text-center">
                  <Camera className="w-8 h-8 text-gray-400 mx-auto mb-1" />
                  <span className="text-sm text-gray-500">Add cover photo</span>
                </div>
              )}
              {isUploading && (
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                  <Loader2 className="w-8 h-8 text-white animate-spin" />
                </div>
              )}
            </div>
            <input 
              ref={coverInputRef}
              type="file"
              accept="image/*"
              onChange={handleCoverUpload}
              className="hidden"
            />
          </div>

          {/* Basic Info */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
              <input 
                type="text" 
                value={editForm.full_name}
                onChange={(e) => setEditForm(prev => ({ ...prev, full_name: e.target.value }))}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" 
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
              <div className="flex">
                <span className="px-4 py-2 bg-gray-100 border border-r-0 border-gray-200 rounded-l-lg text-gray-500">@</span>
                <input 
                  type="text" 
                  value={editForm.username}
                  onChange={(e) => setEditForm(prev => ({ ...prev, username: e.target.value }))}
                  className="flex-1 px-4 py-2 border border-gray-200 rounded-r-lg focus:outline-none focus:ring-2 focus:ring-blue-500" 
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Bio</label>
              <textarea 
                rows={3} 
                value={editForm.bio}
                onChange={(e) => setEditForm(prev => ({ ...prev, bio: e.target.value }))}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" 
                placeholder="Write something about yourself..." 
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
              <input 
                type="text" 
                value={editForm.location}
                onChange={(e) => setEditForm(prev => ({ ...prev, location: e.target.value }))}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" 
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Website</label>
              <input 
                type="url" 
                value={editForm.website}
                onChange={(e) => setEditForm(prev => ({ ...prev, website: e.target.value }))}
                placeholder="https://yourwebsite.com" 
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" 
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
              <input 
                type="tel" 
                value={editForm.phone}
                onChange={(e) => setEditForm(prev => ({ ...prev, phone: e.target.value }))}
                placeholder="+1 (555) 000-0000" 
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" 
              />
            </div>
          </div>

          {/* Work & Education */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-3">Work & Education</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Workplace</label>
                <input 
                  type="text" 
                  value={editForm.work}
                  onChange={(e) => setEditForm(prev => ({ ...prev, work: e.target.value }))}
                  placeholder="Where do you work?"
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" 
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Education</label>
                <input 
                  type="text" 
                  value={editForm.education}
                  onChange={(e) => setEditForm(prev => ({ ...prev, education: e.target.value }))}
                  placeholder="Where did you study?"
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" 
                />
              </div>
            </div>
          </div>

          {/* Relationship Status */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Relationship Status</label>
            <select 
              value={editForm.relationship_status}
              onChange={(e) => setEditForm(prev => ({ ...prev, relationship_status: e.target.value }))}
              className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option>Single</option>
              <option>In a relationship</option>
              <option>Engaged</option>
              <option>Married</option>
              <option>It's complicated</option>
            </select>
          </div>
        </div>

        <div className="sticky bottom-0 bg-white border-t border-gray-200 p-4 flex justify-end gap-3">
          <button 
            onClick={() => setShowEditProfile(false)} 
            className="px-6 py-2 text-gray-700 font-medium hover:bg-gray-100 rounded-lg"
          >
            Cancel
          </button>
          <button 
            onClick={handleSaveProfile}
            disabled={isSaving}
            className="px-6 py-2 bg-blue-500 text-white font-medium rounded-lg hover:bg-blue-600 disabled:opacity-50 flex items-center gap-2"
          >
            {isSaving && <Loader2 className="w-4 h-4 animate-spin" />}
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );

  // Share Profile Modal
  const ShareProfileModal = () => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl w-full max-w-md p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold">Share Profile</h3>
          <button onClick={() => setShowShareProfile(false)} className="p-2 hover:bg-gray-100 rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="space-y-4">
          {/* Profile Link */}
          <div className="flex items-center gap-2 p-3 bg-gray-100 rounded-lg">
            <input 
              type="text"
              value={`socialite.app/profile/${user.username}`}
              readOnly
              className="flex-1 bg-transparent text-sm focus:outline-none"
            />
            <button 
              onClick={copyProfileLink}
              className="p-2 hover:bg-gray-200 rounded-lg"
            >
              <Copy className="w-4 h-4" />
            </button>
          </div>

          {/* Share Options */}
          <div className="grid grid-cols-4 gap-4">
            {[
              { icon: MessageCircle, label: 'Message', color: 'bg-blue-500' },
              { icon: Mail, label: 'Email', color: 'bg-red-500' },
              { icon: ExternalLink, label: 'More', color: 'bg-gray-500' },
              { icon: QrCode, label: 'QR Code', color: 'bg-purple-500', onClick: () => { setShowShareProfile(false); setShowQRCode(true); } }
            ].map((option, idx) => (
              <button 
                key={idx}
                onClick={option.onClick}
                className="flex flex-col items-center gap-2"
              >
                <div className={`w-12 h-12 ${option.color} rounded-full flex items-center justify-center text-white`}>
                  <option.icon className="w-5 h-5" />
                </div>
                <span className="text-xs text-gray-600">{option.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  // Activity Log Modal
  const ActivityLogModal = () => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 p-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900">Activity Log</h2>
          <button onClick={() => setShowActivityLog(false)} className="p-2 hover:bg-gray-100 rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-4">
          {/* Filters */}
          <div className="flex gap-2 mb-4 overflow-x-auto pb-2">
            {['All', 'Posts', 'Photos', 'Likes', 'Comments', 'Friends'].map((filter) => (
              <button key={filter} className="px-4 py-2 bg-gray-100 rounded-full text-sm font-medium text-gray-700 hover:bg-gray-200 whitespace-nowrap">
                {filter}
              </button>
            ))}
          </div>

          {/* Activity List */}
          <div className="space-y-3">
            {activityLog.map((activity) => (
              <div key={activity.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <activity.icon className="w-5 h-5 text-blue-600" />
                </div>
                <div className="flex-1">
                  <p className="text-gray-900">{activity.action}</p>
                  <p className="text-sm text-gray-500">{activity.time}</p>
                </div>
                <button className="p-2 hover:bg-gray-200 rounded-lg">
                  <MoreHorizontal className="w-5 h-5 text-gray-500" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  // Story Archive Modal
  const StoryArchiveModal = () => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 p-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900">Story Archive</h2>
          <button onClick={() => setShowStoryArchive(false)} className="p-2 hover:bg-gray-100 rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-4">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {storyArchive.map((story) => (
              <div key={story.id} className="relative group cursor-pointer">
                <img src={story.image} alt="" className="w-full aspect-[9/16] object-cover rounded-lg" />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                  <Eye className="w-6 h-6 text-white" />
                </div>
                <div className="absolute bottom-2 left-2 right-2 text-white text-xs">
                  <p>{story.date}</p>
                  <p className="flex items-center gap-1">
                    <Eye className="w-3 h-3" /> {story.views}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  // Archive Modal
  const ArchiveModal = () => (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 p-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900">Archive</h2>
          <button onClick={() => setShowArchive(false)} className="p-2 hover:bg-gray-100 rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-4">
          <div className="grid grid-cols-2 gap-4">
            <button 
              onClick={() => { setShowArchive(false); setShowStoryArchive(true); }}
              className="p-6 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl text-white text-left"
            >
              <Clock className="w-8 h-8 mb-2" />
              <h3 className="font-bold text-lg">Stories Archive</h3>
              <p className="text-sm text-white/80">{storyArchive.length} stories</p>
            </button>
            <button className="p-6 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl text-white text-left">
              <Archive className="w-8 h-8 mb-2" />
              <h3 className="font-bold text-lg">Posts Archive</h3>
              <p className="text-sm text-white/80">12 archived posts</p>
            </button>
            <button className="p-6 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl text-white text-left">
              <Film className="w-8 h-8 mb-2" />
              <h3 className="font-bold text-lg">Reels Archive</h3>
              <p className="text-sm text-white/80">5 archived reels</p>
            </button>
            <button className="p-6 bg-gradient-to-br from-orange-500 to-red-500 rounded-xl text-white text-left">
              <Video className="w-8 h-8 mb-2" />
              <h3 className="font-bold text-lg">Live Archive</h3>
              <p className="text-sm text-white/80">3 past lives</p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  // More Options Dropdown
  const MoreOptionsDropdown = () => (
    <div className="absolute right-0 top-full mt-2 w-72 bg-white rounded-xl shadow-xl border border-gray-200 py-2 z-50">
      {isOwnProfile ? (
        <>
          <button onClick={() => { setShowMoreOptions(false); setShowActivityLog(true); }} className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 text-left">
            <Clock className="w-5 h-5 text-gray-500" />
            <span className="text-gray-700">Activity Log</span>
          </button>
          <button onClick={() => { setShowMoreOptions(false); setShowArchive(true); }} className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 text-left">
            <Archive className="w-5 h-5 text-gray-500" />
            <span className="text-gray-700">Archive</span>
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 text-left">
            <Bookmark className="w-5 h-5 text-gray-500" />
            <span className="text-gray-700">Saved</span>
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 text-left">
            <Eye className="w-5 h-5 text-gray-500" />
            <span className="text-gray-700">View As</span>
          </button>
          <div className="border-t border-gray-100 my-2" />
          <button className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 text-left">
            <Search className="w-5 h-5 text-gray-500" />
            <span className="text-gray-700">Search Profile</span>
          </button>
          <button onClick={() => { setShowMoreOptions(false); setShowShareProfile(true); }} className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 text-left">
            <Share2 className="w-5 h-5 text-gray-500" />
            <span className="text-gray-700">Share Profile</span>
          </button>
          <button onClick={copyProfileLink} className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 text-left">
            <Link className="w-5 h-5 text-gray-500" />
            <span className="text-gray-700">Copy Profile Link</span>
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 text-left">
            <Download className="w-5 h-5 text-gray-500" />
            <span className="text-gray-700">Download Your Information</span>
          </button>
          <div className="border-t border-gray-100 my-2" />
          <button className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 text-left">
            <Lock className="w-5 h-5 text-gray-500" />
            <span className="text-gray-700">Privacy Settings</span>
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 text-left">
            <Shield className="w-5 h-5 text-gray-500" />
            <span className="text-gray-700">Profile Lock</span>
          </button>
        </>
      ) : (
        <>
          <button className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 text-left">
            <Bell className="w-5 h-5 text-gray-500" />
            <span className="text-gray-700">Get Notifications</span>
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 text-left">
            <Star className="w-5 h-5 text-gray-500" />
            <span className="text-gray-700">Add to Favorites</span>
          </button>
          <button onClick={copyProfileLink} className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 text-left">
            <Link className="w-5 h-5 text-gray-500" />
            <span className="text-gray-700">Copy Profile Link</span>
          </button>
          <div className="border-t border-gray-100 my-2" />
          <button className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 text-left">
            <EyeOff className="w-5 h-5 text-gray-500" />
            <span className="text-gray-700">Unfollow</span>
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 text-left">
            <UserX className="w-5 h-5 text-gray-500" />
            <span className="text-gray-700">Block</span>
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 text-left text-red-600">
            <Flag className="w-5 h-5" />
            <span>Report Profile</span>
          </button>
        </>
      )}
    </div>
  );

  // Render About Tab
  const renderAboutTab = () => (
    <div className="space-y-4">
      {/* Overview */}
      <div className="bg-white rounded-xl shadow-sm p-4">
        <h3 className="font-semibold text-gray-900 mb-4">Overview</h3>
        <div className="space-y-3">
          <div className="flex items-center gap-3 text-gray-600">
            <Briefcase className="w-5 h-5 text-gray-400" />
            <span>Works at <strong>Tech Company</strong></span>
          </div>
          <div className="flex items-center gap-3 text-gray-600">
            <GraduationCap className="w-5 h-5 text-gray-400" />
            <span>Studied at <strong>Stanford University</strong></span>
          </div>
          <div className="flex items-center gap-3 text-gray-600">
            <Home className="w-5 h-5 text-gray-400" />
            <span>Lives in <strong>{user.location || 'San Francisco, CA'}</strong></span>
          </div>
          <div className="flex items-center gap-3 text-gray-600">
            <MapPin className="w-5 h-5 text-gray-400" />
            <span>From <strong>New York, NY</strong></span>
          </div>
          <div className="flex items-center gap-3 text-gray-600">
            <Heart className="w-5 h-5 text-gray-400" />
            <span>Single</span>
          </div>
          <div className="flex items-center gap-3 text-gray-600">
            <Calendar className="w-5 h-5 text-gray-400" />
            <span>Joined <strong>January 2020</strong></span>
          </div>
          <div className="flex items-center gap-3 text-gray-600">
            <Users className="w-5 h-5 text-gray-400" />
            <span>Followed by <strong>{user.followers.toLocaleString()}</strong> people</span>
          </div>
        </div>
      </div>

      {/* Contact Info */}
      <div className="bg-white rounded-xl shadow-sm p-4">
        <h3 className="font-semibold text-gray-900 mb-4">Contact Info</h3>
        <div className="space-y-3">
          <div className="flex items-center gap-3 text-gray-600">
            <Phone className="w-5 h-5 text-gray-400" />
            <span>+1 (555) 123-4567</span>
          </div>
          <div className="flex items-center gap-3 text-gray-600">
            <Mail className="w-5 h-5 text-gray-400" />
            <span>{user.username}@email.com</span>
          </div>
          <div className="flex items-center gap-3 text-gray-600">
            <Link className="w-5 h-5 text-gray-400" />
            <a href="#" className="text-blue-500 hover:underline">www.{user.username}.com</a>
          </div>
        </div>
      </div>

      {/* Life Events */}
      <div className="bg-white rounded-xl shadow-sm p-4">
        <h3 className="font-semibold text-gray-900 mb-4">Life Events</h3>
        <div className="space-y-4">
          {lifeEvents.map((event) => (
            <div key={event.id} className="flex items-start gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <event.icon className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="font-medium text-gray-900">{event.title}</p>
                <p className="text-sm text-gray-500">{event.date}</p>
              </div>
            </div>
          ))}
          {isOwnProfile && (
            <button className="flex items-center gap-2 text-blue-500 font-medium hover:underline">
              <Plus className="w-4 h-4" />
              Add life event
            </button>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Cover Photo */}
      <div className="relative h-[350px] bg-gradient-to-b from-gray-300 to-gray-400">
        <img 
          src={profile?.cover_photo || user.coverPhoto || 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298773815_6b3b8d77.png'}
          alt="Cover"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
        {isOwnProfile && (
          <button 
            onClick={() => coverInputRef.current?.click()}
            className="absolute bottom-4 right-4 flex items-center gap-2 px-4 py-2 bg-white rounded-lg font-medium text-gray-900 hover:bg-gray-100 transition-colors shadow-lg"
          >
            <Camera className="w-5 h-5" />
            Edit cover photo
          </button>
        )}
      </div>

      {/* Profile Info */}
      <div className="max-w-5xl mx-auto px-4">
        <div className="relative -mt-8 pb-4 border-b border-gray-200">
          <div className="flex flex-col md:flex-row md:items-end gap-4">
            {/* Avatar */}
            <div className="relative">
              <img 
                src={profile?.avatar_url || user.avatar}
                alt={user.name}
                className="w-40 h-40 rounded-full object-cover border-4 border-white shadow-lg"
              />
              {isOwnProfile && (
                <button 
                  onClick={() => avatarInputRef.current?.click()}
                  className="absolute bottom-2 right-2 w-9 h-9 bg-gray-200 rounded-full flex items-center justify-center hover:bg-gray-300 transition-colors"
                >
                  <Camera className="w-5 h-5 text-gray-700" />
                </button>
              )}
              {user.isOnline && (
                <div className="absolute bottom-4 right-4 w-5 h-5 bg-green-500 rounded-full border-4 border-white" />
              )}
            </div>

            {/* Name & Stats */}
            <div className="flex-1 md:pb-4">
              <div className="flex items-center gap-2">
                <h1 className="text-3xl font-bold text-gray-900">{profile?.full_name || user.name}</h1>
                {(profile?.is_verified || user.isVerified) && (
                  <svg className="w-6 h-6 text-blue-500" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/>
                  </svg>
                )}
              </div>
              <p className="text-gray-500">@{profile?.username || user.username}</p>
              <div className="flex items-center gap-4 mt-2 text-sm">
                <span className="font-semibold text-gray-900">{(profile?.followers_count || user.followers).toLocaleString()} <span className="font-normal text-gray-500">followers</span></span>
                <span className="font-semibold text-gray-900">{(profile?.following_count || user.following).toLocaleString()} <span className="font-normal text-gray-500">following</span></span>
              </div>
              
              {/* Mutual Friends */}
              <div className="flex items-center gap-2 mt-3">
                <div className="flex -space-x-2">
                  {friends.slice(0, 5).map((friend, idx) => (
                    <img 
                      key={friend.id}
                      src={friend.avatar}
                      alt={friend.name}
                      className="w-8 h-8 rounded-full border-2 border-white object-cover"
                    />
                  ))}
                </div>
                <span className="text-sm text-gray-500">
                  {friends.length} mutual friends
                </span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 md:pb-4">
              {isOwnProfile ? (
                <>
                  <button className="flex items-center gap-2 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg font-medium hover:bg-gray-300 transition-colors">
                    <Plus className="w-4 h-4" />
                    Add to story
                  </button>
                  <button 
                    onClick={() => {
                      setEditForm({
                        full_name: profile?.full_name || '',
                        username: profile?.username || '',
                        bio: profile?.bio || '',
                        location: profile?.location || '',
                        website: profile?.website || '',
                        phone: profile?.phone || '',
                        work: '',
                        education: '',
                        relationship_status: 'Single'
                      });
                      setShowEditProfile(true);
                    }}
                    className="flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors"
                  >
                    <Edit className="w-4 h-4" />
                    Edit profile
                  </button>
                  <div className="relative">
                    <button 
                      onClick={() => setShowMoreOptions(!showMoreOptions)}
                      className="flex items-center gap-2 px-3 py-2 bg-gray-200 text-gray-700 rounded-lg font-medium hover:bg-gray-300 transition-colors"
                    >
                      <ChevronDown className="w-4 h-4" />
                    </button>
                    {showMoreOptions && <MoreOptionsDropdown />}
                  </div>
                </>
              ) : (
                <>
                  <button 
                    onClick={() => setIsFriend(!isFriend)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                      isFriend 
                        ? 'bg-gray-200 text-gray-700 hover:bg-gray-300' 
                        : 'bg-blue-500 text-white hover:bg-blue-600'
                    }`}
                  >
                    {isFriend ? <Check className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
                    {isFriend ? 'Friends' : 'Add Friend'}
                  </button>
                  <button className="flex items-center gap-2 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg font-medium hover:bg-gray-300 transition-colors">
                    <MessageCircle className="w-4 h-4" />
                    Message
                  </button>
                  <button 
                    onClick={() => setIsFollowing(!isFollowing)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                      isFollowing 
                        ? 'bg-gray-200 text-gray-700 hover:bg-gray-300' 
                        : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                    }`}
                  >
                    {isFollowing ? <Check className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
                    {isFollowing ? 'Following' : 'Follow'}
                  </button>
                  <div className="relative">
                    <button 
                      onClick={() => setShowMoreOptions(!showMoreOptions)}
                      className="w-10 h-10 bg-gray-200 rounded-lg flex items-center justify-center hover:bg-gray-300 transition-colors"
                    >
                      <MoreHorizontal className="w-5 h-5 text-gray-700" />
                    </button>
                    {showMoreOptions && <MoreOptionsDropdown />}
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Tabs */}
          <div className="flex items-center gap-1 mt-4 overflow-x-auto">
            {tabs.slice(0, 6).map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-3 font-medium rounded-lg transition-colors whitespace-nowrap ${
                  activeTab === tab.id 
                    ? 'text-blue-500 bg-blue-50' 
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                {tab.label}
              </button>
            ))}
            <button className="px-4 py-3 font-medium text-gray-600 hover:bg-gray-100 rounded-lg flex items-center gap-1">
              More
              <ChevronDown className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="py-4 grid grid-cols-1 lg:grid-cols-5 gap-4">
          {/* Left Column - About & Photos */}
          <div className="lg:col-span-2 space-y-4">
            {/* Intro */}
            <div className="bg-white rounded-xl shadow-sm p-4">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Intro</h2>
              {(profile?.bio || user.bio) && (
                <p className="text-gray-700 text-center mb-4">{profile?.bio || user.bio}</p>
              )}
              <div className="space-y-3">
                {(profile?.location || user.location) && (
                  <div className="flex items-center gap-3 text-gray-600">
                    <MapPin className="w-5 h-5 text-gray-400" />
                    <span>Lives in <strong>{profile?.location || user.location}</strong></span>
                  </div>
                )}
                <div className="flex items-center gap-3 text-gray-600">
                  <Briefcase className="w-5 h-5 text-gray-400" />
                  <span>Works at <strong>Tech Company</strong></span>
                </div>
                <div className="flex items-center gap-3 text-gray-600">
                  <GraduationCap className="w-5 h-5 text-gray-400" />
                  <span>Studied at <strong>University</strong></span>
                </div>
                <div className="flex items-center gap-3 text-gray-600">
                  <Heart className="w-5 h-5 text-gray-400" />
                  <span>Single</span>
                </div>
                <div className="flex items-center gap-3 text-gray-600">
                  <Calendar className="w-5 h-5 text-gray-400" />
                  <span>Joined {user.joinDate || 'January 2020'}</span>
                </div>
              </div>
              {isOwnProfile && (
                <>
                  <button 
                    onClick={() => setShowEditProfile(true)}
                    className="w-full mt-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors"
                  >
                    Edit details
                  </button>
                  <button className="w-full mt-2 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors">
                    Add hobbies
                  </button>
                  <button className="w-full mt-2 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors">
                    Add featured
                  </button>
                </>
              )}
            </div>

            {/* Photos */}
            <div className="bg-white rounded-xl shadow-sm p-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-gray-900">Photos</h2>
                <button className="text-blue-500 hover:underline">See all photos</button>
              </div>
              <div className="grid grid-cols-3 gap-1 rounded-lg overflow-hidden">
                {photos.map((photo, idx) => (
                  <img 
                    key={idx}
                    src={photo}
                    alt={`Photo ${idx + 1}`}
                    className="aspect-square object-cover cursor-pointer hover:opacity-90 transition-opacity"
                  />
                ))}
              </div>
            </div>

            {/* Friends */}
            <div className="bg-white rounded-xl shadow-sm p-4">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-xl font-bold text-gray-900">Friends</h2>
                  <p className="text-sm text-gray-500">{friends.length} friends</p>
                </div>
                <button className="text-blue-500 hover:underline">See all friends</button>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {friends.map((friend) => (
                  <div key={friend.id} className="text-center">
                    <img 
                      src={friend.avatar}
                      alt={friend.name}
                      className="w-full aspect-square object-cover rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
                    />
                    <p className="text-sm font-medium text-gray-900 mt-1 truncate">{friend.name}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Badges */}
            {isOwnProfile && (
              <div className="bg-white rounded-xl shadow-sm p-4">
                <h2 className="text-xl font-bold text-gray-900 mb-4">Achievements</h2>
                <div className="grid grid-cols-2 gap-3">
                  {badges.map((badge) => (
                    <div 
                      key={badge.id}
                      className="flex items-center gap-3 p-3 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg"
                    >
                      <span className="text-2xl">{badge.icon}</span>
                      <div>
                        <p className="font-medium text-gray-900 text-sm">{badge.name}</p>
                        <p className="text-xs text-gray-500">{badge.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Column - Posts */}
          <div className="lg:col-span-3 space-y-4">
            {/* Create Post */}
            {isOwnProfile && (
              <div className="bg-white rounded-xl shadow-sm p-4">
                <div className="flex items-center gap-3">
                  <img 
                    src={profile?.avatar_url || user.avatar}
                    alt={user.name}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <button className="flex-1 px-4 py-2.5 bg-gray-100 rounded-full text-left text-gray-500 hover:bg-gray-200 transition-colors">
                    What's on your mind, {(profile?.full_name || user.name).split(' ')[0]}?
                  </button>
                </div>
                <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
                  <button className="flex-1 flex items-center justify-center gap-2 py-2 rounded-lg hover:bg-gray-100 transition-colors text-gray-600">
                    <Video className="w-5 h-5 text-red-500" />
                    <span className="font-medium text-sm">Live Video</span>
                  </button>
                  <button className="flex-1 flex items-center justify-center gap-2 py-2 rounded-lg hover:bg-gray-100 transition-colors text-gray-600">
                    <Image className="w-5 h-5 text-green-500" />
                    <span className="font-medium text-sm">Photo/Video</span>
                  </button>
                  <button className="flex-1 flex items-center justify-center gap-2 py-2 rounded-lg hover:bg-gray-100 transition-colors text-gray-600">
                    <Smile className="w-5 h-5 text-yellow-500" />
                    <span className="font-medium text-sm">Feeling</span>
                  </button>
                </div>
              </div>
            )}

            {/* Posts Filter */}
            <div className="bg-white rounded-xl shadow-sm p-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">Posts</h2>
                <div className="flex items-center gap-2">
                  <button className="flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-lg font-medium text-gray-700 hover:bg-gray-200 transition-colors">
                    <Settings className="w-4 h-4" />
                    Filters
                  </button>
                  <button className="flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-lg font-medium text-gray-700 hover:bg-gray-200 transition-colors">
                    <Grid className="w-4 h-4" />
                    Manage posts
                  </button>
                </div>
              </div>
            </div>

            {/* About Tab Content */}
            {activeTab === 'about' && renderAboutTab()}

            {/* User Posts */}
            {activeTab === 'posts' && (
              userPosts.length > 0 ? (
                userPosts.map((post) => (
                  <PostCard 
                    key={post.id}
                    post={post}
                    onLike={() => {}}
                    onComment={() => {}}
                    onShare={() => {}}
                    onSave={() => {}}
                  />
                ))
              ) : (
                <div className="bg-white rounded-xl shadow-sm p-8 text-center">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Grid className="w-8 h-8 text-gray-400" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">No posts yet</h3>
                  <p className="text-gray-500">When {isOwnProfile ? 'you' : user.name} posts, they'll appear here.</p>
                </div>
              )
            )}
          </div>
        </div>
      </div>

      {/* Modals */}
      {showEditProfile && <EditProfileModal />}
      {showActivityLog && <ActivityLogModal />}
      {showArchive && <ArchiveModal />}
      {showStoryArchive && <StoryArchiveModal />}
      {showShareProfile && <ShareProfileModal />}

      {/* Hidden file inputs */}
      <input 
        ref={avatarInputRef}
        type="file"
        accept="image/*"
        onChange={handleAvatarUpload}
        className="hidden"
      />
      <input 
        ref={coverInputRef}
        type="file"
        accept="image/*"
        onChange={handleCoverUpload}
        className="hidden"
      />

      {/* Click outside to close dropdown */}
      {showMoreOptions && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setShowMoreOptions(false)}
        />
      )}
    </div>
  );
};

export default ProfilePage;
