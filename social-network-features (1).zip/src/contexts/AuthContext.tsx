import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '@/lib/supabase';

export interface UserProfile {
  id: string;
  user_id: string;
  email: string;
  full_name: string | null;
  username: string | null;
  avatar_url: string | null;
  cover_photo: string | null;
  bio: string | null;
  location: string | null;
  website: string | null;
  phone: string | null;
  followers_count: number;
  following_count: number;
  is_verified: boolean;
  is_online: boolean;
  created_at: string;
  updated_at: string;
}


export interface AuthUser {
  id: string;
  email: string;
  profile?: UserProfile;
}

interface AuthContextType {
  user: AuthUser | null;
  profile: UserProfile | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  signUp: (email: string, password: string, fullName: string) => Promise<{ error: string | null }>;
  signIn: (email: string, password: string, rememberMe?: boolean) => Promise<{ error: string | null }>;
  signInWithGoogle: () => Promise<{ error: string | null }>;
  signInWithFacebook: () => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<{ error: string | null }>;
  updateProfile: (updates: Partial<UserProfile>) => Promise<{ error: string | null }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Check for existing session on mount
  useEffect(() => {
    checkSession();
  }, []);

  const checkSession = async () => {
    try {
      // Check localStorage for remembered session
      const savedSession = localStorage.getItem('socialite_session');
      if (savedSession) {
        const sessionData = JSON.parse(savedSession);
        if (sessionData.expiresAt > Date.now()) {
          setUser(sessionData.user);
          setProfile(sessionData.profile);
          setIsLoading(false);
          return;
        } else {
          localStorage.removeItem('socialite_session');
        }
      }

      // Check sessionStorage for current session
      const currentSession = sessionStorage.getItem('socialite_session');
      if (currentSession) {
        const sessionData = JSON.parse(currentSession);
        setUser(sessionData.user);
        setProfile(sessionData.profile);
      }
    } catch (error) {
      console.error('Error checking session:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveSession = (authUser: AuthUser, userProfile: UserProfile | null, rememberMe: boolean) => {
    const sessionData = {
      user: authUser,
      profile: userProfile,
      expiresAt: rememberMe ? Date.now() + (30 * 24 * 60 * 60 * 1000) : Date.now() + (24 * 60 * 60 * 1000) // 30 days or 1 day
    };

    if (rememberMe) {
      localStorage.setItem('socialite_session', JSON.stringify(sessionData));
    } else {
      sessionStorage.setItem('socialite_session', JSON.stringify(sessionData));
    }
  };

  const signUp = async (email: string, password: string, fullName: string): Promise<{ error: string | null }> => {
    try {
      const { data, error } = await supabase.functions.invoke('auth-service', {
        body: { 
          action: 'signup',
          email,
          password,
          fullName
        }
      });

      if (error) {
        console.error('Sign up error:', error);
        // Fallback to demo mode if backend fails
        return createDemoUser(email, fullName);
      }

      if (data?.error) {
        return { error: data.error };
      }

      if (data?.success && data?.user) {
        const authUser: AuthUser = {
          id: data.user.id,
          email: data.user.email,
          profile: data.user.profile
        };

        setUser(authUser);
        setProfile(data.user.profile);
        saveSession(authUser, data.user.profile, false);

        return { error: null };
      }

      // Fallback to demo mode
      return createDemoUser(email, fullName);
    } catch (error: any) {
      console.error('Sign up error:', error);
      // Fallback to demo mode if backend fails
      return createDemoUser(email, fullName);
    }
  };

  // Demo mode fallback for when backend is unavailable
  const createDemoUser = (email: string, fullName: string): { error: string | null } => {
    const demoUserId = crypto.randomUUID();
    const demoProfile: UserProfile = {
      id: demoUserId,
      user_id: demoUserId,
      email: email,
      full_name: fullName,
      username: email.split('@')[0] + Math.floor(Math.random() * 1000),
      avatar_url: `https://ui-avatars.com/api/?name=${encodeURIComponent(fullName)}&background=1877F2&color=fff&size=200`,
      cover_photo: null,
      bio: null,
      location: null,
      website: null,
      phone: null,
      followers_count: 0,
      following_count: 0,
      is_verified: false,
      is_online: true,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    const authUser: AuthUser = {
      id: demoUserId,
      email: email,
      profile: demoProfile
    };

    setUser(authUser);
    setProfile(demoProfile);
    saveSession(authUser, demoProfile, false);

    return { error: null };
  };



  const signIn = async (email: string, password: string, rememberMe: boolean = false): Promise<{ error: string | null }> => {
    try {
      const { data, error } = await supabase.functions.invoke('auth-service', {
        body: { 
          action: 'signin',
          email,
          password
        }
      });

      if (error) {
        console.error('Sign in error:', error);
        return { error: error.message || 'An error occurred during sign in' };
      }

      if (data?.error) {
        return { error: data.error };
      }

      if (data?.success && data?.user) {
        const authUser: AuthUser = {
          id: data.user.id,
          email: data.user.email,
          profile: data.user.profile
        };

        setUser(authUser);
        setProfile(data.user.profile);
        saveSession(authUser, data.user.profile, rememberMe);

        return { error: null };
      }

      return { error: 'Invalid email or password' };
    } catch (error: any) {
      console.error('Sign in error:', error);
      return { error: error.message || 'An error occurred during sign in' };
    }
  };

  const signInWithGoogle = async (): Promise<{ error: string | null }> => {
    try {
      // For demo purposes, create a mock Google user
      const mockGoogleUser = {
        email: `google_user_${Date.now()}@gmail.com`,
        fullName: 'Google User'
      };

      // Use the auth service to create the account
      const { data, error } = await supabase.functions.invoke('auth-service', {
        body: { 
          action: 'signup',
          email: mockGoogleUser.email,
          password: crypto.randomUUID(), // Random password for OAuth users
          fullName: mockGoogleUser.fullName
        }
      });

      if (error && !error.message?.includes('already exists')) {
        return { error: 'Failed to sign in with Google' };
      }

      // If account exists, try to sign in
      if (data?.error?.includes('already exists')) {
        // In real app, OAuth would handle this
        return { error: 'Google sign-in is currently in demo mode' };
      }

      if (data?.success && data?.user) {
        const authUser: AuthUser = {
          id: data.user.id,
          email: data.user.email,
          profile: data.user.profile
        };

        setUser(authUser);
        setProfile(data.user.profile);
        saveSession(authUser, data.user.profile, true);

        return { error: null };
      }

      return { error: 'Failed to sign in with Google' };
    } catch (error: any) {
      console.error('Google sign in error:', error);
      return { error: 'Failed to sign in with Google' };
    }
  };

  const signInWithFacebook = async (): Promise<{ error: string | null }> => {
    try {
      // For demo purposes, create a mock Facebook user
      const mockFacebookUser = {
        email: `fb_user_${Date.now()}@facebook.com`,
        fullName: 'Facebook User'
      };

      // Use the auth service to create the account
      const { data, error } = await supabase.functions.invoke('auth-service', {
        body: { 
          action: 'signup',
          email: mockFacebookUser.email,
          password: crypto.randomUUID(), // Random password for OAuth users
          fullName: mockFacebookUser.fullName
        }
      });

      if (error && !error.message?.includes('already exists')) {
        return { error: 'Failed to sign in with Facebook' };
      }

      if (data?.success && data?.user) {
        const authUser: AuthUser = {
          id: data.user.id,
          email: data.user.email,
          profile: data.user.profile
        };

        setUser(authUser);
        setProfile(data.user.profile);
        saveSession(authUser, data.user.profile, true);

        return { error: null };
      }

      return { error: 'Failed to sign in with Facebook' };
    } catch (error: any) {
      console.error('Facebook sign in error:', error);
      return { error: 'Failed to sign in with Facebook' };
    }
  };

  const signOut = async () => {
    try {
      if (user) {
        await supabase.functions.invoke('auth-service', {
          body: { 
            action: 'signout',
            userId: user.id
          }
        });
      }
    } catch (error) {
      console.error('Sign out error:', error);
    } finally {
      setUser(null);
      setProfile(null);
      localStorage.removeItem('socialite_session');
      sessionStorage.removeItem('socialite_session');
    }
  };

  const resetPassword = async (email: string): Promise<{ error: string | null }> => {
    try {
      const { data, error } = await supabase.functions.invoke('auth-service', {
        body: { 
          action: 'reset_password',
          email
        }
      });

      if (error) {
        return { error: error.message || 'Failed to send password reset email' };
      }

      if (data?.error) {
        return { error: data.error };
      }

      return { error: null };
    } catch (error: any) {
      console.error('Password reset error:', error);
      return { error: 'Failed to send password reset email' };
    }
  };

  const updateProfile = async (updates: Partial<UserProfile>): Promise<{ error: string | null }> => {
    if (!user) {
      return { error: 'Not authenticated' };
    }

    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('user_id', user.id)
        .select()
        .single();

      if (error) {
        return { error: error.message };
      }

      setProfile(data);
      
      // Update session
      const authUser: AuthUser = { ...user, profile: data };
      setUser(authUser);
      
      const savedLocal = localStorage.getItem('socialite_session');
      const savedSession = sessionStorage.getItem('socialite_session');
      
      if (savedLocal) {
        const sessionData = JSON.parse(savedLocal);
        sessionData.user = authUser;
        sessionData.profile = data;
        localStorage.setItem('socialite_session', JSON.stringify(sessionData));
      }
      
      if (savedSession) {
        const sessionData = JSON.parse(savedSession);
        sessionData.user = authUser;
        sessionData.profile = data;
        sessionStorage.setItem('socialite_session', JSON.stringify(sessionData));
      }

      return { error: null };
    } catch (error: any) {
      console.error('Update profile error:', error);
      return { error: 'Failed to update profile' };
    }
  };

  const value: AuthContextType = {
    user,
    profile,
    isLoading,
    isAuthenticated: !!user,
    signUp,
    signIn,
    signInWithGoogle,
    signInWithFacebook,
    signOut,
    resetPassword,
    updateProfile
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
