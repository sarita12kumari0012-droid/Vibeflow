import React, { useState } from 'react';
import { 
  ArrowLeft, Users, FileText, Flag, Settings, BarChart3, Shield, 
  Ban, CheckCircle, XCircle, Eye, Trash2, Edit, Search, Filter,
  TrendingUp, TrendingDown, DollarSign, MessageSquare, Image,
  Video, AlertTriangle, Clock, Globe, Lock, UserX, UserCheck,
  Mail, Bell, Database, Server, Activity, Zap, Crown, Gift,
  ChevronDown, ChevronRight, MoreHorizontal, Download, Upload,
  RefreshCw, Calendar, PieChart, LayoutDashboard, Megaphone,
  CreditCard, HelpCircle, LogOut, Key, Smartphone, Monitor
} from 'lucide-react';

interface AdminPanelProps {
  onBack: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ onBack }) => {
  const [activeSection, setActiveSection] = useState('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);

  // Mock data
  const stats = {
    totalUsers: 125847,
    activeUsers: 89234,
    newUsersToday: 1247,
    totalPosts: 892456,
    totalReports: 234,
    pendingReports: 45,
    revenue: 45678,
    engagement: 78.5
  };

  const users = [
    { id: '1', name: 'John Doe', email: 'john@example.com', status: 'active', role: 'user', posts: 156, joined: '2024-01-15', avatar: 'https://i.pravatar.cc/150?img=1', verified: true },
    { id: '2', name: 'Jane Smith', email: 'jane@example.com', status: 'active', role: 'creator', posts: 892, joined: '2023-11-20', avatar: 'https://i.pravatar.cc/150?img=2', verified: true },
    { id: '3', name: 'Bob Wilson', email: 'bob@example.com', status: 'suspended', role: 'user', posts: 45, joined: '2024-03-10', avatar: 'https://i.pravatar.cc/150?img=3', verified: false },
    { id: '4', name: 'Alice Brown', email: 'alice@example.com', status: 'active', role: 'moderator', posts: 234, joined: '2023-08-05', avatar: 'https://i.pravatar.cc/150?img=4', verified: true },
    { id: '5', name: 'Charlie Davis', email: 'charlie@example.com', status: 'banned', role: 'user', posts: 12, joined: '2024-02-28', avatar: 'https://i.pravatar.cc/150?img=5', verified: false },
    { id: '6', name: 'Emma Wilson', email: 'emma@example.com', status: 'active', role: 'admin', posts: 567, joined: '2023-05-15', avatar: 'https://i.pravatar.cc/150?img=6', verified: true },
  ];

  const reports = [
    { id: '1', type: 'spam', reporter: 'John Doe', reported: 'Spam Account', content: 'Posting promotional content repeatedly', status: 'pending', date: '2024-12-10', priority: 'high' },
    { id: '2', type: 'harassment', reporter: 'Jane Smith', reported: 'User123', content: 'Sending threatening messages', status: 'pending', date: '2024-12-09', priority: 'high' },
    { id: '3', type: 'inappropriate', reporter: 'Bob Wilson', reported: 'RandomUser', content: 'Posting inappropriate images', status: 'resolved', date: '2024-12-08', priority: 'medium' },
    { id: '4', type: 'fake_account', reporter: 'Alice Brown', reported: 'FakeProfile', content: 'Impersonating a celebrity', status: 'pending', date: '2024-12-07', priority: 'medium' },
    { id: '5', type: 'hate_speech', reporter: 'Charlie Davis', reported: 'HateUser', content: 'Posting hateful content', status: 'resolved', date: '2024-12-06', priority: 'high' },
  ];

  const contentItems = [
    { id: '1', type: 'post', author: 'John Doe', content: 'Check out my new photo!', likes: 234, comments: 45, reports: 0, status: 'active', date: '2024-12-10' },
    { id: '2', type: 'video', author: 'Jane Smith', content: 'Tutorial: How to cook pasta', likes: 1892, comments: 234, reports: 2, status: 'flagged', date: '2024-12-09' },
    { id: '3', type: 'reel', author: 'Bob Wilson', content: 'Funny cat compilation', likes: 5678, comments: 890, reports: 0, status: 'active', date: '2024-12-08' },
    { id: '4', type: 'story', author: 'Alice Brown', content: 'My day at the beach', likes: 456, comments: 0, reports: 1, status: 'under_review', date: '2024-12-07' },
  ];

  const menuItems = [
    { id: 'dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { id: 'users', icon: Users, label: 'User Management' },
    { id: 'content', icon: FileText, label: 'Content Moderation' },
    { id: 'reports', icon: Flag, label: 'Reports & Appeals' },
    { id: 'analytics', icon: BarChart3, label: 'Analytics' },
    { id: 'monetization', icon: DollarSign, label: 'Monetization' },
    { id: 'ads', icon: Megaphone, label: 'Ad Management' },
    { id: 'notifications', icon: Bell, label: 'Notifications' },
    { id: 'security', icon: Shield, label: 'Security' },
    { id: 'settings', icon: Settings, label: 'App Settings' },
  ];

  const renderDashboard = () => (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Total Users</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalUsers.toLocaleString()}</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
          </div>
          <div className="flex items-center gap-1 mt-2 text-sm">
            <TrendingUp className="w-4 h-4 text-green-500" />
            <span className="text-green-500 font-medium">+12.5%</span>
            <span className="text-gray-500">vs last month</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Active Users</p>
              <p className="text-2xl font-bold text-gray-900">{stats.activeUsers.toLocaleString()}</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
              <Activity className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <div className="flex items-center gap-1 mt-2 text-sm">
            <TrendingUp className="w-4 h-4 text-green-500" />
            <span className="text-green-500 font-medium">+8.3%</span>
            <span className="text-gray-500">vs last month</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Total Posts</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalPosts.toLocaleString()}</p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
              <FileText className="w-6 h-6 text-purple-600" />
            </div>
          </div>
          <div className="flex items-center gap-1 mt-2 text-sm">
            <TrendingUp className="w-4 h-4 text-green-500" />
            <span className="text-green-500 font-medium">+23.1%</span>
            <span className="text-gray-500">vs last month</span>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Revenue</p>
              <p className="text-2xl font-bold text-gray-900">${stats.revenue.toLocaleString()}</p>
            </div>
            <div className="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
          <div className="flex items-center gap-1 mt-2 text-sm">
            <TrendingUp className="w-4 h-4 text-green-500" />
            <span className="text-green-500 font-medium">+15.7%</span>
            <span className="text-gray-500">vs last month</span>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-xl p-6 shadow-sm">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          <button className="flex flex-col items-center gap-2 p-4 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors">
            <UserCheck className="w-6 h-6 text-blue-600" />
            <span className="text-sm font-medium text-blue-700">Verify User</span>
          </button>
          <button className="flex flex-col items-center gap-2 p-4 bg-red-50 rounded-xl hover:bg-red-100 transition-colors">
            <Ban className="w-6 h-6 text-red-600" />
            <span className="text-sm font-medium text-red-700">Ban User</span>
          </button>
          <button className="flex flex-col items-center gap-2 p-4 bg-yellow-50 rounded-xl hover:bg-yellow-100 transition-colors">
            <Flag className="w-6 h-6 text-yellow-600" />
            <span className="text-sm font-medium text-yellow-700">Review Reports</span>
          </button>
          <button className="flex flex-col items-center gap-2 p-4 bg-green-50 rounded-xl hover:bg-green-100 transition-colors">
            <Megaphone className="w-6 h-6 text-green-600" />
            <span className="text-sm font-medium text-green-700">Send Broadcast</span>
          </button>
          <button className="flex flex-col items-center gap-2 p-4 bg-purple-50 rounded-xl hover:bg-purple-100 transition-colors">
            <Download className="w-6 h-6 text-purple-600" />
            <span className="text-sm font-medium text-purple-700">Export Data</span>
          </button>
          <button className="flex flex-col items-center gap-2 p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
            <Settings className="w-6 h-6 text-gray-600" />
            <span className="text-sm font-medium text-gray-700">Settings</span>
          </button>
        </div>
      </div>

      {/* Recent Activity & Pending Reports */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Pending Reports</h3>
            <span className="px-3 py-1 bg-red-100 text-red-600 text-sm font-medium rounded-full">{stats.pendingReports}</span>
          </div>
          <div className="space-y-3">
            {reports.filter(r => r.status === 'pending').slice(0, 4).map((report) => (
              <div key={report.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  report.priority === 'high' ? 'bg-red-100' : 'bg-yellow-100'
                }`}>
                  <AlertTriangle className={`w-5 h-5 ${
                    report.priority === 'high' ? 'text-red-600' : 'text-yellow-600'
                  }`} />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900 text-sm">{report.type.replace('_', ' ').toUpperCase()}</p>
                  <p className="text-xs text-gray-500">Reported: {report.reported}</p>
                </div>
                <button className="px-3 py-1.5 bg-blue-500 text-white text-xs font-medium rounded-lg hover:bg-blue-600">
                  Review
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">New Users Today</h3>
            <span className="px-3 py-1 bg-green-100 text-green-600 text-sm font-medium rounded-full">+{stats.newUsersToday}</span>
          </div>
          <div className="space-y-3">
            {users.slice(0, 4).map((user) => (
              <div key={user.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full object-cover" />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-gray-900 text-sm">{user.name}</p>
                    {user.verified && (
                      <CheckCircle className="w-4 h-4 text-blue-500" />
                    )}
                  </div>
                  <p className="text-xs text-gray-500">{user.email}</p>
                </div>
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                  user.role === 'admin' ? 'bg-purple-100 text-purple-600' :
                  user.role === 'moderator' ? 'bg-blue-100 text-blue-600' :
                  user.role === 'creator' ? 'bg-green-100 text-green-600' :
                  'bg-gray-100 text-gray-600'
                }`}>
                  {user.role}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Charts Placeholder */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">User Growth</h3>
          <div className="h-64 bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <BarChart3 className="w-12 h-12 text-blue-400 mx-auto mb-2" />
              <p className="text-gray-500">User growth chart</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Engagement Rate</h3>
          <div className="h-64 bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <PieChart className="w-12 h-12 text-green-400 mx-auto mb-2" />
              <p className="text-gray-500">Engagement breakdown</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderUserManagement = () => (
    <div className="space-y-6">
      {/* Search & Filters */}
      <div className="bg-white rounded-xl p-4 shadow-sm">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search users by name, email, or ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="flex gap-2">
            <select className="px-4 py-2.5 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option>All Status</option>
              <option>Active</option>
              <option>Suspended</option>
              <option>Banned</option>
            </select>
            <select className="px-4 py-2.5 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option>All Roles</option>
              <option>Admin</option>
              <option>Moderator</option>
              <option>Creator</option>
              <option>User</option>
            </select>
            <button className="px-4 py-2.5 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 flex items-center gap-2">
              <Filter className="w-4 h-4" />
              Filter
            </button>
          </div>
        </div>
      </div>

      {/* Bulk Actions */}
      {selectedUsers.length > 0 && (
        <div className="bg-blue-50 rounded-xl p-4 flex items-center justify-between">
          <span className="text-blue-700 font-medium">{selectedUsers.length} users selected</span>
          <div className="flex gap-2">
            <button className="px-4 py-2 bg-yellow-500 text-white rounded-lg text-sm font-medium hover:bg-yellow-600">
              Suspend Selected
            </button>
            <button className="px-4 py-2 bg-red-500 text-white rounded-lg text-sm font-medium hover:bg-red-600">
              Ban Selected
            </button>
            <button className="px-4 py-2 bg-gray-500 text-white rounded-lg text-sm font-medium hover:bg-gray-600">
              Clear Selection
            </button>
          </div>
        </div>
      )}

      {/* Users Table */}
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-4 py-3 text-left">
                  <input type="checkbox" className="rounded" />
                </th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">User</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Role</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Status</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Posts</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Joined</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {users.map((user) => (
                <tr key={user.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3">
                    <input 
                      type="checkbox" 
                      className="rounded"
                      checked={selectedUsers.includes(user.id)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedUsers([...selectedUsers, user.id]);
                        } else {
                          setSelectedUsers(selectedUsers.filter(id => id !== user.id));
                        }
                      }}
                    />
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full object-cover" />
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-medium text-gray-900">{user.name}</p>
                          {user.verified && <CheckCircle className="w-4 h-4 text-blue-500" />}
                        </div>
                        <p className="text-sm text-gray-500">{user.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      user.role === 'admin' ? 'bg-purple-100 text-purple-600' :
                      user.role === 'moderator' ? 'bg-blue-100 text-blue-600' :
                      user.role === 'creator' ? 'bg-green-100 text-green-600' :
                      'bg-gray-100 text-gray-600'
                    }`}>
                      {user.role}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      user.status === 'active' ? 'bg-green-100 text-green-600' :
                      user.status === 'suspended' ? 'bg-yellow-100 text-yellow-600' :
                      'bg-red-100 text-red-600'
                    }`}>
                      {user.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-gray-600">{user.posts}</td>
                  <td className="px-4 py-3 text-gray-600">{user.joined}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <button className="p-2 hover:bg-gray-100 rounded-lg" title="View Profile">
                        <Eye className="w-4 h-4 text-gray-500" />
                      </button>
                      <button className="p-2 hover:bg-gray-100 rounded-lg" title="Edit User">
                        <Edit className="w-4 h-4 text-gray-500" />
                      </button>
                      <button className="p-2 hover:bg-gray-100 rounded-lg" title="Ban User">
                        <Ban className="w-4 h-4 text-red-500" />
                      </button>
                      <button className="p-2 hover:bg-gray-100 rounded-lg" title="More Actions">
                        <MoreHorizontal className="w-4 h-4 text-gray-500" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 flex items-center justify-between">
          <p className="text-sm text-gray-500">Showing 1-6 of {stats.totalUsers.toLocaleString()} users</p>
          <div className="flex gap-2">
            <button className="px-3 py-1.5 border border-gray-200 rounded-lg text-sm hover:bg-gray-100">Previous</button>
            <button className="px-3 py-1.5 bg-blue-500 text-white rounded-lg text-sm">1</button>
            <button className="px-3 py-1.5 border border-gray-200 rounded-lg text-sm hover:bg-gray-100">2</button>
            <button className="px-3 py-1.5 border border-gray-200 rounded-lg text-sm hover:bg-gray-100">3</button>
            <button className="px-3 py-1.5 border border-gray-200 rounded-lg text-sm hover:bg-gray-100">Next</button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderContentModeration = () => (
    <div className="space-y-6">
      {/* Content Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <FileText className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">892K</p>
              <p className="text-sm text-gray-500">Total Posts</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-yellow-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">156</p>
              <p className="text-sm text-gray-500">Flagged Content</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
              <Trash2 className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">234</p>
              <p className="text-sm text-gray-500">Removed Today</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">98.5%</p>
              <p className="text-sm text-gray-500">Clean Rate</p>
            </div>
          </div>
        </div>
      </div>

      {/* Content List */}
      <div className="bg-white rounded-xl shadow-sm">
        <div className="p-4 border-b border-gray-200 flex items-center justify-between">
          <h3 className="font-semibold text-gray-900">Content Review Queue</h3>
          <div className="flex gap-2">
            <select className="px-3 py-2 border border-gray-200 rounded-lg text-sm">
              <option>All Types</option>
              <option>Posts</option>
              <option>Videos</option>
              <option>Reels</option>
              <option>Stories</option>
            </select>
            <select className="px-3 py-2 border border-gray-200 rounded-lg text-sm">
              <option>All Status</option>
              <option>Active</option>
              <option>Flagged</option>
              <option>Under Review</option>
            </select>
          </div>
        </div>
        <div className="divide-y divide-gray-100">
          {contentItems.map((item) => (
            <div key={item.id} className="p-4 hover:bg-gray-50">
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                  item.type === 'post' ? 'bg-blue-100' :
                  item.type === 'video' ? 'bg-red-100' :
                  item.type === 'reel' ? 'bg-pink-100' :
                  'bg-purple-100'
                }`}>
                  {item.type === 'post' ? <FileText className="w-6 h-6 text-blue-600" /> :
                   item.type === 'video' ? <Video className="w-6 h-6 text-red-600" /> :
                   item.type === 'reel' ? <Video className="w-6 h-6 text-pink-600" /> :
                   <Image className="w-6 h-6 text-purple-600" />}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <p className="font-medium text-gray-900">{item.author}</p>
                    <span className="text-xs text-gray-400">•</span>
                    <span className="text-xs text-gray-500">{item.date}</span>
                    <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${
                      item.status === 'active' ? 'bg-green-100 text-green-600' :
                      item.status === 'flagged' ? 'bg-yellow-100 text-yellow-600' :
                      'bg-blue-100 text-blue-600'
                    }`}>
                      {item.status.replace('_', ' ')}
                    </span>
                  </div>
                  <p className="text-gray-600 text-sm mb-2">{item.content}</p>
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <span>{item.likes} likes</span>
                    <span>{item.comments} comments</span>
                    {item.reports > 0 && (
                      <span className="text-red-500">{item.reports} reports</span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button className="p-2 hover:bg-green-100 rounded-lg" title="Approve">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  </button>
                  <button className="p-2 hover:bg-red-100 rounded-lg" title="Remove">
                    <XCircle className="w-5 h-5 text-red-600" />
                  </button>
                  <button className="p-2 hover:bg-gray-100 rounded-lg" title="View">
                    <Eye className="w-5 h-5 text-gray-500" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderReports = () => (
    <div className="space-y-6">
      {/* Report Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-4 shadow-sm">
          <p className="text-sm text-gray-500">Total Reports</p>
          <p className="text-2xl font-bold text-gray-900">{stats.totalReports}</p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-sm">
          <p className="text-sm text-gray-500">Pending</p>
          <p className="text-2xl font-bold text-yellow-600">{stats.pendingReports}</p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-sm">
          <p className="text-sm text-gray-500">Resolved Today</p>
          <p className="text-2xl font-bold text-green-600">23</p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-sm">
          <p className="text-sm text-gray-500">Avg Response Time</p>
          <p className="text-2xl font-bold text-blue-600">2.4h</p>
        </div>
      </div>

      {/* Reports List */}
      <div className="bg-white rounded-xl shadow-sm">
        <div className="p-4 border-b border-gray-200">
          <h3 className="font-semibold text-gray-900">Report Queue</h3>
        </div>
        <div className="divide-y divide-gray-100">
          {reports.map((report) => (
            <div key={report.id} className="p-4 hover:bg-gray-50">
              <div className="flex items-start gap-4">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  report.priority === 'high' ? 'bg-red-100' : 'bg-yellow-100'
                }`}>
                  <Flag className={`w-5 h-5 ${
                    report.priority === 'high' ? 'text-red-600' : 'text-yellow-600'
                  }`} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs font-medium rounded">
                      {report.type.replace('_', ' ').toUpperCase()}
                    </span>
                    <span className={`px-2 py-0.5 text-xs font-medium rounded ${
                      report.status === 'pending' ? 'bg-yellow-100 text-yellow-600' : 'bg-green-100 text-green-600'
                    }`}>
                      {report.status}
                    </span>
                    <span className={`px-2 py-0.5 text-xs font-medium rounded ${
                      report.priority === 'high' ? 'bg-red-100 text-red-600' : 'bg-orange-100 text-orange-600'
                    }`}>
                      {report.priority} priority
                    </span>
                  </div>
                  <p className="text-gray-900 font-medium">Reported: {report.reported}</p>
                  <p className="text-gray-600 text-sm">{report.content}</p>
                  <p className="text-gray-400 text-xs mt-1">Reported by {report.reporter} on {report.date}</p>
                </div>
                <div className="flex items-center gap-2">
                  <button className="px-3 py-1.5 bg-blue-500 text-white text-sm font-medium rounded-lg hover:bg-blue-600">
                    Review
                  </button>
                  <button className="px-3 py-1.5 bg-gray-100 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-200">
                    Dismiss
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* General Settings */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">General Settings</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">App Name</label>
              <input type="text" defaultValue="Socialite" className="w-full px-4 py-2 border border-gray-200 rounded-lg" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">App Description</label>
              <textarea rows={3} defaultValue="Connect with friends and the world around you" className="w-full px-4 py-2 border border-gray-200 rounded-lg" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Support Email</label>
              <input type="email" defaultValue="support@socialite.com" className="w-full px-4 py-2 border border-gray-200 rounded-lg" />
            </div>
          </div>
        </div>

        {/* Security Settings */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Security Settings</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                <Shield className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="font-medium text-gray-900">Two-Factor Authentication</p>
                  <p className="text-sm text-gray-500">Require 2FA for admin accounts</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" defaultChecked className="sr-only peer" />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                <Lock className="w-5 h-5 text-green-600" />
                <div>
                  <p className="font-medium text-gray-900">Content Encryption</p>
                  <p className="text-sm text-gray-500">End-to-end encryption for messages</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" defaultChecked className="sr-only peer" />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                <Key className="w-5 h-5 text-purple-600" />
                <div>
                  <p className="font-medium text-gray-900">API Rate Limiting</p>
                  <p className="text-sm text-gray-500">Limit API requests per user</p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" defaultChecked className="sr-only peer" />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
          </div>
        </div>

        {/* Notification Settings */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Push Notifications</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium text-gray-900">New User Alerts</p>
                <p className="text-sm text-gray-500">Get notified when new users sign up</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" defaultChecked className="sr-only peer" />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div>
                <p className="font-medium text-gray-900">Report Alerts</p>
                <p className="text-sm text-gray-500">Get notified for high-priority reports</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" defaultChecked className="sr-only peer" />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
          </div>
        </div>

        {/* Maintenance */}
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Maintenance</h3>
          <div className="space-y-4">
            <button className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <div className="flex items-center gap-3">
                <Database className="w-5 h-5 text-blue-600" />
                <span className="font-medium text-gray-900">Backup Database</span>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
            <button className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <div className="flex items-center gap-3">
                <RefreshCw className="w-5 h-5 text-green-600" />
                <span className="font-medium text-gray-900">Clear Cache</span>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
            <button className="w-full flex items-center justify-between p-3 bg-red-50 rounded-lg hover:bg-red-100 transition-colors">
              <div className="flex items-center gap-3">
                <AlertTriangle className="w-5 h-5 text-red-600" />
                <span className="font-medium text-red-700">Maintenance Mode</span>
              </div>
              <ChevronRight className="w-5 h-5 text-red-400" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard': return renderDashboard();
      case 'users': return renderUserManagement();
      case 'content': return renderContentModeration();
      case 'reports': return renderReports();
      case 'settings': return renderSettings();
      default: return (
        <div className="bg-white rounded-xl shadow-sm p-8 text-center">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Settings className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">{activeSection.charAt(0).toUpperCase() + activeSection.slice(1)}</h3>
          <p className="text-gray-500">This section is under development.</p>
        </div>
      );
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Top Bar */}
      <div className="fixed top-0 left-0 right-0 h-14 bg-white border-b border-gray-200 flex items-center justify-between px-4 z-50">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-gray-100 rounded-lg">
            <ArrowLeft className="w-5 h-5 text-gray-600" />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-red-500 to-pink-500 rounded-lg flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-gray-900">Admin Panel</span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button className="p-2 hover:bg-gray-100 rounded-lg relative">
            <Bell className="w-5 h-5 text-gray-600" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
          </button>
          <button className="p-2 hover:bg-gray-100 rounded-lg">
            <Settings className="w-5 h-5 text-gray-600" />
          </button>
          <img src="https://i.pravatar.cc/150?img=1" alt="Admin" className="w-8 h-8 rounded-full" />
        </div>
      </div>

      <div className="flex pt-14">
        {/* Sidebar */}
        <aside className="w-64 h-[calc(100vh-56px)] bg-white border-r border-gray-200 fixed left-0 top-14 overflow-y-auto">
          <nav className="p-4 space-y-1">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveSection(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                  activeSection === item.id
                    ? 'bg-blue-50 text-blue-600'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
                {item.id === 'reports' && stats.pendingReports > 0 && (
                  <span className="ml-auto px-2 py-0.5 bg-red-100 text-red-600 text-xs font-medium rounded-full">
                    {stats.pendingReports}
                  </span>
                )}
              </button>
            ))}
          </nav>

          <div className="p-4 border-t border-gray-200">
            <button className="w-full flex items-center gap-3 px-3 py-2.5 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
              <LogOut className="w-5 h-5" />
              <span className="font-medium">Logout</span>
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 ml-64 p-6">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-gray-900">
              {menuItems.find(m => m.id === activeSection)?.label || 'Dashboard'}
            </h1>
            <p className="text-gray-500">Manage your application settings and users</p>
          </div>
          {renderContent()}
        </main>
      </div>
    </div>
  );
};

export default AdminPanel;
