import React, { useState } from 'react';
import Header from './Header';
import Stories from './Stories';
import PostCard from './PostCard';
import CreatePost from './CreatePost';
import { LeftSidebar, RightSidebar } from './Sidebar';
import MessagesPanel from './MessagesPanel';
import NotificationsPanel from './NotificationsPanel';
import ProfilePage from './ProfilePage';
import GroupsPage from './GroupsPage';
import FriendsPage from './FriendsPage';
import WatchPage from './WatchPage';
import MarketplacePage from './MarketplacePage';
import StoryCreator from './StoryCreator';
import MoodFilter from './MoodFilter';
import VirtualHangout from './VirtualHangout';
import AuthModal from './AuthModal';
import AIAssistant from './AIAssistant';
import MonetizationPanel from './MonetizationPanel';
import AnalyticsDashboard from './AnalyticsDashboard';
import AdMonetization from './AdMonetization';
import ReelsPage from './ReelsPage';
import EventsPage from './EventsPage';
import GamingPage from './GamingPage';
import SettingsPage from './SettingsPage';
import SavedPostsPage from './SavedPostsPage';
import MemoriesPage from './MemoriesPage';
import PagesPage from './PagesPage';
import NearbyFriendsPage from './NearbyFriendsPage';
import AdminPanel from './AdminPanel';
import { useAuth } from '@/contexts/AuthContext';
import { posts as initialPosts, Post, currentUser } from '../data/socialData';
import { Sparkles, Video, RefreshCw, Bot, DollarSign, Zap, BarChart3, Film, Gamepad2, Calendar, Heart } from 'lucide-react';

const AppLayout: React.FC = () => {
  const { isAuthenticated, profile, isLoading: authLoading } = useAuth();
  const [activeTab, setActiveTab] = useState('home');
  const [showMessages, setShowMessages] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [showStoryCreator, setShowStoryCreator] = useState(false);
  const [showMoodFilter, setShowMoodFilter] = useState(false);
  const [showVirtualHangout, setShowVirtualHangout] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showAIAssistant, setShowAIAssistant] = useState(false);
  const [showMonetization, setShowMonetization] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [showAdMonetization, setShowAdMonetization] = useState(false);
  const [authModalView, setAuthModalView] = useState<'login' | 'signup' | 'reset'>('login');
  const [currentMood, setCurrentMood] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [posts, setPosts] = useState<Post[]>(initialPosts);
  const [isLoading, setIsLoading] = useState(false);

  // Get display user (authenticated user or demo user)
  const displayUser = isAuthenticated && profile ? {
    id: profile.user_id,
    name: profile.full_name || 'User',
    username: profile.username || 'user',
    avatar: profile.avatar_url || currentUser.avatar,
    bio: profile.bio || currentUser.bio,
    location: profile.location || currentUser.location,
    followers: currentUser.followers,
    following: currentUser.following,
    isOnline: true,
    isVerified: false
  } : currentUser;

  // Handle new post creation
  const handleCreatePost = (content: string, images: string[], privacy: string) => {
    if (!isAuthenticated) {
      setShowAuthModal(true);
      return;
    }

    const newPost: Post = {
      id: `post-${Date.now()}`,
      user: displayUser,
      content,
      images: images.length > 0 ? images : undefined,
      timestamp: 'Just now',
      reactions: [
        { type: 'like', count: 0, userReacted: false },
        { type: 'love', count: 0, userReacted: false }
      ],
      comments: [],
      shares: 0,
      isLiked: false,
      isSaved: false,
      privacy: privacy as 'public' | 'friends' | 'private'
    };
    setPosts([newPost, ...posts]);
    setShowCreatePost(false);
  };

  // Handle AI content insertion
  const handleAIInsertContent = (content: string) => {
    setShowCreatePost(true);
  };

  // Handle post interactions
  const handleLike = (postId: string) => {
    if (!isAuthenticated) {
      setShowAuthModal(true);
      return;
    }

    setPosts(posts.map(post => {
      if (post.id === postId) {
        const isCurrentlyLiked = post.isLiked;
        return {
          ...post,
          isLiked: !isCurrentlyLiked,
          reactions: post.reactions.map(r => 
            r.type === 'like' 
              ? { ...r, count: isCurrentlyLiked ? r.count - 1 : r.count + 1, userReacted: !isCurrentlyLiked }
              : r
          )
        };
      }
      return post;
    }));
  };

  const handleComment = (postId: string, comment: string) => {
    if (!isAuthenticated) {
      setShowAuthModal(true);
      return;
    }

    setPosts(posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          comments: [
            ...post.comments,
            {
              id: `comment-${Date.now()}`,
              user: displayUser,
              content: comment,
              timestamp: 'Just now',
              likes: 0
            }
          ]
        };
      }
      return post;
    }));
  };

  const handleShare = (postId: string) => {
    if (!isAuthenticated) {
      setShowAuthModal(true);
      return;
    }

    setPosts(posts.map(post => {
      if (post.id === postId) {
        return { ...post, shares: post.shares + 1 };
      }
      return post;
    }));
  };

  const handleSave = (postId: string) => {
    if (!isAuthenticated) {
      setShowAuthModal(true);
      return;
    }

    setPosts(posts.map(post => {
      if (post.id === postId) {
        return { ...post, isSaved: !post.isSaved };
      }
      return post;
    }));
  };

  // Handle story creation
  const handleCreateStory = (story: { media: string; text?: string }) => {
    if (!isAuthenticated) {
      setShowAuthModal(true);
      return;
    }
    console.log('Story created:', story);
    setShowStoryCreator(false);
  };

  // Handle opening auth modal
  const handleOpenAuth = (view: 'login' | 'signup' | 'reset' = 'login') => {
    setAuthModalView(view);
    setShowAuthModal(true);
  };

  // Handle actions that require auth
  const handleAuthRequired = (action: () => void) => {
    if (!isAuthenticated) {
      setShowAuthModal(true);
      return;
    }
    action();
  };

  // Simulate loading more posts
  const loadMorePosts = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  };

  // Filter posts based on search
  const filteredPosts = posts.filter(post => 
    post.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
    post.user.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Render main content based on active tab
  const renderContent = () => {
    switch (activeTab) {
      case 'profile':
        return <ProfilePage onBack={() => setActiveTab('home')} />;
      case 'groups':
        return <GroupsPage onBack={() => setActiveTab('home')} />;
      case 'friends':
        return <FriendsPage onBack={() => setActiveTab('home')} />;
      case 'watch':
        return <WatchPage onBack={() => setActiveTab('home')} />;
      case 'marketplace':
        return <MarketplacePage onBack={() => setActiveTab('home')} />;
      case 'reels':
        return <ReelsPage onBack={() => setActiveTab('home')} />;
      case 'events':
        return <EventsPage onBack={() => setActiveTab('home')} />;
      case 'gaming':
        return <GamingPage onBack={() => setActiveTab('home')} />;
      case 'settings':
        return <SettingsPage onBack={() => setActiveTab('home')} />;
      case 'saved':
        return <SavedPostsPage onBack={() => setActiveTab('home')} />;
      case 'memories':
        return <MemoriesPage onBack={() => setActiveTab('home')} />;
      case 'pages':
        return <PagesPage onBack={() => setActiveTab('home')} />;
      case 'nearby':
        return <NearbyFriendsPage onBack={() => setActiveTab('home')} />;
      case 'admin':
        return <AdminPanel onBack={() => setActiveTab('home')} />;
      case 'live':
        return (
          <div className="min-h-screen bg-gray-100 pt-20">
            <div className="max-w-4xl mx-auto px-4 py-6">
              <div className="bg-white rounded-xl shadow-sm p-8 text-center">
                <Video className="w-16 h-16 text-red-500 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Go Live</h2>
                <p className="text-gray-500 mb-6">Start a live video to connect with your friends and followers in real-time.</p>
                <button 
                  onClick={() => handleAuthRequired(() => setShowVirtualHangout(true))}
                  className="px-8 py-3 bg-red-500 text-white rounded-xl font-semibold hover:bg-red-600 transition-colors"
                >
                  Start Live Video
                </button>
              </div>
            </div>
          </div>
        );
      case 'favorites':
        return (
          <div className="min-h-screen bg-gray-100 pt-20">
            <div className="max-w-4xl mx-auto px-4 py-6">
              <div className="bg-white rounded-xl shadow-sm p-8 text-center">
                <Heart className="w-16 h-16 text-pink-500 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Favorites</h2>
                <p className="text-gray-500 mb-6">Your favorite friends and pages will appear here for quick access.</p>
                <button 
                  onClick={() => setActiveTab('friends')}
                  className="px-8 py-3 bg-pink-500 text-white rounded-xl font-semibold hover:bg-pink-600 transition-colors"
                >
                  Add Favorites
                </button>
              </div>
            </div>
          </div>
        );
      default:
        return (
          <div className="min-h-screen bg-gray-100">
            <div className="max-w-7xl mx-auto px-4 pt-20 pb-8">
              <div className="flex gap-4">
                {/* Left Sidebar */}
                <div className="hidden lg:block">
                  <LeftSidebar 
                    activeTab={activeTab} 
                    setActiveTab={setActiveTab}
                    onOpenAI={() => setShowAIAssistant(true)}
                    onOpenMonetization={() => setShowMonetization(true)}
                    onOpenAnalytics={() => setShowAnalytics(true)}
                    onOpenAdMonetization={() => setShowAdMonetization(true)}
                  />
                </div>

                {/* Main Feed */}
                <main className="flex-1 max-w-2xl mx-auto">
                  {/* Welcome Banner for Non-Authenticated Users */}
                  {!isAuthenticated && (
                    <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl p-6 mb-4 text-white">
                      <h2 className="text-2xl font-bold mb-2">Welcome to Socialite!</h2>
                      <p className="text-blue-100 mb-4">
                        Join our community to connect with friends, share moments, and discover amazing content.
                      </p>
                      <div className="flex items-center gap-3">
                        <button 
                          onClick={() => handleOpenAuth('signup')}
                          className="px-6 py-2.5 bg-white text-blue-600 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
                        >
                          Create Account
                        </button>
                        <button 
                          onClick={() => handleOpenAuth('login')}
                          className="px-6 py-2.5 bg-white/20 text-white rounded-lg font-semibold hover:bg-white/30 transition-colors"
                        >
                          Sign In
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Mood Filter Banner */}
                  {currentMood && (
                    <div className="bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl p-4 mb-4 text-white flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Sparkles className="w-6 h-6" />
                        <div>
                          <p className="font-semibold">
                            {currentMood.charAt(0).toUpperCase() + currentMood.slice(1)} mode active
                          </p>
                          <p className="text-sm opacity-80">Your feed is filtered to match your mood</p>
                        </div>
                      </div>
                      <button 
                        onClick={() => setCurrentMood(null)}
                        className="px-4 py-1.5 bg-white/20 rounded-full text-sm font-medium hover:bg-white/30 transition-colors"
                      >
                        Clear
                      </button>
                    </div>
                  )}

                  {/* Feature Quick Access */}
                  <div className="bg-white rounded-xl shadow-sm p-4 mb-4">
                    <div className="grid grid-cols-4 sm:grid-cols-6 gap-3">
                      <button 
                        onClick={() => setActiveTab('reels')}
                        className="flex flex-col items-center gap-2 py-3 bg-gradient-to-br from-pink-500 to-rose-500 text-white rounded-xl hover:opacity-90 transition-opacity"
                      >
                        <Film className="w-6 h-6" />
                        <span className="text-xs font-medium">Reels</span>
                      </button>
                      <button 
                        onClick={() => setActiveTab('gaming')}
                        className="flex flex-col items-center gap-2 py-3 bg-gradient-to-br from-purple-500 to-indigo-500 text-white rounded-xl hover:opacity-90 transition-opacity"
                      >
                        <Gamepad2 className="w-6 h-6" />
                        <span className="text-xs font-medium">Gaming</span>
                      </button>
                      <button 
                        onClick={() => setActiveTab('events')}
                        className="flex flex-col items-center gap-2 py-3 bg-gradient-to-br from-orange-500 to-red-500 text-white rounded-xl hover:opacity-90 transition-opacity"
                      >
                        <Calendar className="w-6 h-6" />
                        <span className="text-xs font-medium">Events</span>
                      </button>
                      <button 
                        onClick={() => handleAuthRequired(() => setShowVirtualHangout(true))}
                        className="flex flex-col items-center gap-2 py-3 bg-gradient-to-br from-blue-500 to-cyan-500 text-white rounded-xl hover:opacity-90 transition-opacity"
                      >
                        <Video className="w-6 h-6" />
                        <span className="text-xs font-medium">Live</span>
                      </button>
                      <button 
                        onClick={() => setShowAIAssistant(true)}
                        className="flex flex-col items-center gap-2 py-3 bg-gradient-to-br from-violet-500 to-purple-500 text-white rounded-xl hover:opacity-90 transition-opacity"
                      >
                        <Bot className="w-6 h-6" />
                        <span className="text-xs font-medium">AI</span>
                      </button>
                      <button 
                        onClick={() => handleAuthRequired(() => setShowMonetization(true))}
                        className="flex flex-col items-center gap-2 py-3 bg-gradient-to-br from-green-500 to-emerald-500 text-white rounded-xl hover:opacity-90 transition-opacity"
                      >
                        <DollarSign className="w-6 h-6" />
                        <span className="text-xs font-medium">Earn</span>
                      </button>
                    </div>
                  </div>

                  {/* AI & Monetization Feature Cards */}
                  {isAuthenticated && (
                    <div className="grid grid-cols-3 gap-4 mb-4">
                      <button
                        onClick={() => setShowAIAssistant(true)}
                        className="bg-gradient-to-br from-violet-500 to-purple-600 rounded-xl p-4 text-white text-left hover:opacity-95 transition-opacity"
                      >
                        <div className="flex items-center gap-3 mb-2">
                          <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
                            <Bot className="w-6 h-6" />
                          </div>
                          <div>
                            <p className="font-bold text-sm">AI Assistant</p>
                            <p className="text-xs text-white/80">Gemini AI</p>
                          </div>
                        </div>
                      </button>
                      
                      <button
                        onClick={() => setShowMonetization(true)}
                        className="bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl p-4 text-white text-left hover:opacity-95 transition-opacity"
                      >
                        <div className="flex items-center gap-3 mb-2">
                          <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
                            <DollarSign className="w-6 h-6" />
                          </div>
                          <div>
                            <p className="font-bold text-sm">Monetize</p>
                            <p className="text-xs text-white/80">Earn Money</p>
                          </div>
                        </div>
                      </button>

                      <button
                        onClick={() => setShowAnalytics(true)}
                        className="bg-gradient-to-br from-blue-500 to-cyan-600 rounded-xl p-4 text-white text-left hover:opacity-95 transition-opacity"
                      >
                        <div className="flex items-center gap-3 mb-2">
                          <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
                            <BarChart3 className="w-6 h-6" />
                          </div>
                          <div>
                            <p className="font-bold text-sm">Analytics</p>
                            <p className="text-xs text-white/80">Insights</p>
                          </div>
                        </div>
                      </button>
                    </div>
                  )}

                  {/* Stories */}
                  <Stories onCreateStory={() => handleAuthRequired(() => setShowStoryCreator(true))} />

                  {/* Create Post */}
                  <div className="bg-white rounded-xl shadow-sm p-4 mb-4">
                    <div className="flex items-center gap-3">
                      <img 
                        src={displayUser.avatar}
                        alt={displayUser.name}
                        className="w-11 h-11 rounded-full object-cover"
                      />
                      <button 
                        onClick={() => handleAuthRequired(() => setShowCreatePost(true))}
                        className="flex-1 px-4 py-2.5 bg-gray-100 rounded-full text-left text-gray-500 hover:bg-gray-200 transition-colors"
                      >
                        {isAuthenticated 
                          ? `What's on your mind, ${displayUser.name.split(' ')[0]}?`
                          : 'Sign in to share your thoughts...'}
                      </button>
                    </div>
                    <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
                      <button 
                        onClick={() => handleAuthRequired(() => setShowVirtualHangout(true))}
                        className="flex-1 flex items-center justify-center gap-2 py-2 rounded-lg hover:bg-gray-100 transition-colors text-gray-600"
                      >
                        <Video className="w-5 h-5 text-red-500" />
                        <span className="font-medium text-sm">Live Video</span>
                      </button>
                      <button 
                        onClick={() => handleAuthRequired(() => setShowCreatePost(true))}
                        className="flex-1 flex items-center justify-center gap-2 py-2 rounded-lg hover:bg-gray-100 transition-colors text-gray-600"
                      >
                        <svg className="w-5 h-5 text-green-500" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zm-5-7l-3 3.72L9 13l-3 4h12l-4-5z"/>
                        </svg>
                        <span className="font-medium text-sm">Photo/Video</span>
                      </button>
                      <button 
                        onClick={() => setShowAIAssistant(true)}
                        className="flex-1 flex items-center justify-center gap-2 py-2 rounded-lg hover:bg-gray-100 transition-colors text-gray-600"
                      >
                        <Zap className="w-5 h-5 text-violet-500" />
                        <span className="font-medium text-sm">AI Write</span>
                      </button>
                    </div>
                  </div>

                  {/* Posts Feed */}
                  <div className="space-y-4">
                    {filteredPosts.map((post) => (
                      <PostCard
                        key={post.id}
                        post={post}
                        onLike={handleLike}
                        onComment={handleComment}
                        onShare={handleShare}
                        onSave={handleSave}
                      />
                    ))}
                  </div>

                  {/* Load More */}
                  <div className="mt-6 text-center">
                    <button 
                      onClick={loadMorePosts}
                      disabled={isLoading}
                      className="px-6 py-3 bg-white rounded-lg shadow-sm font-medium text-blue-500 hover:bg-gray-50 transition-colors flex items-center gap-2 mx-auto"
                    >
                      {isLoading ? (
                        <>
                          <RefreshCw className="w-5 h-5 animate-spin" />
                          Loading...
                        </>
                      ) : (
                        <>
                          <RefreshCw className="w-5 h-5" />
                          Load More Posts
                        </>
                      )}
                    </button>
                  </div>
                </main>

                {/* Right Sidebar */}
                <div className="hidden xl:block">
                  <RightSidebar />
                </div>
              </div>
            </div>
          </div>
        );
    }
  };

  // Show loading state
  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
            <span className="text-white font-bold text-2xl">S</span>
          </div>
          <p className="text-gray-500">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <Header 
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenMessages={() => handleAuthRequired(() => setShowMessages(true))}
        onOpenNotifications={() => handleAuthRequired(() => setShowNotifications(true))}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onOpenAuth={() => handleOpenAuth('login')}
      />

      {/* Main Content */}
      {renderContent()}

      {/* Modals */}
      <MessagesPanel 
        isOpen={showMessages} 
        onClose={() => setShowMessages(false)} 
      />
      
      <NotificationsPanel 
        isOpen={showNotifications} 
        onClose={() => setShowNotifications(false)} 
      />

      {showCreatePost && (
        <CreatePost 
          onPost={handleCreatePost}
          isModal={true}
          onClose={() => setShowCreatePost(false)}
        />
      )}

      <StoryCreator 
        isOpen={showStoryCreator}
        onClose={() => setShowStoryCreator(false)}
        onPost={handleCreateStory}
      />

      <MoodFilter 
        isOpen={showMoodFilter}
        onClose={() => setShowMoodFilter(false)}
        onSelectMood={setCurrentMood}
        currentMood={currentMood}
      />

      <VirtualHangout 
        isOpen={showVirtualHangout}
        onClose={() => setShowVirtualHangout(false)}
      />

      {/* AI Assistant */}
      <AIAssistant 
        isOpen={showAIAssistant}
        onClose={() => setShowAIAssistant(false)}
        onInsertContent={handleAIInsertContent}
      />

      {/* Monetization Panel */}
      <MonetizationPanel 
        isOpen={showMonetization}
        onClose={() => setShowMonetization(false)}
      />

      {/* Analytics Dashboard */}
      <AnalyticsDashboard 
        isOpen={showAnalytics}
        onClose={() => setShowAnalytics(false)}
      />

      {/* Ad Monetization */}
      <AdMonetization 
        isOpen={showAdMonetization}
        onClose={() => setShowAdMonetization(false)}
      />

      {/* Auth Modal */}
      <AuthModal 
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        initialView={authModalView}
      />

      {/* Floating AI Button */}
      <button
        onClick={() => setShowAIAssistant(true)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-br from-violet-600 to-purple-600 rounded-full shadow-lg flex items-center justify-center text-white hover:scale-110 transition-transform z-40"
      >
        <Bot className="w-7 h-7" />
      </button>

      {/* Custom Styles */}
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.2s ease-out;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .scrollbar-thin::-webkit-scrollbar {
          width: 6px;
        }
        .scrollbar-thin::-webkit-scrollbar-track {
          background: transparent;
        }
        .scrollbar-thin::-webkit-scrollbar-thumb {
          background: #d1d5db;
          border-radius: 3px;
        }
        .scrollbar-thin::-webkit-scrollbar-thumb:hover {
          background: #9ca3af;
        }
        .line-clamp-2 {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>
    </div>
  );
};

export default AppLayout;
