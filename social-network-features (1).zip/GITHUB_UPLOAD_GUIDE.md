# 🚀 GitHub Pe Upload Karne Ki Complete Guide

## Aapke App Ki Files Structure:

```
📁 your-project/
├── 📄 package.json          (Project settings)
├── 📄 index.html             (Main HTML)
├── 📄 vite.config.ts         (Vite config)
├── 📄 tailwind.config.ts     (Tailwind CSS)
├── 📄 tsconfig.json          (TypeScript config)
├── 📁 src/                   (Source code)
│   ├── 📄 main.tsx           (Entry point)
│   ├── 📄 App.tsx            (Main App)
│   ├── 📄 index.css          (Styles)
│   ├── 📁 components/        (All components)
│   ├── 📁 contexts/          (Context files)
│   ├── 📁 hooks/             (Custom hooks)
│   ├── 📁 pages/             (Page components)
│   └── 📁 lib/               (Utilities)
└── 📁 public/                (Static files)
```

---

## 📋 STEP-BY-STEP INSTRUCTIONS:

### STEP 1: GitHub Account Banao (Agar Nahi Hai)
1. https://github.com pe jao
2. "Sign Up" click karo
3. Email, password dalo
4. Account verify karo

---

### STEP 2: GitHub Pe New Repository Banao
1. https://github.com/new pe jao
2. **Repository name:** `social-media-app` (ya jo bhi naam chahiye)
3. **Description:** Social Media Application
4. **Public** select karo (free hosting ke liye)
5. ⚠️ **IMPORTANT:** Neeche ke checkboxes KHALI CHHODO:
   - ❌ Add a README file - UNCHECK
   - ❌ Add .gitignore - UNCHECK  
   - ❌ Choose a license - UNCHECK
6. **"Create repository"** button click karo

---

### STEP 3: Terminal/Command Prompt Kholo

**Windows:**
- Start menu me "cmd" ya "PowerShell" search karo
- Ya VS Code me Terminal > New Terminal

**Mac:**
- Applications > Utilities > Terminal
- Ya VS Code me Terminal > New Terminal

---

### STEP 4: Project Folder Me Jao

```bash
cd /path/to/your/project
```

Example:
```bash
cd C:\Users\YourName\Desktop\my-project
```
ya
```bash
cd ~/Desktop/my-project
```

---

### STEP 5: Ye Commands Ek-Ek Karke Run Karo

```bash
# 1. Git initialize karo
git init

# 2. Saari files add karo
git add .

# 3. First commit karo
git commit -m "Initial commit - Social Media App"

# 4. Main branch set karo
git branch -M main

# 5. GitHub repository connect karo
# ⚠️ APNA USERNAME AUR REPO NAME DALO!
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git

# 6. Code push karo
git push -u origin main
```

---

## 🎯 REAL EXAMPLE:

Agar aapka GitHub username `rahul123` hai aur repo name `social-media-app`:

```bash
git init
git add .
git commit -m "Initial commit - Social Media App"
git branch -M main
git remote add origin https://github.com/rahul123/social-media-app.git
git push -u origin main
```

---

## 🌐 VERCEL PE FREE DEPLOY KARO:

1. https://vercel.com pe jao
2. **"Sign up with GitHub"** click karo
3. **"Add New Project"** click karo
4. Apna repository select karo
5. Framework: **Vite** select karo
6. **"Deploy"** click karo
7. 2-3 minute me LIVE! 🎉

---

## ⚠️ COMMON ERRORS & SOLUTIONS:

### Error: "git is not recognized"
**Solution:** Git install karo: https://git-scm.com/downloads

### Error: "fatal: remote origin already exists"
**Solution:**
```bash
git remote remove origin
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
```

### Error: "Permission denied"
**Solution:** GitHub pe login check karo ya Personal Access Token banao

### Error: "src refspec main does not match any"
**Solution:**
```bash
git add .
git commit -m "first commit"
git push -u origin main
```

---

## ✅ CHECKLIST:

- [ ] Git installed hai? (`git --version` check karo)
- [ ] Node.js installed hai? (`node --version` check karo)
- [ ] GitHub account hai?
- [ ] New repository banaya?
- [ ] Terminal me project folder me ho?

---

## 📞 HELP CHAHIYE?

1. Git install: https://git-scm.com/downloads
2. Node.js install: https://nodejs.org
3. GitHub Docs: https://docs.github.com

---

**🎉 Bas itna hi! Ab aapka app GitHub pe upload ho jayega!**
