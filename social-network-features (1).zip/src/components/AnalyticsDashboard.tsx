import React, { useState } from 'react';
import {
  X, TrendingUp, TrendingDown, Users, Eye, Heart, MessageCircle,
  Share2, DollarSign, Download, Calendar, ChevronDown, BarChart3,
  PieChart, Activity, Clock, Globe, UserCheck, ArrowUpRight,
  ArrowDownRight, Filter, RefreshCw, FileText, FileSpreadsheet,
  Zap, Target, Award, Sparkles
} from 'lucide-react';
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart as RechartsPie,
  Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  ComposedChart, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis
} from 'recharts';

interface AnalyticsDashboardProps {
  isOpen: boolean;
  onClose: () => void;
}

// Mock data for analytics
const followerGrowthData = [
  { date: 'Jan', followers: 12500, gained: 850, lost: 120 },
  { date: 'Feb', followers: 14200, gained: 1900, lost: 200 },
  { date: 'Mar', followers: 16800, gained: 2800, lost: 200 },
  { date: 'Apr', followers: 19500, gained: 2900, lost: 200 },
  { date: 'May', followers: 23100, gained: 3800, lost: 200 },
  { date: 'Jun', followers: 27500, gained: 4600, lost: 200 },
  { date: 'Jul', followers: 32800, gained: 5500, lost: 200 },
  { date: 'Aug', followers: 38200, gained: 5600, lost: 200 },
  { date: 'Sep', followers: 44500, gained: 6500, lost: 200 },
  { date: 'Oct', followers: 51200, gained: 6900, lost: 200 },
  { date: 'Nov', followers: 58900, gained: 7900, lost: 200 },
  { date: 'Dec', followers: 67500, gained: 8800, lost: 200 },
];

const engagementData = [
  { date: 'Mon', likes: 4500, comments: 1200, shares: 800, saves: 600 },
  { date: 'Tue', likes: 5200, comments: 1400, shares: 950, saves: 720 },
  { date: 'Wed', likes: 4800, comments: 1100, shares: 700, saves: 580 },
  { date: 'Thu', likes: 6100, comments: 1800, shares: 1200, saves: 890 },
  { date: 'Fri', likes: 7200, comments: 2100, shares: 1500, saves: 1100 },
  { date: 'Sat', likes: 8500, comments: 2400, shares: 1800, saves: 1350 },
  { date: 'Sun', likes: 7800, comments: 2200, shares: 1600, saves: 1200 },
];

const postPerformanceData = [
  { name: 'Photo Posts', reach: 45000, engagement: 8.5, posts: 24 },
  { name: 'Video Posts', reach: 78000, engagement: 12.3, posts: 12 },
  { name: 'Stories', reach: 32000, engagement: 6.2, posts: 45 },
  { name: 'Reels', reach: 125000, engagement: 15.8, posts: 8 },
  { name: 'Live', reach: 18000, engagement: 22.4, posts: 3 },
  { name: 'Text Posts', reach: 12000, engagement: 4.1, posts: 18 },
];

const bestPostingTimes = [
  { hour: '6AM', mon: 20, tue: 25, wed: 22, thu: 28, fri: 30, sat: 45, sun: 50 },
  { hour: '9AM', mon: 65, tue: 70, wed: 68, thu: 72, fri: 75, sat: 55, sun: 48 },
  { hour: '12PM', mon: 85, tue: 88, wed: 82, thu: 90, fri: 92, sat: 70, sun: 65 },
  { hour: '3PM', mon: 78, tue: 75, wed: 80, thu: 82, fri: 85, sat: 60, sun: 55 },
  { hour: '6PM', mon: 92, tue: 95, wed: 90, thu: 98, fri: 100, sat: 88, sun: 82 },
  { hour: '9PM', mon: 88, tue: 85, wed: 87, thu: 90, fri: 95, sat: 92, sun: 90 },
];

const audienceAgeData = [
  { name: '13-17', value: 8, color: '#8b5cf6' },
  { name: '18-24', value: 32, color: '#6366f1' },
  { name: '25-34', value: 35, color: '#3b82f6' },
  { name: '35-44', value: 15, color: '#0ea5e9' },
  { name: '45-54', value: 7, color: '#14b8a6' },
  { name: '55+', value: 3, color: '#22c55e' },
];

const audienceGenderData = [
  { name: 'Female', value: 58, color: '#ec4899' },
  { name: 'Male', value: 38, color: '#3b82f6' },
  { name: 'Other', value: 4, color: '#8b5cf6' },
];

const audienceLocationData = [
  { name: 'United States', value: 35, flag: '🇺🇸' },
  { name: 'India', value: 22, flag: '🇮🇳' },
  { name: 'United Kingdom', value: 12, flag: '🇬🇧' },
  { name: 'Canada', value: 8, flag: '🇨🇦' },
  { name: 'Australia', value: 6, flag: '🇦🇺' },
  { name: 'Germany', value: 5, flag: '🇩🇪' },
  { name: 'Brazil', value: 4, flag: '🇧🇷' },
  { name: 'Others', value: 8, flag: '🌍' },
];

const revenueData = [
  { month: 'Jan', subscriptions: 1200, tips: 450, ads: 320, total: 1970 },
  { month: 'Feb', subscriptions: 1450, tips: 580, ads: 380, total: 2410 },
  { month: 'Mar', subscriptions: 1680, tips: 720, ads: 450, total: 2850 },
  { month: 'Apr', subscriptions: 1920, tips: 890, ads: 520, total: 3330 },
  { month: 'May', subscriptions: 2250, tips: 1100, ads: 620, total: 3970 },
  { month: 'Jun', subscriptions: 2580, tips: 1350, ads: 750, total: 4680 },
  { month: 'Jul', subscriptions: 2950, tips: 1580, ads: 880, total: 5410 },
  { month: 'Aug', subscriptions: 3350, tips: 1820, ads: 1020, total: 6190 },
  { month: 'Sep', subscriptions: 3780, tips: 2100, ads: 1180, total: 7060 },
  { month: 'Oct', subscriptions: 4250, tips: 2420, ads: 1350, total: 8020 },
  { month: 'Nov', subscriptions: 4780, tips: 2780, ads: 1550, total: 9110 },
  { month: 'Dec', subscriptions: 5350, tips: 3200, ads: 1780, total: 10330 },
];

const topPostsData = [
  { id: 1, type: 'Reel', title: 'Morning routine tips...', reach: 125000, engagement: 18.5, revenue: 450 },
  { id: 2, type: 'Video', title: 'Behind the scenes...', reach: 98000, engagement: 15.2, revenue: 320 },
  { id: 3, type: 'Photo', title: 'New product launch...', reach: 78000, engagement: 12.8, revenue: 280 },
  { id: 4, type: 'Reel', title: 'Quick tutorial...', reach: 65000, engagement: 14.1, revenue: 220 },
  { id: 5, type: 'Story', title: 'Q&A session...', reach: 52000, engagement: 22.4, revenue: 180 },
];

const contentScoreData = [
  { subject: 'Consistency', A: 85, fullMark: 100 },
  { subject: 'Engagement', A: 78, fullMark: 100 },
  { subject: 'Growth', A: 92, fullMark: 100 },
  { subject: 'Quality', A: 88, fullMark: 100 },
  { subject: 'Reach', A: 75, fullMark: 100 },
  { subject: 'Revenue', A: 82, fullMark: 100 },
];

const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'engagement' | 'audience' | 'revenue' | 'content'>('overview');
  const [dateRange, setDateRange] = useState('30d');
  const [isExporting, setIsExporting] = useState(false);

  if (!isOpen) return null;

  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const handleExport = (format: 'csv' | 'pdf') => {
    setIsExporting(true);
    
    // Simulate export
    setTimeout(() => {
      if (format === 'csv') {
        // Generate CSV content
        const csvContent = generateCSVReport();
        downloadFile(csvContent, 'analytics-report.csv', 'text/csv');
      } else {
        // For PDF, we'd typically use a library like jsPDF
        // For now, generate a text summary
        const reportContent = generateTextReport();
        downloadFile(reportContent, 'analytics-report.txt', 'text/plain');
      }
      setIsExporting(false);
    }, 1500);
  };

  const generateCSVReport = () => {
    let csv = 'Analytics Report - Generated ' + new Date().toLocaleDateString() + '\n\n';
    
    csv += 'Follower Growth\n';
    csv += 'Month,Followers,Gained,Lost\n';
    followerGrowthData.forEach(row => {
      csv += `${row.date},${row.followers},${row.gained},${row.lost}\n`;
    });
    
    csv += '\nEngagement Data\n';
    csv += 'Day,Likes,Comments,Shares,Saves\n';
    engagementData.forEach(row => {
      csv += `${row.date},${row.likes},${row.comments},${row.shares},${row.saves}\n`;
    });
    
    csv += '\nRevenue Data\n';
    csv += 'Month,Subscriptions,Tips,Ads,Total\n';
    revenueData.forEach(row => {
      csv += `${row.month},$${row.subscriptions},$${row.tips},$${row.ads},$${row.total}\n`;
    });
    
    return csv;
  };

  const generateTextReport = () => {
    const totalRevenue = revenueData.reduce((sum, r) => sum + r.total, 0);
    const avgEngagement = engagementData.reduce((sum, e) => sum + e.likes + e.comments + e.shares, 0) / engagementData.length;
    
    return `
SOCIALITE ANALYTICS REPORT
Generated: ${new Date().toLocaleString()}
Period: Last ${dateRange === '7d' ? '7 Days' : dateRange === '30d' ? '30 Days' : dateRange === '90d' ? '90 Days' : '12 Months'}

=== OVERVIEW ===
Total Followers: ${formatNumber(67500)}
Follower Growth: +8,800 (15.0%)
Total Reach: 2.4M
Engagement Rate: 8.7%

=== REVENUE SUMMARY ===
Total Revenue: $${formatNumber(totalRevenue)}
From Subscriptions: $${formatNumber(revenueData.reduce((s, r) => s + r.subscriptions, 0))}
From Tips: $${formatNumber(revenueData.reduce((s, r) => s + r.tips, 0))}
From Ads: $${formatNumber(revenueData.reduce((s, r) => s + r.ads, 0))}

=== TOP PERFORMING CONTENT ===
${topPostsData.map((p, i) => `${i + 1}. ${p.type}: ${p.title} - ${formatNumber(p.reach)} reach`).join('\n')}

=== AUDIENCE DEMOGRAPHICS ===
Top Age Group: 25-34 (35%)
Gender: ${audienceGenderData[0].value}% Female, ${audienceGenderData[1].value}% Male
Top Location: ${audienceLocationData[0].name} (${audienceLocationData[0].value}%)

=== RECOMMENDATIONS ===
1. Post more Reels - they have 15.8% engagement rate
2. Best posting time: 6PM on weekdays
3. Focus on video content for higher reach
    `;
  };

  const downloadFile = (content: string, filename: string, type: string) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const StatCard = ({ 
    title, 
    value, 
    change, 
    changeType, 
    icon: Icon, 
    color 
  }: { 
    title: string; 
    value: string; 
    change: string; 
    changeType: 'up' | 'down'; 
    icon: React.ElementType; 
    color: string;
  }) => (
    <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-gray-500 font-medium">{title}</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">{value}</p>
          <div className={`flex items-center gap-1 mt-2 text-sm font-medium ${
            changeType === 'up' ? 'text-green-600' : 'text-red-500'
          }`}>
            {changeType === 'up' ? (
              <ArrowUpRight className="w-4 h-4" />
            ) : (
              <ArrowDownRight className="w-4 h-4" />
            )}
            <span>{change}</span>
            <span className="text-gray-400 font-normal">vs last period</span>
          </div>
        </div>
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${color}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
    </div>
  );

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Followers"
          value="67.5K"
          change="+15.0%"
          changeType="up"
          icon={Users}
          color="bg-gradient-to-br from-blue-500 to-blue-600"
        />
        <StatCard
          title="Total Reach"
          value="2.4M"
          change="+23.5%"
          changeType="up"
          icon={Eye}
          color="bg-gradient-to-br from-purple-500 to-purple-600"
        />
        <StatCard
          title="Engagement Rate"
          value="8.7%"
          change="+2.1%"
          changeType="up"
          icon={Heart}
          color="bg-gradient-to-br from-pink-500 to-pink-600"
        />
        <StatCard
          title="Total Revenue"
          value="$10.3K"
          change="+28.4%"
          changeType="up"
          icon={DollarSign}
          color="bg-gradient-to-br from-green-500 to-green-600"
        />
      </div>

      {/* Follower Growth Chart */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Follower Growth</h3>
            <p className="text-sm text-gray-500">Track your audience growth over time</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-blue-500" />
              <span className="text-sm text-gray-600">Followers</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-green-500" />
              <span className="text-sm text-gray-600">Gained</span>
            </div>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={followerGrowthData}>
            <defs>
              <linearGradient id="colorFollowers" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis dataKey="date" stroke="#9ca3af" fontSize={12} />
            <YAxis stroke="#9ca3af" fontSize={12} tickFormatter={formatNumber} />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#fff', 
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)'
              }}
              formatter={(value: number) => [formatNumber(value), '']}
            />
            <Area 
              type="monotone" 
              dataKey="followers" 
              stroke="#3b82f6" 
              strokeWidth={2}
              fillOpacity={1} 
              fill="url(#colorFollowers)" 
            />
            <Line type="monotone" dataKey="gained" stroke="#22c55e" strokeWidth={2} dot={false} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Content Score & Top Posts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Content Score Radar */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Content Score</h3>
              <p className="text-sm text-gray-500">Your overall performance metrics</p>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 bg-green-100 text-green-700 rounded-full">
              <Award className="w-4 h-4" />
              <span className="font-semibold">83/100</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <RadarChart data={contentScoreData}>
              <PolarGrid stroke="#e5e7eb" />
              <PolarAngleAxis dataKey="subject" tick={{ fontSize: 12, fill: '#6b7280' }} />
              <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fontSize: 10 }} />
              <Radar
                name="Score"
                dataKey="A"
                stroke="#8b5cf6"
                fill="#8b5cf6"
                fillOpacity={0.4}
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        {/* Top Posts */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Top Performing Posts</h3>
              <p className="text-sm text-gray-500">Your best content this period</p>
            </div>
          </div>
          <div className="space-y-3">
            {topPostsData.map((post, idx) => (
              <div key={post.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-white ${
                  idx === 0 ? 'bg-yellow-500' : idx === 1 ? 'bg-gray-400' : idx === 2 ? 'bg-orange-400' : 'bg-gray-300'
                }`}>
                  {idx + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs px-2 py-0.5 bg-blue-100 text-blue-600 rounded font-medium">
                      {post.type}
                    </span>
                    <p className="text-sm font-medium text-gray-900 truncate">{post.title}</p>
                  </div>
                  <div className="flex items-center gap-3 mt-1 text-xs text-gray-500">
                    <span className="flex items-center gap-1">
                      <Eye className="w-3 h-3" />
                      {formatNumber(post.reach)}
                    </span>
                    <span className="flex items-center gap-1">
                      <Heart className="w-3 h-3" />
                      {post.engagement}%
                    </span>
                    <span className="flex items-center gap-1 text-green-600">
                      <DollarSign className="w-3 h-3" />
                      ${post.revenue}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderEngagement = () => (
    <div className="space-y-6">
      {/* Engagement Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Likes"
          value="44.1K"
          change="+18.2%"
          changeType="up"
          icon={Heart}
          color="bg-gradient-to-br from-red-500 to-pink-500"
        />
        <StatCard
          title="Comments"
          value="12.2K"
          change="+12.5%"
          changeType="up"
          icon={MessageCircle}
          color="bg-gradient-to-br from-blue-500 to-cyan-500"
        />
        <StatCard
          title="Shares"
          value="8.5K"
          change="+25.3%"
          changeType="up"
          icon={Share2}
          color="bg-gradient-to-br from-green-500 to-emerald-500"
        />
        <StatCard
          title="Saves"
          value="6.4K"
          change="+31.2%"
          changeType="up"
          icon={Bookmark}
          color="bg-gradient-to-br from-purple-500 to-violet-500"
        />
      </div>

      {/* Engagement Chart */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Weekly Engagement</h3>
            <p className="text-sm text-gray-500">Breakdown of engagement by type</p>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={350}>
          <ComposedChart data={engagementData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis dataKey="date" stroke="#9ca3af" fontSize={12} />
            <YAxis stroke="#9ca3af" fontSize={12} tickFormatter={formatNumber} />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#fff', 
                border: '1px solid #e5e7eb',
                borderRadius: '8px'
              }}
            />
            <Legend />
            <Bar dataKey="likes" fill="#ef4444" name="Likes" radius={[4, 4, 0, 0]} />
            <Bar dataKey="comments" fill="#3b82f6" name="Comments" radius={[4, 4, 0, 0]} />
            <Bar dataKey="shares" fill="#22c55e" name="Shares" radius={[4, 4, 0, 0]} />
            <Bar dataKey="saves" fill="#8b5cf6" name="Saves" radius={[4, 4, 0, 0]} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* Best Posting Times */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Best Posting Times</h3>
            <p className="text-sm text-gray-500">When your audience is most active</p>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <span className="text-gray-500">Engagement Level:</span>
            <div className="flex items-center gap-1">
              <div className="w-4 h-4 rounded bg-green-100" />
              <span className="text-gray-600">Low</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-4 h-4 rounded bg-green-300" />
              <span className="text-gray-600">Medium</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-4 h-4 rounded bg-green-500" />
              <span className="text-gray-600">High</span>
            </div>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr>
                <th className="text-left text-sm font-medium text-gray-500 pb-3">Time</th>
                <th className="text-center text-sm font-medium text-gray-500 pb-3">Mon</th>
                <th className="text-center text-sm font-medium text-gray-500 pb-3">Tue</th>
                <th className="text-center text-sm font-medium text-gray-500 pb-3">Wed</th>
                <th className="text-center text-sm font-medium text-gray-500 pb-3">Thu</th>
                <th className="text-center text-sm font-medium text-gray-500 pb-3">Fri</th>
                <th className="text-center text-sm font-medium text-gray-500 pb-3">Sat</th>
                <th className="text-center text-sm font-medium text-gray-500 pb-3">Sun</th>
              </tr>
            </thead>
            <tbody>
              {bestPostingTimes.map((row) => (
                <tr key={row.hour}>
                  <td className="py-2 text-sm font-medium text-gray-700">{row.hour}</td>
                  {['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'].map((day) => {
                    const value = row[day as keyof typeof row] as number;
                    const bgColor = value >= 90 ? 'bg-green-500' : 
                                   value >= 70 ? 'bg-green-400' : 
                                   value >= 50 ? 'bg-green-300' : 
                                   value >= 30 ? 'bg-green-200' : 'bg-green-100';
                    return (
                      <td key={day} className="py-2 text-center">
                        <div className={`w-10 h-10 mx-auto rounded-lg ${bgColor} flex items-center justify-center text-xs font-medium ${value >= 70 ? 'text-white' : 'text-green-800'}`}>
                          {value}%
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="mt-4 p-4 bg-blue-50 rounded-lg">
          <div className="flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-blue-500 mt-0.5" />
            <div>
              <p className="font-medium text-blue-900">AI Recommendation</p>
              <p className="text-sm text-blue-700 mt-1">
                Your best posting times are <strong>6PM on weekdays</strong> and <strong>6AM on weekends</strong>. 
                Consider scheduling your most important content during these peak engagement windows.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Post Type Performance */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Content Type Performance</h3>
            <p className="text-sm text-gray-500">Compare engagement across different content types</p>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={postPerformanceData} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis type="number" stroke="#9ca3af" fontSize={12} />
            <YAxis dataKey="name" type="category" stroke="#9ca3af" fontSize={12} width={100} />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#fff', 
                border: '1px solid #e5e7eb',
                borderRadius: '8px'
              }}
            />
            <Bar dataKey="engagement" fill="#8b5cf6" name="Engagement %" radius={[0, 4, 4, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );

  const renderAudience = () => (
    <div className="space-y-6">
      {/* Audience Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Audience"
          value="67.5K"
          change="+15.0%"
          changeType="up"
          icon={Users}
          color="bg-gradient-to-br from-blue-500 to-blue-600"
        />
        <StatCard
          title="Active Followers"
          value="45.2K"
          change="+8.3%"
          changeType="up"
          icon={UserCheck}
          color="bg-gradient-to-br from-green-500 to-green-600"
        />
        <StatCard
          title="Avg. Session"
          value="4m 32s"
          change="+12.5%"
          changeType="up"
          icon={Clock}
          color="bg-gradient-to-br from-purple-500 to-purple-600"
        />
        <StatCard
          title="Countries"
          value="42"
          change="+5"
          changeType="up"
          icon={Globe}
          color="bg-gradient-to-br from-orange-500 to-orange-600"
        />
      </div>

      {/* Demographics Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Age Distribution */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Age Distribution</h3>
          <p className="text-sm text-gray-500 mb-4">Breakdown of your audience by age group</p>
          <ResponsiveContainer width="100%" height={250}>
            <RechartsPie>
              <Pie
                data={audienceAgeData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={2}
                dataKey="value"
                label={({ name, value }) => `${name}: ${value}%`}
              >
                {audienceAgeData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </RechartsPie>
          </ResponsiveContainer>
          <div className="flex flex-wrap gap-2 mt-4 justify-center">
            {audienceAgeData.map((item) => (
              <div key={item.name} className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-xs text-gray-600">{item.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Gender Distribution */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Gender Distribution</h3>
          <p className="text-sm text-gray-500 mb-4">Breakdown of your audience by gender</p>
          <ResponsiveContainer width="100%" height={250}>
            <RechartsPie>
              <Pie
                data={audienceGenderData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                paddingAngle={2}
                dataKey="value"
                label={({ name, value }) => `${name}: ${value}%`}
              >
                {audienceGenderData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </RechartsPie>
          </ResponsiveContainer>
          <div className="flex flex-wrap gap-4 mt-4 justify-center">
            {audienceGenderData.map((item) => (
              <div key={item.name} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-sm text-gray-600">{item.name}: {item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Location Distribution */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Top Locations</h3>
        <p className="text-sm text-gray-500 mb-4">Where your audience is located</p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {audienceLocationData.map((location, idx) => (
            <div key={location.name} className="p-4 bg-gray-50 rounded-xl">
              <div className="flex items-center gap-3 mb-2">
                <span className="text-2xl">{location.flag}</span>
                <div>
                  <p className="font-medium text-gray-900">{location.name}</p>
                  <p className="text-sm text-gray-500">{location.value}% of audience</p>
                </div>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all"
                  style={{ width: `${location.value}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Audience Insights */}
      <div className="bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl p-6 text-white">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center">
            <Target className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-2">Audience Insights</h3>
            <p className="text-white/90 mb-4">
              Your audience is primarily <strong>young adults (25-34)</strong> who are most active during 
              <strong> evening hours (6-9 PM)</strong>. They engage most with <strong>video content</strong> and 
              are interested in lifestyle, technology, and entertainment topics.
            </p>
            <div className="flex flex-wrap gap-2">
              <span className="px-3 py-1 bg-white/20 rounded-full text-sm">Lifestyle</span>
              <span className="px-3 py-1 bg-white/20 rounded-full text-sm">Technology</span>
              <span className="px-3 py-1 bg-white/20 rounded-full text-sm">Entertainment</span>
              <span className="px-3 py-1 bg-white/20 rounded-full text-sm">Fashion</span>
              <span className="px-3 py-1 bg-white/20 rounded-full text-sm">Travel</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderRevenue = () => (
    <div className="space-y-6">
      {/* Revenue Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Revenue"
          value="$64.3K"
          change="+28.4%"
          changeType="up"
          icon={DollarSign}
          color="bg-gradient-to-br from-green-500 to-emerald-600"
        />
        <StatCard
          title="Subscriptions"
          value="$38.5K"
          change="+32.1%"
          changeType="up"
          icon={Users}
          color="bg-gradient-to-br from-blue-500 to-blue-600"
        />
        <StatCard
          title="Tips Received"
          value="$18.1K"
          change="+24.8%"
          changeType="up"
          icon={Heart}
          color="bg-gradient-to-br from-pink-500 to-pink-600"
        />
        <StatCard
          title="Ad Revenue"
          value="$7.7K"
          change="+18.5%"
          changeType="up"
          icon={Zap}
          color="bg-gradient-to-br from-yellow-500 to-orange-500"
        />
      </div>

      {/* Revenue Chart */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Revenue Breakdown</h3>
            <p className="text-sm text-gray-500">Monthly revenue by source</p>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={350}>
          <AreaChart data={revenueData}>
            <defs>
              <linearGradient id="colorSubs" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="colorTips" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#ec4899" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="#ec4899" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="colorAds" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis dataKey="month" stroke="#9ca3af" fontSize={12} />
            <YAxis stroke="#9ca3af" fontSize={12} tickFormatter={(v) => `$${formatNumber(v)}`} />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#fff', 
                border: '1px solid #e5e7eb',
                borderRadius: '8px'
              }}
              formatter={(value: number) => [`$${formatNumber(value)}`, '']}
            />
            <Legend />
            <Area type="monotone" dataKey="subscriptions" stackId="1" stroke="#3b82f6" fill="url(#colorSubs)" name="Subscriptions" />
            <Area type="monotone" dataKey="tips" stackId="1" stroke="#ec4899" fill="url(#colorTips)" name="Tips" />
            <Area type="monotone" dataKey="ads" stackId="1" stroke="#f59e0b" fill="url(#colorAds)" name="Ad Revenue" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Revenue Breakdown & Payout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Sources */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Revenue Sources</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-blue-50 rounded-xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                  <Users className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="font-medium text-gray-900">Subscriptions</p>
                  <p className="text-sm text-gray-500">1,245 active subscribers</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-bold text-gray-900">$38,500</p>
                <p className="text-sm text-green-600">+32.1%</p>
              </div>
            </div>
            <div className="flex items-center justify-between p-4 bg-pink-50 rounded-xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-pink-500 rounded-lg flex items-center justify-center">
                  <Heart className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="font-medium text-gray-900">Tips & Gifts</p>
                  <p className="text-sm text-gray-500">3,892 tips received</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-bold text-gray-900">$18,100</p>
                <p className="text-sm text-green-600">+24.8%</p>
              </div>
            </div>
            <div className="flex items-center justify-between p-4 bg-yellow-50 rounded-xl">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-yellow-500 rounded-lg flex items-center justify-center">
                  <Zap className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="font-medium text-gray-900">Ad Revenue</p>
                  <p className="text-sm text-gray-500">2.4M impressions</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-bold text-gray-900">$7,700</p>
                <p className="text-sm text-green-600">+18.5%</p>
              </div>
            </div>
          </div>
        </div>

        {/* Payout Summary */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Payout Summary</h3>
          <div className="space-y-4">
            <div className="p-4 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl text-white">
              <p className="text-sm text-white/80">Available for Payout</p>
              <p className="text-3xl font-bold mt-1">$8,450.00</p>
              <button className="mt-3 w-full py-2 bg-white text-green-600 rounded-lg font-semibold hover:bg-green-50 transition-colors">
                Request Payout
              </button>
            </div>
            <div className="space-y-3">
              <div className="flex items-center justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600">Pending Balance</span>
                <span className="font-medium">$2,340.00</span>
              </div>
              <div className="flex items-center justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600">Last Payout</span>
                <span className="font-medium">$5,200.00</span>
              </div>
              <div className="flex items-center justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600">Payout Date</span>
                <span className="font-medium">Dec 15, 2025</span>
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-gray-600">Payout Method</span>
                <span className="font-medium">Bank Transfer</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Revenue Goals */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Revenue Goals</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 border border-gray-200 rounded-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-500">Monthly Goal</span>
              <span className="text-sm font-medium text-green-600">85% achieved</span>
            </div>
            <p className="text-2xl font-bold text-gray-900">$10,330 / $12,000</p>
            <div className="w-full bg-gray-200 rounded-full h-2 mt-3">
              <div className="bg-green-500 h-2 rounded-full" style={{ width: '85%' }} />
            </div>
          </div>
          <div className="p-4 border border-gray-200 rounded-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-500">Quarterly Goal</span>
              <span className="text-sm font-medium text-blue-600">72% achieved</span>
            </div>
            <p className="text-2xl font-bold text-gray-900">$26,500 / $36,000</p>
            <div className="w-full bg-gray-200 rounded-full h-2 mt-3">
              <div className="bg-blue-500 h-2 rounded-full" style={{ width: '72%' }} />
            </div>
          </div>
          <div className="p-4 border border-gray-200 rounded-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-500">Annual Goal</span>
              <span className="text-sm font-medium text-purple-600">64% achieved</span>
            </div>
            <p className="text-2xl font-bold text-gray-900">$64,300 / $100,000</p>
            <div className="w-full bg-gray-200 rounded-full h-2 mt-3">
              <div className="bg-purple-500 h-2 rounded-full" style={{ width: '64%' }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderContent = () => (
    <div className="space-y-6">
      {/* Content Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Posts"
          value="156"
          change="+12"
          changeType="up"
          icon={FileText}
          color="bg-gradient-to-br from-blue-500 to-blue-600"
        />
        <StatCard
          title="Avg. Reach"
          value="15.4K"
          change="+18.2%"
          changeType="up"
          icon={Eye}
          color="bg-gradient-to-br from-purple-500 to-purple-600"
        />
        <StatCard
          title="Avg. Engagement"
          value="8.7%"
          change="+2.1%"
          changeType="up"
          icon={Activity}
          color="bg-gradient-to-br from-pink-500 to-pink-600"
        />
        <StatCard
          title="Content Score"
          value="83/100"
          change="+5"
          changeType="up"
          icon={Award}
          color="bg-gradient-to-br from-yellow-500 to-orange-500"
        />
      </div>

      {/* Content Type Breakdown */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Content Performance by Type</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={postPerformanceData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis dataKey="name" stroke="#9ca3af" fontSize={12} />
            <YAxis yAxisId="left" stroke="#9ca3af" fontSize={12} tickFormatter={formatNumber} />
            <YAxis yAxisId="right" orientation="right" stroke="#9ca3af" fontSize={12} />
            <Tooltip />
            <Legend />
            <Bar yAxisId="left" dataKey="reach" fill="#3b82f6" name="Reach" radius={[4, 4, 0, 0]} />
            <Bar yAxisId="right" dataKey="engagement" fill="#8b5cf6" name="Engagement %" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Content Recommendations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Content Mix</h3>
          <div className="space-y-4">
            {postPerformanceData.map((type) => (
              <div key={type.name} className="flex items-center gap-4">
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-gray-700">{type.name}</span>
                    <span className="text-sm text-gray-500">{type.posts} posts</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full"
                      style={{ width: `${(type.posts / 45) * 100}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gradient-to-br from-violet-500 to-purple-600 rounded-xl p-6 text-white">
          <div className="flex items-center gap-3 mb-4">
            <Sparkles className="w-6 h-6" />
            <h3 className="text-lg font-semibold">AI Content Recommendations</h3>
          </div>
          <div className="space-y-3">
            <div className="p-3 bg-white/10 rounded-lg">
              <p className="font-medium">Create more Reels</p>
              <p className="text-sm text-white/80 mt-1">Reels have 15.8% engagement - your highest performing content type</p>
            </div>
            <div className="p-3 bg-white/10 rounded-lg">
              <p className="font-medium">Post at 6PM on weekdays</p>
              <p className="text-sm text-white/80 mt-1">This is when your audience is most active</p>
            </div>
            <div className="p-3 bg-white/10 rounded-lg">
              <p className="font-medium">Use trending hashtags</p>
              <p className="text-sm text-white/80 mt-1">Posts with trending hashtags get 45% more reach</p>
            </div>
            <div className="p-3 bg-white/10 rounded-lg">
              <p className="font-medium">Engage with comments</p>
              <p className="text-sm text-white/80 mt-1">Responding within 1 hour boosts engagement by 30%</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // Import Bookmark icon
  const Bookmark = ({ className }: { className?: string }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
    </svg>
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="w-full max-w-7xl h-[90vh] bg-gray-50 rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-fadeIn">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                <BarChart3 className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900">Creator Analytics</h2>
                <p className="text-sm text-gray-500">Track your performance and grow your audience</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {/* Date Range Selector */}
              <div className="relative">
                <select
                  value={dateRange}
                  onChange={(e) => setDateRange(e.target.value)}
                  className="appearance-none pl-4 pr-10 py-2 bg-gray-100 border border-gray-200 rounded-lg text-sm font-medium text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="7d">Last 7 days</option>
                  <option value="30d">Last 30 days</option>
                  <option value="90d">Last 90 days</option>
                  <option value="12m">Last 12 months</option>
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500 pointer-events-none" />
              </div>
              
              {/* Export Buttons */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleExport('csv')}
                  disabled={isExporting}
                  className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-sm font-medium transition-colors disabled:opacity-50"
                >
                  <FileSpreadsheet className="w-4 h-4" />
                  CSV
                </button>
                <button
                  onClick={() => handleExport('pdf')}
                  disabled={isExporting}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg text-sm font-medium transition-colors disabled:opacity-50"
                >
                  {isExporting ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Download className="w-4 h-4" />
                  )}
                  Export
                </button>
              </div>
              
              <button
                onClick={onClose}
                className="w-10 h-10 rounded-full hover:bg-gray-100 flex items-center justify-center transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex items-center gap-1 mt-4 -mb-4">
            {[
              { id: 'overview', label: 'Overview', icon: BarChart3 },
              { id: 'engagement', label: 'Engagement', icon: Heart },
              { id: 'audience', label: 'Audience', icon: Users },
              { id: 'revenue', label: 'Revenue', icon: DollarSign },
              { id: 'content', label: 'Content', icon: FileText },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'overview' && renderOverview()}
          {activeTab === 'engagement' && renderEngagement()}
          {activeTab === 'audience' && renderAudience()}
          {activeTab === 'revenue' && renderRevenue()}
          {activeTab === 'content' && renderContent()}
        </div>
      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.2s ease-out;
        }
      `}</style>
    </div>
  );
};

export default AnalyticsDashboard;
