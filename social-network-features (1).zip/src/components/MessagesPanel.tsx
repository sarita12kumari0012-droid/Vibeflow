import React, { useState, useRef, useEffect } from 'react';
import { conversations, currentUser, users, Conversation, User } from '../data/socialData';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { 
  X, Search, Edit, MoreHorizontal, Phone, Video, Info,
  Image, Smile, ThumbsUp, Send, Mic, Paperclip, Circle,
  Check, CheckCheck, Loader2, Plus, ArrowLeft
} from 'lucide-react';

interface MessagesPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Message {
  id: string;
  senderId: string;
  content: string;
  timestamp: string;
  type: 'text' | 'image' | 'voice';
  isRead?: boolean;
}

interface ChatConversation {
  id: string;
  other_user: {
    user_id: string;
    full_name: string;
    username: string;
    avatar_url: string;
    is_online?: boolean;
  };
  last_message: string;
  last_message_at: string;
}

const MessagesPanel: React.FC<MessagesPanelProps> = ({ isOpen, onClose }) => {
  const { isAuthenticated, profile } = useAuth();
  const [selectedConversation, setSelectedConversation] = useState<Conversation | ChatConversation | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [messageText, setMessageText] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [dbConversations, setDbConversations] = useState<ChatConversation[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Load conversations from database
  useEffect(() => {
    if (isOpen && isAuthenticated) {
      loadConversations();
    }
  }, [isOpen, isAuthenticated]);

  // Subscribe to real-time messages
  useEffect(() => {
    if (!selectedConversation || !('id' in selectedConversation)) return;

    const channel = supabase
      .channel(`messages:${selectedConversation.id}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chat_messages',
          filter: `conversation_id=eq.${selectedConversation.id}`
        },
        (payload) => {
          const newMessage = payload.new as any;
          // Only add if it's not from current user (we already added it optimistically)
          if (newMessage.sender_id !== profile?.user_id) {
            const formattedMessage: Message = {
              id: newMessage.id,
              senderId: newMessage.sender_id,
              content: newMessage.content,
              timestamp: new Date(newMessage.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              type: newMessage.message_type || 'text',
              isRead: newMessage.is_read
            };
            setMessages(prev => [...prev, formattedMessage]);
            
            // Show typing indicator briefly
            setIsTyping(false);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [selectedConversation, profile?.user_id]);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const loadConversations = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('chat-service', {
        body: { action: 'get_conversations' }
      });

      if (error) throw error;
      if (data?.conversations) {
        setDbConversations(data.conversations);
      }
    } catch (error) {
      console.error('Error loading conversations:', error);
    }
  };

  const loadMessages = async (conversationId: string) => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('chat-service', {
        body: { action: 'get_messages', conversation_id: conversationId }
      });

      if (error) throw error;
      if (data?.messages) {
        const formattedMessages: Message[] = data.messages.map((msg: any) => ({
          id: msg.id,
          senderId: msg.sender_id,
          content: msg.content,
          timestamp: new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          type: msg.message_type || 'text',
          isRead: msg.is_read
        }));
        setMessages(formattedMessages);
      }
    } catch (error) {
      console.error('Error loading messages:', error);
      // Fall back to demo messages
      setMessages([
        { id: '1', senderId: '2', content: 'Hey! How are you doing?', timestamp: '10:30 AM', type: 'text' },
        { id: '2', senderId: currentUser.id, content: "I'm great! Just finished a big project.", timestamp: '10:32 AM', type: 'text' },
        { id: '3', senderId: '2', content: "That's awesome! We should celebrate 🎉", timestamp: '10:33 AM', type: 'text' },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectConversation = async (conv: Conversation | ChatConversation) => {
    setSelectedConversation(conv);
    
    if ('id' in conv && typeof conv.id === 'string' && conv.id.includes('-')) {
      // It's a database conversation (UUID)
      await loadMessages(conv.id);
    } else {
      // Demo conversation
      setMessages([
        { id: '1', senderId: '2', content: 'Hey! How are you doing?', timestamp: '10:30 AM', type: 'text' },
        { id: '2', senderId: currentUser.id, content: "I'm great! Just finished a big project.", timestamp: '10:32 AM', type: 'text' },
        { id: '3', senderId: '2', content: "That's awesome! We should celebrate 🎉", timestamp: '10:33 AM', type: 'text' },
        { id: '4', senderId: currentUser.id, content: 'Definitely! Are you free this weekend?', timestamp: '10:35 AM', type: 'text' },
        { id: '5', senderId: '2', content: "Yes! Let's plan something fun.", timestamp: '10:36 AM', type: 'text' },
      ]);
    }
  };

  const handleSendMessage = async () => {
    if (!messageText.trim()) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      senderId: profile?.user_id || currentUser.id,
      content: messageText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      type: 'text'
    };

    // Optimistically add message
    setMessages(prev => [...prev, newMessage]);
    const sentText = messageText;
    setMessageText('');
    setIsSending(true);

    try {
      if (isAuthenticated && selectedConversation && 'id' in selectedConversation) {
        // Send to database
        const recipientId = 'other_user' in selectedConversation 
          ? selectedConversation.other_user.user_id 
          : getOtherParticipant(selectedConversation as Conversation).id;

        await supabase.functions.invoke('chat-service', {
          body: {
            action: 'send_message',
            conversation_id: selectedConversation.id,
            recipient_id: recipientId,
            content: sentText
          }
        });
      } else {
        // Demo mode - simulate response
        setIsTyping(true);
        setTimeout(() => {
          setIsTyping(false);
          const responseMessage: Message = {
            id: (Date.now() + 1).toString(),
            senderId: '2',
            content: getRandomResponse(),
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            type: 'text'
          };
          setMessages(prev => [...prev, responseMessage]);
        }, 1500 + Math.random() * 1000);
      }
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setIsSending(false);
    }
  };

  const getRandomResponse = () => {
    const responses = [
      "That's interesting! Tell me more.",
      "I totally agree with you!",
      "Sounds great! 😊",
      "Let me think about that...",
      "Awesome! Can't wait!",
      "Thanks for sharing that!",
      "I was just thinking the same thing!",
      "That made my day! 🎉"
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };

  const filteredConversations = conversations.filter(conv => 
    conv.participants.some(p => 
      p.name.toLowerCase().includes(searchQuery.toLowerCase())
    )
  );

  const getOtherParticipant = (conv: Conversation): User => {
    return conv.participants.find(p => p.id !== currentUser.id) || conv.participants[0];
  };

  const getOtherUser = (conv: Conversation | ChatConversation) => {
    if ('other_user' in conv) {
      return conv.other_user;
    }
    const participant = getOtherParticipant(conv as Conversation);
    return {
      user_id: participant.id,
      full_name: participant.name,
      username: participant.username,
      avatar_url: participant.avatar,
      is_online: participant.isOnline
    };
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl h-[85vh] bg-white rounded-2xl shadow-2xl flex overflow-hidden animate-fadeIn">
        {/* Conversations List */}
        <div className={`${selectedConversation ? 'hidden md:flex' : 'flex'} flex-col w-full md:w-96 border-r border-gray-200`}>
          {/* Header */}
          <div className="p-4 border-b border-gray-100 bg-gradient-to-r from-blue-500 to-purple-500">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold text-white">Messages</h2>
              <div className="flex items-center gap-2">
                <button className="w-9 h-9 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors">
                  <Edit className="w-5 h-5 text-white" />
                </button>
                <button 
                  onClick={onClose}
                  className="w-9 h-9 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
                >
                  <X className="w-5 h-5 text-white" />
                </button>
              </div>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-white rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-white/50 shadow-lg"
              />
            </div>
          </div>

          {/* Online Users */}
          <div className="p-3 border-b border-gray-100">
            <p className="text-xs font-semibold text-gray-500 mb-2">ACTIVE NOW</p>
            <div className="flex gap-3 overflow-x-auto pb-1">
              {users.filter(u => u.isOnline).slice(0, 6).map(user => (
                <button key={user.id} className="flex flex-col items-center gap-1 flex-shrink-0">
                  <div className="relative">
                    <img 
                      src={user.avatar}
                      alt={user.name}
                      className="w-12 h-12 rounded-full object-cover ring-2 ring-green-500"
                    />
                    <div className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-green-500 rounded-full border-2 border-white" />
                  </div>
                  <span className="text-xs text-gray-600 truncate w-12 text-center">{user.name.split(' ')[0]}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Conversations */}
          <div className="flex-1 overflow-y-auto">
            {/* Database conversations */}
            {dbConversations.map((conv) => (
              <button
                key={conv.id}
                onClick={() => handleSelectConversation(conv)}
                className={`w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 transition-colors ${
                  selectedConversation && 'id' in selectedConversation && selectedConversation.id === conv.id ? 'bg-blue-50' : ''
                }`}
              >
                <div className="relative flex-shrink-0">
                  <img 
                    src={conv.other_user.avatar_url || '/placeholder.svg'}
                    alt={conv.other_user.full_name}
                    className="w-14 h-14 rounded-full object-cover"
                  />
                  {conv.other_user.is_online && (
                    <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 rounded-full border-2 border-white" />
                  )}
                </div>
                <div className="flex-1 min-w-0 text-left">
                  <div className="flex items-center justify-between">
                    <p className="font-semibold text-gray-900 truncate">{conv.other_user.full_name}</p>
                    <span className="text-xs text-gray-500">
                      {new Date(conv.last_message_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-sm text-gray-500 truncate">{conv.last_message || 'Start a conversation'}</p>
                </div>
              </button>
            ))}

            {/* Demo conversations */}
            {filteredConversations.map((conv) => {
              const otherUser = getOtherParticipant(conv);
              return (
                <button
                  key={conv.id}
                  onClick={() => handleSelectConversation(conv)}
                  className={`w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 transition-colors ${
                    selectedConversation && 'id' in selectedConversation && selectedConversation.id === conv.id ? 'bg-blue-50' : ''
                  }`}
                >
                  <div className="relative flex-shrink-0">
                    <img 
                      src={otherUser.avatar}
                      alt={otherUser.name}
                      className="w-14 h-14 rounded-full object-cover"
                    />
                    {otherUser.isOnline && (
                      <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 rounded-full border-2 border-white" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0 text-left">
                    <div className="flex items-center justify-between">
                      <p className={`font-semibold truncate ${conv.unreadCount > 0 ? 'text-gray-900' : 'text-gray-700'}`}>
                        {otherUser.name}
                      </p>
                      <span className="text-xs text-gray-500">{conv.lastMessage.timestamp}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <p className={`text-sm truncate ${conv.unreadCount > 0 ? 'text-gray-900 font-medium' : 'text-gray-500'}`}>
                        {conv.lastMessage.sender.id === currentUser.id ? 'You: ' : ''}
                        {conv.lastMessage.content}
                      </p>
                      {conv.unreadCount > 0 && (
                        <span className="w-5 h-5 bg-blue-500 text-white text-xs rounded-full flex items-center justify-center flex-shrink-0">
                          {conv.unreadCount}
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Chat Area */}
        {selectedConversation ? (
          <div className="flex-1 flex flex-col">
            {/* Chat Header */}
            <div className="p-4 border-b border-gray-100 flex items-center justify-between bg-white">
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => setSelectedConversation(null)}
                  className="md:hidden w-9 h-9 rounded-full hover:bg-gray-100 flex items-center justify-center"
                >
                  <ArrowLeft className="w-5 h-5 text-gray-600" />
                </button>
                <div className="relative">
                  <img 
                    src={getOtherUser(selectedConversation).avatar_url || '/placeholder.svg'}
                    alt=""
                    className="w-11 h-11 rounded-full object-cover"
                  />
                  {getOtherUser(selectedConversation).is_online && (
                    <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white" />
                  )}
                </div>
                <div>
                  <p className="font-semibold text-gray-900">{getOtherUser(selectedConversation).full_name}</p>
                  <p className="text-xs text-gray-500">
                    {getOtherUser(selectedConversation).is_online ? (
                      <span className="text-green-500 font-medium">Active now</span>
                    ) : (
                      'Active 2h ago'
                    )}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button className="w-10 h-10 rounded-full hover:bg-gray-100 flex items-center justify-center text-blue-500">
                  <Phone className="w-5 h-5" />
                </button>
                <button className="w-10 h-10 rounded-full hover:bg-gray-100 flex items-center justify-center text-blue-500">
                  <Video className="w-5 h-5" />
                </button>
                <button className="w-10 h-10 rounded-full hover:bg-gray-100 flex items-center justify-center text-blue-500">
                  <Info className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gradient-to-b from-gray-50 to-white">
              {isLoading ? (
                <div className="flex items-center justify-center h-full">
                  <Loader2 className="w-8 h-8 text-blue-500 animate-spin" />
                </div>
              ) : (
                <>
                  {messages.map((message) => {
                    const isOwn = message.senderId === (profile?.user_id || currentUser.id);
                    return (
                      <div
                        key={message.id}
                        className={`flex items-end gap-2 ${isOwn ? 'flex-row-reverse' : ''}`}
                      >
                        {!isOwn && (
                          <img 
                            src={getOtherUser(selectedConversation).avatar_url || '/placeholder.svg'}
                            alt=""
                            className="w-7 h-7 rounded-full object-cover"
                          />
                        )}
                        <div className={`max-w-[70%] ${isOwn ? 'items-end' : 'items-start'}`}>
                          <div
                            className={`px-4 py-2.5 rounded-2xl ${
                              isOwn 
                                ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-br-md' 
                                : 'bg-white text-gray-900 rounded-bl-md shadow-sm border border-gray-100'
                            }`}
                          >
                            <p className="text-sm leading-relaxed">{message.content}</p>
                          </div>
                          <div className={`flex items-center gap-1 mt-1 ${isOwn ? 'justify-end' : ''}`}>
                            <p className="text-xs text-gray-400">{message.timestamp}</p>
                            {isOwn && (
                              <CheckCheck className={`w-3.5 h-3.5 ${message.isRead ? 'text-blue-500' : 'text-gray-400'}`} />
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                  
                  {/* Typing Indicator */}
                  {isTyping && (
                    <div className="flex items-end gap-2">
                      <img 
                        src={getOtherUser(selectedConversation).avatar_url || '/placeholder.svg'}
                        alt=""
                        className="w-7 h-7 rounded-full object-cover"
                      />
                      <div className="bg-white px-4 py-3 rounded-2xl rounded-bl-md shadow-sm border border-gray-100">
                        <div className="flex items-center gap-1">
                          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </>
              )}
            </div>

            {/* Message Input */}
            <div className="p-4 border-t border-gray-100 bg-white">
              <div className="flex items-center gap-2">
                <button className="w-10 h-10 rounded-full hover:bg-gray-100 flex items-center justify-center text-blue-500">
                  <Plus className="w-5 h-5" />
                </button>
                <button className="w-10 h-10 rounded-full hover:bg-gray-100 flex items-center justify-center text-blue-500">
                  <Image className="w-5 h-5" />
                </button>
                <button className="w-10 h-10 rounded-full hover:bg-gray-100 flex items-center justify-center text-blue-500">
                  <Mic className="w-5 h-5" />
                </button>
                <div className="flex-1 relative">
                  <input
                    type="text"
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && handleSendMessage()}
                    placeholder="Type a message..."
                    className="w-full px-4 py-2.5 bg-gray-100 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 pr-10"
                  />
                  <button className="absolute right-3 top-1/2 -translate-y-1/2">
                    <Smile className="w-5 h-5 text-gray-400 hover:text-blue-500 transition-colors" />
                  </button>
                </div>
                {messageText.trim() ? (
                  <button 
                    onClick={handleSendMessage}
                    disabled={isSending}
                    className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-500 to-blue-600 flex items-center justify-center hover:opacity-90 transition-opacity disabled:opacity-50"
                  >
                    {isSending ? (
                      <Loader2 className="w-5 h-5 text-white animate-spin" />
                    ) : (
                      <Send className="w-5 h-5 text-white" />
                    )}
                  </button>
                ) : (
                  <button className="w-10 h-10 rounded-full hover:bg-gray-100 flex items-center justify-center text-blue-500">
                    <ThumbsUp className="w-5 h-5" />
                  </button>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="hidden md:flex flex-1 items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50">
            <div className="text-center">
              <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                <Send className="w-12 h-12 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Your Messages</h3>
              <p className="text-gray-500 mb-6">Send private messages to friends</p>
              <button className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-full font-medium hover:opacity-90 transition-opacity">
                Start a Conversation
              </button>
            </div>
          </div>
        )}
      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.2s ease-out;
        }
      `}</style>
    </div>
  );
};

export default MessagesPanel;
