import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, MapPin, Navigation, Users, Clock, Shield,
  Settings, ChevronRight, MoreHorizontal, MessageCircle,
  Phone, Video, Coffee, Utensils, ShoppingBag, Dumbbell,
  Map, List, RefreshCw, Bell, Eye, EyeOff, Compass
} from 'lucide-react';
import { users, currentUser } from '../data/socialData';

interface NearbyFriend {
  id: string;
  user: typeof users[0];
  distance: string;
  lastSeen: string;
  location?: string;
  activity?: string;
  isActive: boolean;
}

interface NearbyFriendsPageProps {
  onBack: () => void;
}

const NearbyFriendsPage: React.FC<NearbyFriendsPageProps> = ({ onBack }) => {
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [locationEnabled, setLocationEnabled] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [selectedFriend, setSelectedFriend] = useState<NearbyFriend | null>(null);

  const [nearbyFriends] = useState<NearbyFriend[]>([
    {
      id: 'nf1',
      user: users[1],
      distance: '0.3 mi',
      lastSeen: 'Just now',
      location: 'Central Coffee Shop',
      activity: 'coffee',
      isActive: true
    },
    {
      id: 'nf2',
      user: users[3],
      distance: '0.5 mi',
      lastSeen: '5 min ago',
      location: 'Downtown Gym',
      activity: 'gym',
      isActive: true
    },
    {
      id: 'nf3',
      user: users[5],
      distance: '0.8 mi',
      lastSeen: '15 min ago',
      location: 'City Mall',
      activity: 'shopping',
      isActive: true
    },
    {
      id: 'nf4',
      user: users[7],
      distance: '1.2 mi',
      lastSeen: '30 min ago',
      location: 'Italian Restaurant',
      activity: 'food',
      isActive: false
    },
    {
      id: 'nf5',
      user: users[9],
      distance: '1.5 mi',
      lastSeen: '1 hour ago',
      isActive: false
    },
    {
      id: 'nf6',
      user: users[2],
      distance: '2.0 mi',
      lastSeen: '2 hours ago',
      isActive: false
    }
  ]);

  const getActivityIcon = (activity?: string) => {
    switch (activity) {
      case 'coffee': return <Coffee className="w-4 h-4" />;
      case 'food': return <Utensils className="w-4 h-4" />;
      case 'shopping': return <ShoppingBag className="w-4 h-4" />;
      case 'gym': return <Dumbbell className="w-4 h-4" />;
      default: return <MapPin className="w-4 h-4" />;
    }
  };

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 1500);
  };

  const activeFriends = nearbyFriends.filter(f => f.isActive);
  const recentFriends = nearbyFriends.filter(f => !f.isActive);

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-3xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <button 
                onClick={onBack}
                className="w-10 h-10 flex items-center justify-center hover:bg-gray-100 rounded-full transition-colors"
              >
                <ArrowLeft className="w-6 h-6 text-gray-700" />
              </button>
              <h1 className="text-2xl font-bold text-gray-900">Nearby Friends</h1>
            </div>
            <div className="flex items-center gap-2">
              <button 
                onClick={handleRefresh}
                className={`w-10 h-10 flex items-center justify-center hover:bg-gray-100 rounded-full transition-colors ${isRefreshing ? 'animate-spin' : ''}`}
              >
                <RefreshCw className="w-5 h-5 text-gray-600" />
              </button>
              <button 
                onClick={() => setShowSettings(true)}
                className="w-10 h-10 flex items-center justify-center hover:bg-gray-100 rounded-full transition-colors"
              >
                <Settings className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-6">
        {/* Location Status Banner */}
        {!locationEnabled && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 mb-6 flex items-center gap-3">
            <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center">
              <MapPin className="w-5 h-5 text-yellow-600" />
            </div>
            <div className="flex-1">
              <p className="font-medium text-yellow-800">Location is turned off</p>
              <p className="text-sm text-yellow-600">Enable location to see nearby friends</p>
            </div>
            <button 
              onClick={() => setLocationEnabled(true)}
              className="px-4 py-2 bg-yellow-500 text-white rounded-lg font-medium hover:bg-yellow-600 transition-colors"
            >
              Enable
            </button>
          </div>
        )}

        {/* Your Location Card */}
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl p-6 mb-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                <Navigation className="w-6 h-6" />
              </div>
              <div>
                <p className="font-bold text-lg">Your Location</p>
                <p className="text-blue-100 text-sm">Downtown, San Francisco</p>
              </div>
            </div>
            <button 
              onClick={() => setLocationEnabled(!locationEnabled)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                locationEnabled 
                  ? 'bg-white/20 hover:bg-white/30' 
                  : 'bg-white text-blue-600 hover:bg-blue-50'
              }`}
            >
              {locationEnabled ? 'Sharing On' : 'Turn On'}
            </button>
          </div>
          <div className="flex items-center gap-6 text-sm">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              <span>{activeFriends.length} friends nearby</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>Updated just now</span>
            </div>
          </div>
        </div>

        {/* View Toggle */}
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-900">Friends Nearby</h2>
          <div className="flex bg-white rounded-lg p-1 shadow-sm">
            <button
              onClick={() => setViewMode('list')}
              className={`px-3 py-1.5 rounded-md font-medium text-sm transition-colors ${
                viewMode === 'list' ? 'bg-blue-500 text-white' : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <List className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('map')}
              className={`px-3 py-1.5 rounded-md font-medium text-sm transition-colors ${
                viewMode === 'map' ? 'bg-blue-500 text-white' : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <Map className="w-4 h-4" />
            </button>
          </div>
        </div>

        {viewMode === 'list' ? (
          <>
            {/* Active Now */}
            {activeFriends.length > 0 && (
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  <span className="text-sm font-medium text-gray-500">Active Now</span>
                </div>
                <div className="space-y-3">
                  {activeFriends.map(friend => (
                    <div 
                      key={friend.id}
                      onClick={() => setSelectedFriend(friend)}
                      className="bg-white rounded-xl shadow-sm p-4 hover:shadow-md transition-shadow cursor-pointer"
                    >
                      <div className="flex items-center gap-4">
                        <div className="relative">
                          <img 
                            src={friend.user.avatar}
                            alt={friend.user.name}
                            className="w-14 h-14 rounded-full object-cover"
                          />
                          <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 rounded-full border-2 border-white" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold text-gray-900">{friend.user.name}</h3>
                            {friend.user.isVerified && (
                              <svg className="w-4 h-4 text-blue-500" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/>
                              </svg>
                            )}
                          </div>
                          {friend.location && (
                            <div className="flex items-center gap-1 text-sm text-gray-500 mt-1">
                              {getActivityIcon(friend.activity)}
                              <span>{friend.location}</span>
                            </div>
                          )}
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-blue-600">{friend.distance}</p>
                          <p className="text-xs text-gray-500">{friend.lastSeen}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Recently Nearby */}
            {recentFriends.length > 0 && (
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Clock className="w-4 h-4 text-gray-400" />
                  <span className="text-sm font-medium text-gray-500">Recently Nearby</span>
                </div>
                <div className="space-y-3">
                  {recentFriends.map(friend => (
                    <div 
                      key={friend.id}
                      className="bg-white rounded-xl shadow-sm p-4 opacity-75"
                    >
                      <div className="flex items-center gap-4">
                        <img 
                          src={friend.user.avatar}
                          alt={friend.user.name}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                        <div className="flex-1">
                          <h3 className="font-medium text-gray-900">{friend.user.name}</h3>
                          <p className="text-sm text-gray-500">{friend.lastSeen}</p>
                        </div>
                        <p className="text-gray-500">{friend.distance}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        ) : (
          /* Map View */
          <div className="bg-white rounded-xl shadow-sm overflow-hidden">
            <div className="h-96 bg-gray-200 relative flex items-center justify-center">
              <div className="text-center">
                <Compass className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500 font-medium">Map View</p>
                <p className="text-sm text-gray-400">Interactive map coming soon</p>
              </div>
              
              {/* Friend Markers (simulated) */}
              {activeFriends.map((friend, idx) => (
                <div 
                  key={friend.id}
                  className="absolute"
                  style={{ 
                    top: `${30 + idx * 15}%`, 
                    left: `${20 + idx * 20}%` 
                  }}
                >
                  <div className="relative">
                    <img 
                      src={friend.user.avatar}
                      alt={friend.user.name}
                      className="w-10 h-10 rounded-full border-3 border-white shadow-lg"
                    />
                    <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-8 border-transparent border-t-white" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Privacy Notice */}
        <div className="mt-6 bg-blue-50 rounded-xl p-4 flex items-start gap-3">
          <Shield className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-medium text-blue-900">Your privacy is protected</p>
            <p className="text-sm text-blue-700">Only friends you've chosen can see your location. You can change this anytime in settings.</p>
          </div>
        </div>
      </div>

      {/* Friend Detail Modal */}
      {selectedFriend && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center">
          <div 
            className="absolute inset-0"
            onClick={() => setSelectedFriend(null)}
          />
          <div className="relative bg-white rounded-t-3xl sm:rounded-2xl w-full sm:max-w-md p-6 animate-slideUp">
            <div className="flex items-center gap-4 mb-6">
              <img 
                src={selectedFriend.user.avatar}
                alt={selectedFriend.user.name}
                className="w-16 h-16 rounded-full object-cover"
              />
              <div>
                <h3 className="font-bold text-xl text-gray-900">{selectedFriend.user.name}</h3>
                <p className="text-gray-500">{selectedFriend.distance} away</p>
              </div>
            </div>

            {selectedFriend.location && (
              <div className="bg-gray-50 rounded-xl p-4 mb-4 flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  {getActivityIcon(selectedFriend.activity)}
                </div>
                <div>
                  <p className="font-medium text-gray-900">{selectedFriend.location}</p>
                  <p className="text-sm text-gray-500">{selectedFriend.lastSeen}</p>
                </div>
              </div>
            )}

            <div className="grid grid-cols-3 gap-3 mb-4">
              <button className="flex flex-col items-center gap-2 py-4 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors">
                <MessageCircle className="w-6 h-6 text-blue-600" />
                <span className="text-sm font-medium text-blue-600">Message</span>
              </button>
              <button className="flex flex-col items-center gap-2 py-4 bg-green-50 rounded-xl hover:bg-green-100 transition-colors">
                <Phone className="w-6 h-6 text-green-600" />
                <span className="text-sm font-medium text-green-600">Call</span>
              </button>
              <button className="flex flex-col items-center gap-2 py-4 bg-purple-50 rounded-xl hover:bg-purple-100 transition-colors">
                <Video className="w-6 h-6 text-purple-600" />
                <span className="text-sm font-medium text-purple-600">Video</span>
              </button>
            </div>

            <button className="w-full py-3 bg-blue-500 text-white rounded-xl font-semibold hover:bg-blue-600 transition-colors flex items-center justify-center gap-2">
              <Navigation className="w-5 h-5" />
              Get Directions
            </button>
          </div>
        </div>
      )}

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md">
            <div className="p-6 border-b flex items-center justify-between">
              <h2 className="text-xl font-bold text-gray-900">Location Settings</h2>
              <button 
                onClick={() => setShowSettings(false)}
                className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center"
              >
                <span className="text-gray-500 text-xl">&times;</span>
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-gray-600" />
                  <div>
                    <p className="font-medium text-gray-900">Share Location</p>
                    <p className="text-sm text-gray-500">Let friends see where you are</p>
                  </div>
                </div>
                <button 
                  onClick={() => setLocationEnabled(!locationEnabled)}
                  className={`w-12 h-6 rounded-full relative transition-colors ${
                    locationEnabled ? 'bg-blue-500' : 'bg-gray-300'
                  }`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${
                    locationEnabled ? 'right-1' : 'left-1'
                  }`} />
                </button>
              </div>

              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                <div className="flex items-center gap-3">
                  <Bell className="w-5 h-5 text-gray-600" />
                  <div>
                    <p className="font-medium text-gray-900">Notifications</p>
                    <p className="text-sm text-gray-500">Get notified when friends are nearby</p>
                  </div>
                </div>
                <button className="w-12 h-6 bg-blue-500 rounded-full relative">
                  <div className="absolute top-1 right-1 w-4 h-4 bg-white rounded-full" />
                </button>
              </div>

              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                <div className="flex items-center gap-3">
                  <Eye className="w-5 h-5 text-gray-600" />
                  <div>
                    <p className="font-medium text-gray-900">Precise Location</p>
                    <p className="text-sm text-gray-500">Show exact location vs. approximate</p>
                  </div>
                </div>
                <button className="w-12 h-6 bg-gray-300 rounded-full relative">
                  <div className="absolute top-1 left-1 w-4 h-4 bg-white rounded-full" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes slideUp {
          from { transform: translateY(100%); }
          to { transform: translateY(0); }
        }
        .animate-slideUp {
          animation: slideUp 0.3s ease-out;
        }
      `}</style>
    </div>
  );
};

export default NearbyFriendsPage;
