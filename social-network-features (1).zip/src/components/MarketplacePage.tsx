import React, { useState } from 'react';
import { users } from '../data/socialData';
import { 
  Search, MapPin, SlidersHorizontal, Heart, MessageCircle,
  Car, Home, Smartphone, Shirt, Sofa, Dumbbell, Music, Gamepad2,
  ChevronRight, Plus, MoreHorizontal, Share2, Flag, X
} from 'lucide-react';

interface MarketplacePageProps {
  onBack: () => void;
}

const MarketplacePage: React.FC<MarketplacePageProps> = ({ onBack }) => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [savedItems, setSavedItems] = useState<string[]>([]);

  const categories = [
    { id: 'all', label: 'All Categories', icon: null },
    { id: 'vehicles', label: 'Vehicles', icon: Car },
    { id: 'property', label: 'Property Rentals', icon: Home },
    { id: 'electronics', label: 'Electronics', icon: Smartphone },
    { id: 'clothing', label: 'Clothing', icon: Shirt },
    { id: 'furniture', label: 'Home & Garden', icon: Sofa },
    { id: 'sports', label: 'Sports', icon: Dumbbell },
    { id: 'music', label: 'Musical Instruments', icon: Music },
    { id: 'gaming', label: 'Gaming', icon: Gamepad2 }
  ];

  const listings = [
    {
      id: 'l1',
      title: 'iPhone 15 Pro Max - Like New',
      price: 899,
      image: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298773815_6b3b8d77.png',
      location: 'San Francisco, CA',
      seller: users[1],
      category: 'electronics',
      condition: 'Like New',
      description: 'Selling my iPhone 15 Pro Max. Used for only 2 months. Comes with original box and accessories.',
      postedAt: '2 hours ago'
    },
    {
      id: 'l2',
      title: 'Vintage Leather Sofa',
      price: 450,
      image: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298672761_8e473f6e.jpg',
      location: 'Austin, TX',
      seller: users[4],
      category: 'furniture',
      condition: 'Good',
      description: 'Beautiful vintage leather sofa in great condition. Minor wear consistent with age.',
      postedAt: '5 hours ago'
    },
    {
      id: 'l3',
      title: '2020 Tesla Model 3',
      price: 35000,
      image: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298748674_67ccb172.png',
      location: 'Los Angeles, CA',
      seller: users[7],
      category: 'vehicles',
      condition: 'Excellent',
      description: 'Low mileage Tesla Model 3. Full self-driving capability. One owner.',
      postedAt: '1 day ago'
    },
    {
      id: 'l4',
      title: 'Gaming PC - RTX 4080',
      price: 1800,
      image: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298743451_fdf3e0a7.png',
      location: 'Seattle, WA',
      seller: users[9],
      category: 'electronics',
      condition: 'New',
      description: 'Custom built gaming PC with RTX 4080, i9 processor, 64GB RAM.',
      postedAt: '3 hours ago'
    },
    {
      id: 'l5',
      title: 'Mountain Bike - Trek',
      price: 650,
      image: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298687191_91fbdc32.png',
      location: 'Denver, CO',
      seller: users[11],
      category: 'sports',
      condition: 'Good',
      description: 'Trek mountain bike, perfect for trails. Recently serviced.',
      postedAt: '6 hours ago'
    },
    {
      id: 'l6',
      title: 'Designer Jacket - Gucci',
      price: 800,
      image: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681505_56062067.png',
      location: 'New York, NY',
      seller: users[6],
      category: 'clothing',
      condition: 'Like New',
      description: 'Authentic Gucci jacket. Size M. Worn twice.',
      postedAt: '8 hours ago'
    },
    {
      id: 'l7',
      title: 'Fender Stratocaster Guitar',
      price: 1200,
      image: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298743519_6c3f2456.jpg',
      location: 'Nashville, TN',
      seller: users[5],
      category: 'music',
      condition: 'Excellent',
      description: 'American Fender Stratocaster. Sunburst finish. Includes hard case.',
      postedAt: '12 hours ago'
    },
    {
      id: 'l8',
      title: 'PS5 + 10 Games Bundle',
      price: 550,
      image: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298750501_53b91201.png',
      location: 'Chicago, IL',
      seller: users[10],
      category: 'gaming',
      condition: 'Like New',
      description: 'PS5 disc edition with 10 popular games. Extra controller included.',
      postedAt: '1 day ago'
    }
  ];

  const filteredListings = listings.filter(item => {
    const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const toggleSave = (itemId: string) => {
    setSavedItems(prev => 
      prev.includes(itemId) 
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm p-4 sticky top-20">
              <div className="flex items-center justify-between mb-4">
                <h1 className="text-2xl font-bold text-gray-900">Marketplace</h1>
              </div>

              {/* Search */}
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search Marketplace"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-gray-100 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Location */}
              <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-gray-100 transition-colors text-gray-700 mb-2">
                <MapPin className="w-5 h-5" />
                <span className="font-medium">San Francisco · 40 mi</span>
                <ChevronRight className="w-4 h-4 ml-auto" />
              </button>

              {/* Filters */}
              <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-gray-100 transition-colors text-gray-700 mb-4">
                <SlidersHorizontal className="w-5 h-5" />
                <span className="font-medium">Filters</span>
              </button>

              {/* Create Listing */}
              <button className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors mb-4">
                <Plus className="w-5 h-5" />
                Create new listing
              </button>

              {/* Categories */}
              <div className="border-t border-gray-200 pt-4">
                <h3 className="font-semibold text-gray-500 text-sm mb-3">Categories</h3>
                <nav className="space-y-1">
                  {categories.map((category) => (
                    <button
                      key={category.id}
                      onClick={() => setActiveCategory(category.id)}
                      className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                        activeCategory === category.id 
                          ? 'bg-blue-50 text-blue-600' 
                          : 'hover:bg-gray-100 text-gray-700'
                      }`}
                    >
                      {category.icon && <category.icon className="w-5 h-5" />}
                      <span className="font-medium text-sm">{category.label}</span>
                    </button>
                  ))}
                </nav>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-gray-900">
                {activeCategory === 'all' ? "Today's picks" : categories.find(c => c.id === activeCategory)?.label}
              </h2>
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <span>{filteredListings.length} items</span>
              </div>
            </div>

            {/* Listings Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-4">
              {filteredListings.map((item) => (
                <div 
                  key={item.id}
                  onClick={() => setSelectedItem(item)}
                  className="bg-white rounded-xl shadow-sm overflow-hidden cursor-pointer hover:shadow-md transition-shadow group"
                >
                  <div className="relative aspect-square">
                    <img 
                      src={item.image}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleSave(item.id);
                      }}
                      className={`absolute top-2 right-2 w-8 h-8 rounded-full flex items-center justify-center transition-colors ${
                        savedItems.includes(item.id)
                          ? 'bg-red-500 text-white'
                          : 'bg-white/90 text-gray-600 hover:bg-white'
                      }`}
                    >
                      <Heart className={`w-4 h-4 ${savedItems.includes(item.id) ? 'fill-current' : ''}`} />
                    </button>
                  </div>
                  <div className="p-3">
                    <p className="font-bold text-gray-900">${item.price.toLocaleString()}</p>
                    <h3 className="text-sm text-gray-700 truncate">{item.title}</h3>
                    <p className="text-xs text-gray-500 mt-1">{item.location}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Item Detail Modal */}
      {selectedItem && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-4xl bg-white rounded-xl shadow-2xl overflow-hidden animate-fadeIn max-h-[90vh] overflow-y-auto">
            <div className="grid grid-cols-1 md:grid-cols-2">
              {/* Image */}
              <div className="relative aspect-square md:aspect-auto md:h-full">
                <img 
                  src={selectedItem.image}
                  alt={selectedItem.title}
                  className="w-full h-full object-cover"
                />
                <button 
                  onClick={() => setSelectedItem(null)}
                  className="absolute top-4 left-4 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-gray-100 transition-colors"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              {/* Details */}
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <p className="text-3xl font-bold text-gray-900">${selectedItem.price.toLocaleString()}</p>
                    <h2 className="text-xl text-gray-700 mt-1">{selectedItem.title}</h2>
                  </div>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => toggleSave(selectedItem.id)}
                      className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${
                        savedItems.includes(selectedItem.id)
                          ? 'bg-red-100 text-red-500'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      <Heart className={`w-5 h-5 ${savedItems.includes(selectedItem.id) ? 'fill-current' : ''}`} />
                    </button>
                    <button className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors">
                      <Share2 className="w-5 h-5 text-gray-600" />
                    </button>
                    <button className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors">
                      <MoreHorizontal className="w-5 h-5 text-gray-600" />
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
                  <MapPin className="w-4 h-4" />
                  <span>{selectedItem.location}</span>
                  <span>·</span>
                  <span>Listed {selectedItem.postedAt}</span>
                </div>

                <div className="flex items-center gap-2 mb-6">
                  <span className="px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-700">
                    {selectedItem.condition}
                  </span>
                  <span className="px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-700 capitalize">
                    {selectedItem.category}
                  </span>
                </div>

                <div className="mb-6">
                  <h3 className="font-semibold text-gray-900 mb-2">Description</h3>
                  <p className="text-gray-600">{selectedItem.description}</p>
                </div>

                {/* Seller Info */}
                <div className="border-t border-gray-200 pt-4 mb-6">
                  <h3 className="font-semibold text-gray-900 mb-3">Seller information</h3>
                  <div className="flex items-center gap-3">
                    <img 
                      src={selectedItem.seller.avatar}
                      alt={selectedItem.seller.name}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div>
                      <p className="font-semibold text-gray-900">{selectedItem.seller.name}</p>
                      <p className="text-sm text-gray-500">Joined {selectedItem.seller.joinDate || '2020'}</p>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="space-y-3">
                  <button className="w-full py-3 bg-blue-500 text-white rounded-lg font-semibold hover:bg-blue-600 transition-colors flex items-center justify-center gap-2">
                    <MessageCircle className="w-5 h-5" />
                    Message Seller
                  </button>
                  <button className="w-full py-3 bg-gray-100 text-gray-700 rounded-lg font-semibold hover:bg-gray-200 transition-colors">
                    Make Offer
                  </button>
                </div>

                <button className="flex items-center gap-2 text-gray-500 text-sm mt-4 hover:text-gray-700">
                  <Flag className="w-4 h-4" />
                  Report listing
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MarketplacePage;
