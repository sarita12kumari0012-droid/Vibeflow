import React, { useState } from 'react';
import { Post, Comment } from '../data/socialData';
import { 
  MoreHorizontal, Globe, Users, Lock, ThumbsUp, Heart, 
  Laugh, Frown, Angry, MessageCircle, Share2, Bookmark,
  Send, Image, Smile, X, ChevronDown, ChevronUp
} from 'lucide-react';

interface PostCardProps {
  post: Post;
  onLike: (postId: string) => void;
  onComment: (postId: string, comment: string) => void;
  onShare: (postId: string) => void;
  onSave: (postId: string) => void;
}

const reactionIcons = {
  like: { icon: ThumbsUp, color: 'text-blue-500', bg: 'bg-blue-500' },
  love: { icon: Heart, color: 'text-red-500', bg: 'bg-red-500' },
  haha: { icon: Laugh, color: 'text-yellow-500', bg: 'bg-yellow-500' },
  wow: { icon: () => <span className="text-lg">😮</span>, color: 'text-yellow-500', bg: 'bg-yellow-500' },
  sad: { icon: Frown, color: 'text-yellow-500', bg: 'bg-yellow-500' },
  angry: { icon: Angry, color: 'text-orange-500', bg: 'bg-orange-500' }
};

const privacyIcons = {
  public: Globe,
  friends: Users,
  private: Lock
};

const PostCard: React.FC<PostCardProps> = ({ post, onLike, onComment, onShare, onSave }) => {
  const [showReactions, setShowReactions] = useState(false);
  const [selectedReaction, setSelectedReaction] = useState<string | null>(
    post.reactions.find(r => r.userReacted)?.type || null
  );
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [showAllComments, setShowAllComments] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [isSaved, setIsSaved] = useState(post.isSaved);
  const [imageIndex, setImageIndex] = useState(0);

  const totalReactions = post.reactions.reduce((acc, r) => acc + r.count, 0);
  const PrivacyIcon = privacyIcons[post.privacy];

  const handleReaction = (type: string) => {
    setSelectedReaction(selectedReaction === type ? null : type);
    setShowReactions(false);
    onLike(post.id);
  };

  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (commentText.trim()) {
      onComment(post.id, commentText);
      setCommentText('');
    }
  };

  const handleSave = () => {
    setIsSaved(!isSaved);
    onSave(post.id);
  };

  const displayedComments = showAllComments ? post.comments : post.comments.slice(0, 2);

  return (
    <article className="bg-white rounded-xl shadow-sm overflow-hidden mb-4 transition-all hover:shadow-md">
      {/* Post Header */}
      <div className="p-4 flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            <img 
              src={post.user.avatar}
              alt={post.user.name}
              className="w-11 h-11 rounded-full object-cover"
            />
            {post.user.isOnline && (
              <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white" />
            )}
          </div>
          <div>
            <div className="flex items-center gap-1">
              <h3 className="font-semibold text-gray-900 hover:underline cursor-pointer">
                {post.user.name}
              </h3>
              {post.user.isVerified && (
                <svg className="w-4 h-4 text-blue-500" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/>
                </svg>
              )}
              {post.feeling && (
                <span className="text-gray-500 text-sm">is feeling {post.feeling}</span>
              )}
            </div>
            <div className="flex items-center gap-1 text-xs text-gray-500">
              <span>{post.timestamp}</span>
              <span>·</span>
              <PrivacyIcon className="w-3 h-3" />
              {post.location && (
                <>
                  <span>·</span>
                  <span className="hover:underline cursor-pointer">{post.location}</span>
                </>
              )}
            </div>
          </div>
        </div>
        <div className="relative">
          <button 
            onClick={() => setShowMenu(!showMenu)}
            className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center transition-colors"
          >
            <MoreHorizontal className="w-5 h-5 text-gray-500" />
          </button>
          {showMenu && (
            <div className="absolute right-0 top-10 w-48 bg-white rounded-lg shadow-xl border border-gray-100 py-1 z-10">
              {['Save post', 'Hide post', 'Report post', 'Copy link'].map((item) => (
                <button 
                  key={item}
                  onClick={() => setShowMenu(false)}
                  className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50"
                >
                  {item}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Post Content */}
      <div className="px-4 pb-3">
        <p className="text-gray-900 whitespace-pre-wrap">{post.content}</p>
      </div>

      {/* Post Images */}
      {post.images && post.images.length > 0 && (
        <div className="relative">
          {post.images.length === 1 ? (
            <img 
              src={post.images[0]}
              alt="Post"
              className="w-full max-h-[500px] object-cover cursor-pointer"
            />
          ) : (
            <div className="grid grid-cols-2 gap-0.5">
              {post.images.slice(0, 4).map((img, idx) => (
                <div key={idx} className="relative aspect-square">
                  <img 
                    src={img}
                    alt={`Post ${idx + 1}`}
                    className="w-full h-full object-cover cursor-pointer"
                  />
                  {idx === 3 && post.images!.length > 4 && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <span className="text-white text-2xl font-bold">+{post.images!.length - 4}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Reactions & Stats */}
      <div className="px-4 py-2 flex items-center justify-between border-b border-gray-100">
        <div className="flex items-center gap-1">
          <div className="flex -space-x-1">
            {post.reactions.slice(0, 3).map((reaction, idx) => {
              const ReactionIcon = reactionIcons[reaction.type as keyof typeof reactionIcons];
              return (
                <div 
                  key={idx}
                  className={`w-5 h-5 ${ReactionIcon.bg} rounded-full flex items-center justify-center text-white text-xs`}
                >
                  {typeof ReactionIcon.icon === 'function' ? (
                    React.createElement(ReactionIcon.icon, { className: 'w-3 h-3' })
                  ) : (
                    <ReactionIcon.icon className="w-3 h-3" />
                  )}
                </div>
              );
            })}
          </div>
          <span className="text-sm text-gray-500 ml-1">{totalReactions.toLocaleString()}</span>
        </div>
        <div className="flex items-center gap-4 text-sm text-gray-500">
          <button 
            onClick={() => setShowComments(!showComments)}
            className="hover:underline"
          >
            {post.comments.length} comments
          </button>
          <span>{post.shares} shares</span>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="px-4 py-1 flex items-center justify-between border-b border-gray-100">
        <div 
          className="relative flex-1"
          onMouseEnter={() => setShowReactions(true)}
          onMouseLeave={() => setShowReactions(false)}
        >
          <button 
            onClick={() => handleReaction('like')}
            className={`w-full flex items-center justify-center gap-2 py-2 rounded-lg hover:bg-gray-100 transition-colors ${
              selectedReaction ? reactionIcons[selectedReaction as keyof typeof reactionIcons]?.color : 'text-gray-600'
            }`}
          >
            {selectedReaction ? (
              <>
                {React.createElement(
                  reactionIcons[selectedReaction as keyof typeof reactionIcons].icon,
                  { className: 'w-5 h-5' }
                )}
                <span className="font-medium capitalize">{selectedReaction}</span>
              </>
            ) : (
              <>
                <ThumbsUp className="w-5 h-5" />
                <span className="font-medium">Like</span>
              </>
            )}
          </button>
          
          {/* Reaction Picker */}
          {showReactions && (
            <div className="absolute bottom-full left-0 mb-2 bg-white rounded-full shadow-xl border border-gray-100 px-2 py-1 flex items-center gap-1 animate-fadeIn">
              {Object.entries(reactionIcons).map(([type, { icon: Icon, color }]) => (
                <button
                  key={type}
                  onClick={() => handleReaction(type)}
                  className={`w-10 h-10 rounded-full flex items-center justify-center hover:scale-125 transition-transform ${color}`}
                >
                  {typeof Icon === 'function' ? (
                    <Icon className="w-6 h-6" />
                  ) : (
                    <Icon />
                  )}
                </button>
              ))}
            </div>
          )}
        </div>

        <button 
          onClick={() => setShowComments(!showComments)}
          className="flex-1 flex items-center justify-center gap-2 py-2 rounded-lg hover:bg-gray-100 transition-colors text-gray-600"
        >
          <MessageCircle className="w-5 h-5" />
          <span className="font-medium">Comment</span>
        </button>

        <button 
          onClick={() => onShare(post.id)}
          className="flex-1 flex items-center justify-center gap-2 py-2 rounded-lg hover:bg-gray-100 transition-colors text-gray-600"
        >
          <Share2 className="w-5 h-5" />
          <span className="font-medium">Share</span>
        </button>

        <button 
          onClick={handleSave}
          className={`w-10 h-10 rounded-lg hover:bg-gray-100 flex items-center justify-center transition-colors ${
            isSaved ? 'text-blue-500' : 'text-gray-600'
          }`}
        >
          <Bookmark className={`w-5 h-5 ${isSaved ? 'fill-current' : ''}`} />
        </button>
      </div>

      {/* Comments Section */}
      {showComments && (
        <div className="p-4">
          {/* Comment Input */}
          <form onSubmit={handleSubmitComment} className="flex items-start gap-3 mb-4">
            <img 
              src={post.user.avatar}
              alt="Your avatar"
              className="w-8 h-8 rounded-full object-cover"
            />
            <div className="flex-1 relative">
              <input
                type="text"
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="Write a comment..."
                className="w-full px-4 py-2 bg-gray-100 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 pr-20"
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                <button type="button" className="p-1 hover:bg-gray-200 rounded-full">
                  <Smile className="w-4 h-4 text-gray-500" />
                </button>
                <button type="button" className="p-1 hover:bg-gray-200 rounded-full">
                  <Image className="w-4 h-4 text-gray-500" />
                </button>
                <button 
                  type="submit"
                  disabled={!commentText.trim()}
                  className="p-1 hover:bg-gray-200 rounded-full disabled:opacity-50"
                >
                  <Send className="w-4 h-4 text-blue-500" />
                </button>
              </div>
            </div>
          </form>

          {/* Comments List */}
          <div className="space-y-3">
            {displayedComments.map((comment) => (
              <CommentItem key={comment.id} comment={comment} />
            ))}
          </div>

          {post.comments.length > 2 && (
            <button 
              onClick={() => setShowAllComments(!showAllComments)}
              className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700 mt-3"
            >
              {showAllComments ? (
                <>
                  <ChevronUp className="w-4 h-4" />
                  Show less comments
                </>
              ) : (
                <>
                  <ChevronDown className="w-4 h-4" />
                  View {post.comments.length - 2} more comments
                </>
              )}
            </button>
          )}
        </div>
      )}
    </article>
  );
};

const CommentItem: React.FC<{ comment: Comment; isReply?: boolean }> = ({ comment, isReply = false }) => {
  const [showReplies, setShowReplies] = useState(false);
  const [liked, setLiked] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [showReplyInput, setShowReplyInput] = useState(false);

  return (
    <div className={`flex gap-2 ${isReply ? 'ml-10' : ''}`}>
      <img 
        src={comment.user.avatar}
        alt={comment.user.name}
        className={`${isReply ? 'w-6 h-6' : 'w-8 h-8'} rounded-full object-cover flex-shrink-0`}
      />
      <div className="flex-1">
        <div className="bg-gray-100 rounded-2xl px-3 py-2">
          <p className="font-semibold text-sm text-gray-900">{comment.user.name}</p>
          <p className="text-sm text-gray-700">{comment.content}</p>
        </div>
        <div className="flex items-center gap-4 mt-1 px-2">
          <button 
            onClick={() => setLiked(!liked)}
            className={`text-xs font-medium ${liked ? 'text-blue-500' : 'text-gray-500 hover:text-gray-700'}`}
          >
            Like
          </button>
          <button 
            onClick={() => setShowReplyInput(!showReplyInput)}
            className="text-xs font-medium text-gray-500 hover:text-gray-700"
          >
            Reply
          </button>
          <span className="text-xs text-gray-400">{comment.timestamp}</span>
          {comment.likes > 0 && (
            <div className="flex items-center gap-1 ml-auto">
              <ThumbsUp className="w-3 h-3 text-blue-500" />
              <span className="text-xs text-gray-500">{comment.likes}</span>
            </div>
          )}
        </div>

        {/* Reply Input */}
        {showReplyInput && (
          <div className="flex items-center gap-2 mt-2">
            <input
              type="text"
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              placeholder="Write a reply..."
              className="flex-1 px-3 py-1.5 bg-gray-100 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button 
              onClick={() => {
                setReplyText('');
                setShowReplyInput(false);
              }}
              className="text-xs text-blue-500 font-medium"
            >
              Post
            </button>
          </div>
        )}

        {/* Replies */}
        {comment.replies && comment.replies.length > 0 && (
          <>
            <button 
              onClick={() => setShowReplies(!showReplies)}
              className="text-xs text-gray-500 hover:text-gray-700 mt-2 flex items-center gap-1"
            >
              {showReplies ? 'Hide' : 'View'} {comment.replies.length} {comment.replies.length === 1 ? 'reply' : 'replies'}
            </button>
            {showReplies && (
              <div className="mt-2 space-y-2">
                {comment.replies.map((reply) => (
                  <CommentItem key={reply.id} comment={reply} isReply />
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default PostCard;
