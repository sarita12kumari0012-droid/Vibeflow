import React, { useState } from 'react';
import { 
  ArrowLeft, Bookmark, Search, Grid, List, MoreHorizontal,
  Folder, Plus, Image, Video, Link2, MapPin, Calendar,
  Heart, MessageCircle, Share2, Trash2, FolderPlus
} from 'lucide-react';
import { posts, users, currentUser } from '../data/socialData';

interface Collection {
  id: string;
  name: string;
  cover: string;
  itemCount: number;
}

interface SavedPostsPageProps {
  onBack: () => void;
}

const SavedPostsPage: React.FC<SavedPostsPageProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateCollection, setShowCreateCollection] = useState(false);
  const [newCollectionName, setNewCollectionName] = useState('');

  const [collections, setCollections] = useState<Collection[]>([
    { id: 'c1', name: 'Travel Inspiration', cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298748674_67ccb172.png', itemCount: 12 },
    { id: 'c2', name: 'Recipes', cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298672761_8e473f6e.jpg', itemCount: 8 },
    { id: 'c3', name: 'Fitness Tips', cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298770024_3c3895be.jpg', itemCount: 15 },
    { id: 'c4', name: 'Tech Articles', cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298773815_6b3b8d77.png', itemCount: 6 }
  ]);

  // Mock saved items
  const savedItems = [
    {
      id: 's1',
      type: 'post',
      user: users[2],
      content: 'Just captured this amazing sunset during my evening walk.',
      image: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298743451_fdf3e0a7.png',
      savedAt: '2 days ago',
      likes: 245,
      comments: 34
    },
    {
      id: 's2',
      type: 'post',
      user: users[4],
      content: 'Sunday brunch with the best crew! Nothing beats good food.',
      image: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298672761_8e473f6e.jpg',
      savedAt: '3 days ago',
      likes: 156,
      comments: 23
    },
    {
      id: 's3',
      type: 'video',
      user: users[5],
      content: 'New track preview! Let me know what you think.',
      image: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681347_8aa2cbbc.png',
      savedAt: '5 days ago',
      likes: 890,
      comments: 156
    },
    {
      id: 's4',
      type: 'post',
      user: users[3],
      content: 'New personal record at the gym today! Keep pushing!',
      image: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298770024_3c3895be.jpg',
      savedAt: '1 week ago',
      likes: 567,
      comments: 89
    },
    {
      id: 's5',
      type: 'link',
      user: users[7],
      content: 'Great article on startup funding strategies',
      image: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298773815_6b3b8d77.png',
      savedAt: '1 week ago',
      likes: 234,
      comments: 45
    },
    {
      id: 's6',
      type: 'post',
      user: users[11],
      content: 'Hiked to the summit today and the view was breathtaking!',
      image: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298748674_67ccb172.png',
      savedAt: '2 weeks ago',
      likes: 432,
      comments: 67
    }
  ];

  const tabs = [
    { id: 'all', label: 'All Saved', icon: Bookmark },
    { id: 'posts', label: 'Posts', icon: Image },
    { id: 'videos', label: 'Videos', icon: Video },
    { id: 'links', label: 'Links', icon: Link2 },
    { id: 'places', label: 'Places', icon: MapPin },
    { id: 'events', label: 'Events', icon: Calendar }
  ];

  const filteredItems = savedItems.filter(item => {
    const matchesSearch = item.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         item.user.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTab = activeTab === 'all' || item.type === activeTab.slice(0, -1);
    return matchesSearch && matchesTab;
  });

  const handleCreateCollection = () => {
    if (newCollectionName.trim()) {
      setCollections([
        ...collections,
        {
          id: `c${collections.length + 1}`,
          name: newCollectionName,
          cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681505_56062067.png',
          itemCount: 0
        }
      ]);
      setNewCollectionName('');
      setShowCreateCollection(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-5xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <button 
                onClick={onBack}
                className="w-10 h-10 flex items-center justify-center hover:bg-gray-100 rounded-full transition-colors"
              >
                <ArrowLeft className="w-6 h-6 text-gray-700" />
              </button>
              <div className="flex items-center gap-2">
                <Bookmark className="w-7 h-7 text-blue-500" />
                <h1 className="text-2xl font-bold text-gray-900">Saved</h1>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="relative hidden md:block">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search saved items..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-64 pl-10 pr-4 py-2 bg-gray-100 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="flex items-center bg-gray-100 rounded-lg p-1">
                <button 
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded-md transition-colors ${
                    viewMode === 'grid' ? 'bg-white shadow-sm' : 'hover:bg-gray-200'
                  }`}
                >
                  <Grid className="w-5 h-5 text-gray-600" />
                </button>
                <button 
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded-md transition-colors ${
                    viewMode === 'list' ? 'bg-white shadow-sm' : 'hover:bg-gray-200'
                  }`}
                >
                  <List className="w-5 h-5 text-gray-600" />
                </button>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex items-center gap-1 pb-3 overflow-x-auto">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-full font-medium text-sm whitespace-nowrap transition-colors ${
                  activeTab === tab.id
                    ? 'bg-blue-100 text-blue-600'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-6">
        <div className="flex gap-6">
          {/* Sidebar - Collections */}
          <aside className="w-64 flex-shrink-0 hidden lg:block">
            <div className="bg-white rounded-xl shadow-sm p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-900">Collections</h3>
                <button 
                  onClick={() => setShowCreateCollection(true)}
                  className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 hover:bg-blue-200 transition-colors"
                >
                  <Plus className="w-5 h-5" />
                </button>
              </div>
              <div className="space-y-2">
                {collections.map(collection => (
                  <button
                    key={collection.id}
                    className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <img 
                      src={collection.cover}
                      alt={collection.name}
                      className="w-12 h-12 rounded-lg object-cover"
                    />
                    <div className="flex-1 text-left">
                      <p className="font-medium text-gray-900 text-sm">{collection.name}</p>
                      <p className="text-xs text-gray-500">{collection.itemCount} items</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </aside>

          {/* Main Content */}
          <main className="flex-1">
            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              {[
                { label: 'Total Saved', value: savedItems.length, icon: Bookmark, color: 'blue' },
                { label: 'Posts', value: savedItems.filter(i => i.type === 'post').length, icon: Image, color: 'green' },
                { label: 'Videos', value: savedItems.filter(i => i.type === 'video').length, icon: Video, color: 'purple' },
                { label: 'Collections', value: collections.length, icon: Folder, color: 'orange' }
              ].map((stat, idx) => (
                <div key={idx} className="bg-white rounded-xl shadow-sm p-4">
                  <div className={`w-10 h-10 rounded-lg bg-${stat.color}-100 flex items-center justify-center mb-2`}>
                    <stat.icon className={`w-5 h-5 text-${stat.color}-600`} />
                  </div>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-sm text-gray-500">{stat.label}</p>
                </div>
              ))}
            </div>

            {/* Saved Items */}
            {viewMode === 'grid' ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredItems.map(item => (
                  <div key={item.id} className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow">
                    <div className="relative">
                      <img 
                        src={item.image}
                        alt=""
                        className="w-full h-48 object-cover"
                      />
                      {item.type === 'video' && (
                        <div className="absolute top-2 left-2 px-2 py-1 bg-black/70 rounded text-white text-xs flex items-center gap-1">
                          <Video className="w-3 h-3" />
                          Video
                        </div>
                      )}
                      <button className="absolute top-2 right-2 w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-md hover:bg-gray-100">
                        <MoreHorizontal className="w-5 h-5 text-gray-600" />
                      </button>
                    </div>
                    <div className="p-4">
                      <div className="flex items-center gap-3 mb-2">
                        <img 
                          src={item.user.avatar}
                          alt={item.user.name}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                        <div>
                          <p className="font-medium text-gray-900 text-sm">{item.user.name}</p>
                          <p className="text-xs text-gray-500">Saved {item.savedAt}</p>
                        </div>
                      </div>
                      <p className="text-sm text-gray-700 line-clamp-2 mb-3">{item.content}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4 text-sm text-gray-500">
                          <span className="flex items-center gap-1">
                            <Heart className="w-4 h-4" />
                            {item.likes}
                          </span>
                          <span className="flex items-center gap-1">
                            <MessageCircle className="w-4 h-4" />
                            {item.comments}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <button className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200">
                            <FolderPlus className="w-4 h-4 text-gray-600" />
                          </button>
                          <button className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center hover:bg-red-100 hover:text-red-600">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-3">
                {filteredItems.map(item => (
                  <div key={item.id} className="bg-white rounded-xl shadow-sm p-4 flex gap-4 hover:shadow-md transition-shadow">
                    <img 
                      src={item.image}
                      alt=""
                      className="w-32 h-24 rounded-lg object-cover flex-shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <img 
                          src={item.user.avatar}
                          alt={item.user.name}
                          className="w-6 h-6 rounded-full object-cover"
                        />
                        <span className="font-medium text-gray-900 text-sm">{item.user.name}</span>
                        <span className="text-xs text-gray-500">· Saved {item.savedAt}</span>
                      </div>
                      <p className="text-gray-700 line-clamp-2 mb-2">{item.content}</p>
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <span className="flex items-center gap-1">
                          <Heart className="w-4 h-4" />
                          {item.likes}
                        </span>
                        <span className="flex items-center gap-1">
                          <MessageCircle className="w-4 h-4" />
                          {item.comments}
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-col gap-2">
                      <button className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200">
                        <Share2 className="w-4 h-4 text-gray-600" />
                      </button>
                      <button className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center hover:bg-red-100 hover:text-red-600">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {filteredItems.length === 0 && (
              <div className="bg-white rounded-xl shadow-sm p-12 text-center">
                <Bookmark className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No saved items</h3>
                <p className="text-gray-500">Items you save will appear here</p>
              </div>
            )}
          </main>
        </div>
      </div>

      {/* Create Collection Modal */}
      {showCreateCollection && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowCreateCollection(false)} />
          <div className="relative bg-white rounded-2xl w-full max-w-md p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Create Collection</h2>
            <input
              type="text"
              placeholder="Collection name"
              value={newCollectionName}
              onChange={(e) => setNewCollectionName(e.target.value)}
              className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
            />
            <div className="flex gap-3">
              <button 
                onClick={() => setShowCreateCollection(false)}
                className="flex-1 py-2.5 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={handleCreateCollection}
                className="flex-1 py-2.5 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors"
              >
                Create
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SavedPostsPage;
