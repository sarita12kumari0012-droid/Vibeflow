import React, { useState } from 'react';
import { 
  ArrowLeft, Plus, Search, Star, Users, ThumbsUp, MessageCircle,
  Share2, MoreHorizontal, Globe, Lock, Settings, BarChart3,
  Image, Video, Calendar, Megaphone, DollarSign, TrendingUp,
  Heart, Bookmark, Bell, CheckCircle, MapPin, Phone, Mail, Link2
} from 'lucide-react';
import { users, currentUser } from '../data/socialData';

interface Page {
  id: string;
  name: string;
  category: string;
  cover: string;
  avatar: string;
  followers: number;
  likes: number;
  isVerified: boolean;
  isOwned: boolean;
  isFollowing: boolean;
  description: string;
  rating?: number;
  reviews?: number;
}

interface PagesPageProps {
  onBack: () => void;
}

const PagesPage: React.FC<PagesPageProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState('discover');
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('all');

  const [pages, setPages] = useState<Page[]>([
    {
      id: 'p1',
      name: 'Tech Innovators Hub',
      category: 'Technology Company',
      cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681347_8aa2cbbc.png',
      avatar: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298770024_3c3895be.jpg',
      followers: 125000,
      likes: 98000,
      isVerified: true,
      isOwned: true,
      isFollowing: true,
      description: 'Your daily dose of tech news, reviews, and innovations.',
      rating: 4.8,
      reviews: 1250
    },
    {
      id: 'p2',
      name: 'Fitness & Wellness',
      category: 'Health & Wellness',
      cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298743451_fdf3e0a7.png',
      avatar: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298672761_8e473f6e.jpg',
      followers: 89000,
      likes: 76000,
      isVerified: true,
      isOwned: false,
      isFollowing: true,
      description: 'Transform your life with expert fitness tips and wellness advice.',
      rating: 4.9,
      reviews: 890
    },
    {
      id: 'p3',
      name: 'Gourmet Kitchen',
      category: 'Food & Beverage',
      cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681505_56062067.png',
      avatar: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681347_8aa2cbbc.png',
      followers: 234000,
      likes: 198000,
      isVerified: true,
      isOwned: false,
      isFollowing: false,
      description: 'Delicious recipes, cooking tips, and culinary adventures.',
      rating: 4.7,
      reviews: 2100
    },
    {
      id: 'p4',
      name: 'Travel Adventures',
      category: 'Travel & Tourism',
      cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298770024_3c3895be.jpg',
      avatar: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298743451_fdf3e0a7.png',
      followers: 456000,
      likes: 389000,
      isVerified: true,
      isOwned: false,
      isFollowing: false,
      description: 'Explore the world with us! Travel tips, destinations, and inspiration.',
      rating: 4.9,
      reviews: 3400
    },
    {
      id: 'p5',
      name: 'Music Vibes',
      category: 'Entertainment',
      cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298672761_8e473f6e.jpg',
      avatar: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681505_56062067.png',
      followers: 567000,
      likes: 498000,
      isVerified: true,
      isOwned: false,
      isFollowing: true,
      description: 'The best music, artists, and concert updates.',
      rating: 4.6,
      reviews: 4500
    },
    {
      id: 'p6',
      name: 'Fashion Forward',
      category: 'Fashion & Beauty',
      cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681347_8aa2cbbc.png',
      avatar: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298770024_3c3895be.jpg',
      followers: 345000,
      likes: 298000,
      isVerified: false,
      isOwned: false,
      isFollowing: false,
      description: 'Latest fashion trends, style tips, and beauty hacks.',
      rating: 4.5,
      reviews: 1890
    }
  ]);

  const categories = [
    { id: 'all', label: 'All' },
    { id: 'technology', label: 'Technology' },
    { id: 'entertainment', label: 'Entertainment' },
    { id: 'food', label: 'Food & Drink' },
    { id: 'travel', label: 'Travel' },
    { id: 'health', label: 'Health' },
    { id: 'fashion', label: 'Fashion' },
    { id: 'sports', label: 'Sports' }
  ];

  const formatNumber = (num: number): string => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const handleFollow = (pageId: string) => {
    setPages(pages.map(page => {
      if (page.id === pageId) {
        return {
          ...page,
          isFollowing: !page.isFollowing,
          followers: page.isFollowing ? page.followers - 1 : page.followers + 1
        };
      }
      return page;
    }));
  };

  const myPages = pages.filter(p => p.isOwned);
  const followingPages = pages.filter(p => p.isFollowing && !p.isOwned);
  const discoverPages = pages.filter(p => !p.isFollowing);

  const filteredPages = (activeTab === 'your-pages' ? myPages : 
                        activeTab === 'following' ? followingPages : 
                        discoverPages).filter(page =>
    page.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
    (selectedCategory === 'all' || page.category.toLowerCase().includes(selectedCategory))
  );

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <button 
                onClick={onBack}
                className="w-10 h-10 flex items-center justify-center hover:bg-gray-100 rounded-full transition-colors"
              >
                <ArrowLeft className="w-6 h-6 text-gray-700" />
              </button>
              <h1 className="text-2xl font-bold text-gray-900">Pages</h1>
            </div>
            <button 
              onClick={() => setShowCreateModal(true)}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors flex items-center gap-2"
            >
              <Plus className="w-5 h-5" />
              Create Page
            </button>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 border-t border-gray-100">
            {[
              { id: 'discover', label: 'Discover' },
              { id: 'your-pages', label: 'Your Pages' },
              { id: 'following', label: 'Following' },
              { id: 'invites', label: 'Invites' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-6 py-3 font-medium transition-colors relative ${
                  activeTab === tab.id
                    ? 'text-blue-600'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                {tab.label}
                {activeTab === tab.id && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600" />
                )}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Search & Filter */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search pages..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-white rounded-xl border-0 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-full font-medium text-sm whitespace-nowrap transition-colors ${
                  selectedCategory === cat.id
                    ? 'bg-blue-500 text-white'
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Your Pages Section (if on your-pages tab) */}
        {activeTab === 'your-pages' && myPages.length > 0 && (
          <div className="mb-8">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Pages You Manage</h2>
            {myPages.map(page => (
              <div key={page.id} className="bg-white rounded-xl shadow-sm overflow-hidden mb-4">
                <div className="h-32 bg-cover bg-center" style={{ backgroundImage: `url(${page.cover})` }} />
                <div className="p-4">
                  <div className="flex items-start gap-4 -mt-12">
                    <img 
                      src={page.avatar}
                      alt={page.name}
                      className="w-20 h-20 rounded-xl object-cover border-4 border-white shadow-lg"
                    />
                    <div className="flex-1 pt-8">
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-xl text-gray-900">{page.name}</h3>
                        {page.isVerified && (
                          <CheckCircle className="w-5 h-5 text-blue-500 fill-blue-500" />
                        )}
                      </div>
                      <p className="text-gray-500 text-sm">{page.category}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-6 mt-4 pt-4 border-t">
                    <div className="text-center">
                      <p className="font-bold text-gray-900">{formatNumber(page.followers)}</p>
                      <p className="text-xs text-gray-500">Followers</p>
                    </div>
                    <div className="text-center">
                      <p className="font-bold text-gray-900">{formatNumber(page.likes)}</p>
                      <p className="text-xs text-gray-500">Likes</p>
                    </div>
                    <div className="flex-1" />
                    <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors flex items-center gap-2">
                      <Settings className="w-4 h-4" />
                      Manage
                    </button>
                    <button className="px-4 py-2 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors flex items-center gap-2">
                      <BarChart3 className="w-4 h-4" />
                      Insights
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Pages Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredPages.map(page => (
            <div key={page.id} className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow">
              <div className="h-28 bg-cover bg-center relative" style={{ backgroundImage: `url(${page.cover})` }}>
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
              </div>
              <div className="p-4">
                <div className="flex items-start gap-3 -mt-10 relative z-10">
                  <img 
                    src={page.avatar}
                    alt={page.name}
                    className="w-16 h-16 rounded-xl object-cover border-3 border-white shadow-lg"
                  />
                  <div className="flex-1 pt-6">
                    <div className="flex items-center gap-1">
                      <h3 className="font-bold text-gray-900 line-clamp-1">{page.name}</h3>
                      {page.isVerified && (
                        <CheckCircle className="w-4 h-4 text-blue-500 fill-blue-500 flex-shrink-0" />
                      )}
                    </div>
                    <p className="text-gray-500 text-xs">{page.category}</p>
                  </div>
                </div>

                <p className="text-sm text-gray-600 mt-3 line-clamp-2">{page.description}</p>

                <div className="flex items-center gap-4 mt-3">
                  <div className="flex items-center gap-1 text-sm text-gray-500">
                    <Users className="w-4 h-4" />
                    {formatNumber(page.followers)}
                  </div>
                  <div className="flex items-center gap-1 text-sm text-gray-500">
                    <ThumbsUp className="w-4 h-4" />
                    {formatNumber(page.likes)}
                  </div>
                  {page.rating && (
                    <div className="flex items-center gap-1 text-sm text-gray-500">
                      <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                      {page.rating}
                    </div>
                  )}
                </div>

                <div className="flex gap-2 mt-4">
                  <button 
                    onClick={() => handleFollow(page.id)}
                    className={`flex-1 py-2 rounded-lg font-medium transition-colors flex items-center justify-center gap-2 ${
                      page.isFollowing
                        ? 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        : 'bg-blue-500 text-white hover:bg-blue-600'
                    }`}
                  >
                    {page.isFollowing ? (
                      <>
                        <CheckCircle className="w-4 h-4" />
                        Following
                      </>
                    ) : (
                      <>
                        <Plus className="w-4 h-4" />
                        Follow
                      </>
                    )}
                  </button>
                  <button className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center hover:bg-gray-200 transition-colors">
                    <Share2 className="w-5 h-5 text-gray-600" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredPages.length === 0 && (
          <div className="bg-white rounded-xl shadow-sm p-8 text-center">
            <Globe className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No Pages Found</h3>
            <p className="text-gray-500 mb-4">Try adjusting your search or filters.</p>
            <button 
              onClick={() => setShowCreateModal(true)}
              className="px-6 py-2 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors"
            >
              Create a Page
            </button>
          </div>
        )}
      </div>

      {/* Create Page Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b sticky top-0 bg-white">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">Create a Page</h2>
                <button 
                  onClick={() => setShowCreateModal(false)}
                  className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200"
                >
                  <span className="text-gray-500 text-xl">&times;</span>
                </button>
              </div>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Page Name</label>
                <input 
                  type="text"
                  placeholder="Enter page name"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <select className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option>Select a category</option>
                  <option>Business</option>
                  <option>Brand or Product</option>
                  <option>Artist, Band or Public Figure</option>
                  <option>Entertainment</option>
                  <option>Community</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea 
                  placeholder="Tell people what your page is about"
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Profile Picture</label>
                <div className="border-2 border-dashed border-gray-200 rounded-xl p-8 text-center hover:border-blue-500 transition-colors cursor-pointer">
                  <Image className="w-10 h-10 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-500">Click to upload or drag and drop</p>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Cover Photo</label>
                <div className="border-2 border-dashed border-gray-200 rounded-xl p-8 text-center hover:border-blue-500 transition-colors cursor-pointer">
                  <Image className="w-10 h-10 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-500">Recommended: 820 x 312 pixels</p>
                </div>
              </div>

              <button className="w-full py-3 bg-blue-500 text-white rounded-xl font-semibold hover:bg-blue-600 transition-colors">
                Create Page
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PagesPage;
