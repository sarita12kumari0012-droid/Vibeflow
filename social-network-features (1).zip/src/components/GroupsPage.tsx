import React, { useState } from 'react';
import { groups, users, currentUser } from '../data/socialData';
import { 
  Search, Plus, Settings, ChevronRight, Users, Lock, Globe,
  Image, Calendar, Bell, MoreHorizontal, TrendingUp
} from 'lucide-react';

interface GroupsPageProps {
  onBack: () => void;
}

const GroupsPage: React.FC<GroupsPageProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState('feed');
  const [searchQuery, setSearchQuery] = useState('');

  const tabs = [
    { id: 'feed', label: 'Your Feed' },
    { id: 'discover', label: 'Discover' },
    { id: 'your-groups', label: 'Your Groups' }
  ];

  const categories = [
    'Technology', 'Health & Fitness', 'Art & Photography', 
    'Food & Drink', 'Gaming', 'Music', 'Travel', 'Business'
  ];

  const suggestedGroups = [
    {
      id: 'sg1',
      name: 'Web Developers Community',
      cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298773815_6b3b8d77.png',
      members: 125000,
      postsPerDay: 50,
      privacy: 'public',
      description: 'A community for web developers to share knowledge and resources'
    },
    {
      id: 'sg2',
      name: 'Startup Founders Network',
      cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298770024_3c3895be.jpg',
      members: 89000,
      postsPerDay: 35,
      privacy: 'private',
      description: 'Connect with fellow entrepreneurs and grow your business'
    },
    {
      id: 'sg3',
      name: 'Digital Nomads Worldwide',
      cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298743451_fdf3e0a7.png',
      members: 234000,
      postsPerDay: 120,
      privacy: 'public',
      description: 'For those who work remotely while traveling the world'
    },
    {
      id: 'sg4',
      name: 'AI & Machine Learning',
      cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298748674_67ccb172.png',
      members: 156000,
      postsPerDay: 80,
      privacy: 'public',
      description: 'Discuss the latest in AI and machine learning'
    }
  ];

  const groupPosts = [
    {
      id: 'gp1',
      group: groups[0],
      user: users[1],
      content: 'Just launched my new open-source project! Check it out and let me know what you think. Looking for contributors!',
      image: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298773815_6b3b8d77.png',
      likes: 234,
      comments: 45,
      timestamp: '2 hours ago'
    },
    {
      id: 'gp2',
      group: groups[1],
      user: users[3],
      content: 'Morning workout complete! 💪 Who else is crushing their fitness goals today? Share your progress!',
      image: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298672761_8e473f6e.jpg',
      likes: 567,
      comments: 89,
      timestamp: '4 hours ago'
    },
    {
      id: 'gp3',
      group: groups[2],
      user: users[2],
      content: 'Captured this amazing sunset yesterday. What do you think of the composition? Tips welcome!',
      image: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298743451_fdf3e0a7.png',
      likes: 892,
      comments: 123,
      timestamp: '6 hours ago'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm p-4 sticky top-20">
              <div className="flex items-center justify-between mb-4">
                <h1 className="text-2xl font-bold text-gray-900">Groups</h1>
                <button className="w-9 h-9 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors">
                  <Settings className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              {/* Search */}
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search groups"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-gray-100 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Navigation */}
              <nav className="space-y-1">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg transition-colors ${
                      activeTab === tab.id 
                        ? 'bg-blue-50 text-blue-600' 
                        : 'hover:bg-gray-100 text-gray-700'
                    }`}
                  >
                    <span className="font-medium">{tab.label}</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                ))}
              </nav>

              {/* Create Group Button */}
              <button className="w-full mt-4 flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors">
                <Plus className="w-5 h-5" />
                Create new group
              </button>

              {/* Your Groups */}
              <div className="mt-6">
                <h3 className="font-semibold text-gray-500 text-sm mb-3">Groups you've joined</h3>
                <div className="space-y-2">
                  {groups.map((group) => (
                    <button
                      key={group.id}
                      className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100 transition-colors"
                    >
                      <img 
                        src={group.cover}
                        alt={group.name}
                        className="w-12 h-12 rounded-lg object-cover"
                      />
                      <div className="flex-1 text-left">
                        <p className="font-medium text-gray-900 text-sm truncate">{group.name}</p>
                        <p className="text-xs text-gray-500">Last active 2h ago</p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {activeTab === 'feed' && (
              <>
                {/* Group Posts */}
                {groupPosts.map((post) => (
                  <div key={post.id} className="bg-white rounded-xl shadow-sm overflow-hidden">
                    {/* Group Header */}
                    <div className="p-4 flex items-center gap-3 border-b border-gray-100">
                      <img 
                        src={post.group.cover}
                        alt={post.group.name}
                        className="w-10 h-10 rounded-lg object-cover"
                      />
                      <div className="flex-1">
                        <p className="font-semibold text-gray-900">{post.group.name}</p>
                        <div className="flex items-center gap-2 text-xs text-gray-500">
                          <img 
                            src={post.user.avatar}
                            alt={post.user.name}
                            className="w-5 h-5 rounded-full object-cover"
                          />
                          <span>{post.user.name}</span>
                          <span>·</span>
                          <span>{post.timestamp}</span>
                        </div>
                      </div>
                      <button className="w-8 h-8 rounded-full hover:bg-gray-100 flex items-center justify-center">
                        <MoreHorizontal className="w-5 h-5 text-gray-500" />
                      </button>
                    </div>

                    {/* Post Content */}
                    <div className="p-4">
                      <p className="text-gray-900 mb-3">{post.content}</p>
                      {post.image && (
                        <img 
                          src={post.image}
                          alt="Post"
                          className="w-full rounded-lg object-cover max-h-96"
                        />
                      )}
                    </div>

                    {/* Post Actions */}
                    <div className="px-4 py-3 border-t border-gray-100 flex items-center justify-between">
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <span>{post.likes} likes</span>
                        <span>{post.comments} comments</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <button className="px-4 py-1.5 rounded-lg hover:bg-gray-100 text-gray-600 font-medium text-sm">
                          Like
                        </button>
                        <button className="px-4 py-1.5 rounded-lg hover:bg-gray-100 text-gray-600 font-medium text-sm">
                          Comment
                        </button>
                        <button className="px-4 py-1.5 rounded-lg hover:bg-gray-100 text-gray-600 font-medium text-sm">
                          Share
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </>
            )}

            {activeTab === 'discover' && (
              <>
                {/* Categories */}
                <div className="bg-white rounded-xl shadow-sm p-4">
                  <h2 className="text-lg font-bold text-gray-900 mb-4">Browse by Category</h2>
                  <div className="flex flex-wrap gap-2">
                    {categories.map((category) => (
                      <button
                        key={category}
                        className="px-4 py-2 bg-gray-100 rounded-full text-sm font-medium text-gray-700 hover:bg-gray-200 transition-colors"
                      >
                        {category}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Suggested Groups */}
                <div className="bg-white rounded-xl shadow-sm p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-bold text-gray-900">Suggested for you</h2>
                    <button className="text-blue-500 hover:underline text-sm">See all</button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {suggestedGroups.map((group) => (
                      <div key={group.id} className="border border-gray-200 rounded-xl overflow-hidden hover:shadow-md transition-shadow">
                        <div className="relative h-32">
                          <img 
                            src={group.cover}
                            alt={group.name}
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                          <div className="absolute bottom-3 left-3 right-3">
                            <h3 className="font-bold text-white truncate">{group.name}</h3>
                          </div>
                        </div>
                        <div className="p-3">
                          <div className="flex items-center gap-2 text-xs text-gray-500 mb-2">
                            {group.privacy === 'private' ? (
                              <Lock className="w-3 h-3" />
                            ) : (
                              <Globe className="w-3 h-3" />
                            )}
                            <span>{group.privacy === 'private' ? 'Private' : 'Public'} group</span>
                            <span>·</span>
                            <span>{(group.members / 1000).toFixed(0)}K members</span>
                          </div>
                          <p className="text-sm text-gray-600 mb-3 line-clamp-2">{group.description}</p>
                          <div className="flex items-center gap-2 text-xs text-gray-500 mb-3">
                            <TrendingUp className="w-3 h-3 text-green-500" />
                            <span>{group.postsPerDay}+ posts a day</span>
                          </div>
                          <button className="w-full py-2 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors">
                            Join Group
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Friends' Groups */}
                <div className="bg-white rounded-xl shadow-sm p-4">
                  <h2 className="text-lg font-bold text-gray-900 mb-4">Friends' Groups</h2>
                  <div className="space-y-3">
                    {groups.slice(0, 3).map((group) => (
                      <div key={group.id} className="flex items-center gap-4 p-3 rounded-lg hover:bg-gray-50 transition-colors">
                        <img 
                          src={group.cover}
                          alt={group.name}
                          className="w-16 h-16 rounded-lg object-cover"
                        />
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900">{group.name}</h3>
                          <p className="text-sm text-gray-500">{(group.members / 1000).toFixed(0)}K members</p>
                          <div className="flex items-center gap-1 mt-1">
                            <div className="flex -space-x-1">
                              {users.slice(0, 3).map((user) => (
                                <img 
                                  key={user.id}
                                  src={user.avatar}
                                  alt=""
                                  className="w-5 h-5 rounded-full border border-white object-cover"
                                />
                              ))}
                            </div>
                            <span className="text-xs text-gray-500">3 friends are members</span>
                          </div>
                        </div>
                        <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-medium hover:bg-gray-200 transition-colors">
                          Join
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}

            {activeTab === 'your-groups' && (
              <div className="bg-white rounded-xl shadow-sm p-4">
                <h2 className="text-lg font-bold text-gray-900 mb-4">Groups you manage</h2>
                <div className="space-y-3">
                  {groups.slice(0, 2).map((group) => (
                    <div key={group.id} className="flex items-center gap-4 p-3 rounded-lg border border-gray-200">
                      <img 
                        src={group.cover}
                        alt={group.name}
                        className="w-20 h-20 rounded-lg object-cover"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900">{group.name}</h3>
                        <p className="text-sm text-gray-500">{group.category} · {(group.members / 1000).toFixed(0)}K members</p>
                        <div className="flex items-center gap-3 mt-2">
                          <button className="text-sm text-blue-500 hover:underline">View group</button>
                          <button className="text-sm text-gray-500 hover:underline">Manage</button>
                        </div>
                      </div>
                      <button className="w-10 h-10 rounded-full hover:bg-gray-100 flex items-center justify-center">
                        <Bell className="w-5 h-5 text-gray-500" />
                      </button>
                    </div>
                  ))}
                </div>

                <h2 className="text-lg font-bold text-gray-900 mt-6 mb-4">Groups you've joined</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {groups.map((group) => (
                    <div key={group.id} className="flex items-center gap-3 p-3 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
                      <img 
                        src={group.cover}
                        alt={group.name}
                        className="w-14 h-14 rounded-lg object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-gray-900 truncate">{group.name}</h3>
                        <p className="text-xs text-gray-500">Last active 2h ago</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default GroupsPage;
