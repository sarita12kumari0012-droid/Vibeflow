import { supabase } from '@/lib/supabase';

export interface PostData {
  id: string;
  user_id: string;
  content: string;
  images: string[];
  video: string | null;
  feeling: string | null;
  location: string | null;
  privacy: 'public' | 'friends' | 'private';
  likes_count: number;
  comments_count: number;
  shares_count: number;
  created_at: string;
  updated_at: string;
  user: {
    user_id: string;
    full_name: string;
    username: string;
    avatar_url: string;
    is_verified: boolean;
  };
  userReaction: string | null;
  isSaved: boolean;
}

export interface CreatePostParams {
  userId: string;
  content: string;
  images?: string[];
  video?: string;
  feeling?: string;
  location?: string;
  privacy?: 'public' | 'friends' | 'private';
}

class PostsService {
  async createPost(params: CreatePostParams): Promise<{ success: boolean; post?: PostData; error?: string }> {
    try {
      const { data, error } = await supabase.functions.invoke('posts-service', {
        body: {
          action: 'create',
          ...params
        }
      });

      if (error) {
        console.error('Create post error:', error);
        return { success: false, error: error.message };
      }

      if (data?.error) {
        return { success: false, error: data.error };
      }

      return { success: true, post: data.post };
    } catch (error: any) {
      console.error('Create post error:', error);
      return { success: false, error: error.message || 'Failed to create post' };
    }
  }

  async getFeed(userId?: string, limit: number = 20, offset: number = 0): Promise<{ success: boolean; posts?: PostData[]; error?: string }> {
    try {
      const { data, error } = await supabase.functions.invoke('posts-service', {
        body: {
          action: 'get_feed',
          userId,
          limit,
          offset
        }
      });

      if (error) {
        console.error('Get feed error:', error);
        return { success: false, error: error.message };
      }

      if (data?.error) {
        return { success: false, error: data.error };
      }

      return { success: true, posts: data.posts || [] };
    } catch (error: any) {
      console.error('Get feed error:', error);
      return { success: false, error: error.message || 'Failed to fetch posts' };
    }
  }

  async reactToPost(userId: string, postId: string, reactionType: string): Promise<{ success: boolean; action?: string; error?: string }> {
    try {
      const { data, error } = await supabase.functions.invoke('posts-service', {
        body: {
          action: 'react',
          userId,
          postId,
          reactionType
        }
      });

      if (error) {
        console.error('React to post error:', error);
        return { success: false, error: error.message };
      }

      if (data?.error) {
        return { success: false, error: data.error };
      }

      return { success: true, action: data.action };
    } catch (error: any) {
      console.error('React to post error:', error);
      return { success: false, error: error.message || 'Failed to react to post' };
    }
  }

  async savePost(userId: string, postId: string): Promise<{ success: boolean; action?: string; error?: string }> {
    try {
      const { data, error } = await supabase.functions.invoke('posts-service', {
        body: {
          action: 'save',
          userId,
          postId
        }
      });

      if (error) {
        console.error('Save post error:', error);
        return { success: false, error: error.message };
      }

      if (data?.error) {
        return { success: false, error: data.error };
      }

      return { success: true, action: data.action };
    } catch (error: any) {
      console.error('Save post error:', error);
      return { success: false, error: error.message || 'Failed to save post' };
    }
  }

  async deletePost(userId: string, postId: string): Promise<{ success: boolean; error?: string }> {
    try {
      const { data, error } = await supabase.functions.invoke('posts-service', {
        body: {
          action: 'delete',
          userId,
          postId
        }
      });

      if (error) {
        console.error('Delete post error:', error);
        return { success: false, error: error.message };
      }

      if (data?.error) {
        return { success: false, error: data.error };
      }

      return { success: true };
    } catch (error: any) {
      console.error('Delete post error:', error);
      return { success: false, error: error.message || 'Failed to delete post' };
    }
  }

  async addComment(postId: string, userId: string, content: string, parentId?: string): Promise<{ success: boolean; comment?: any; error?: string }> {
    try {
      const { data, error } = await supabase
        .from('comments')
        .insert([{
          post_id: postId,
          user_id: userId,
          content,
          parent_id: parentId || null
        }])
        .select()
        .single();

      if (error) {
        console.error('Add comment error:', error);
        return { success: false, error: error.message };
      }

      // Update comments count on post
      await supabase
        .from('posts')
        .update({ comments_count: supabase.rpc('increment') })
        .eq('id', postId);

      return { success: true, comment: data };
    } catch (error: any) {
      console.error('Add comment error:', error);
      return { success: false, error: error.message || 'Failed to add comment' };
    }
  }

  async getComments(postId: string): Promise<{ success: boolean; comments?: any[]; error?: string }> {
    try {
      const { data: comments, error } = await supabase
        .from('comments')
        .select('*')
        .eq('post_id', postId)
        .order('created_at', { ascending: true });

      if (error) {
        console.error('Get comments error:', error);
        return { success: false, error: error.message };
      }

      // Get user profiles for comments
      const userIds = [...new Set(comments.map(c => c.user_id))];
      const { data: profiles } = await supabase
        .from('user_profiles')
        .select('user_id, full_name, username, avatar_url, is_verified')
        .in('user_id', userIds);

      const profileMap = new Map(profiles?.map(p => [p.user_id, p]) || []);

      const commentsWithUsers = comments.map(comment => ({
        ...comment,
        user: profileMap.get(comment.user_id) || { full_name: 'Unknown User', avatar_url: '' }
      }));

      return { success: true, comments: commentsWithUsers };
    } catch (error: any) {
      console.error('Get comments error:', error);
      return { success: false, error: error.message || 'Failed to fetch comments' };
    }
  }
}

export const postsService = new PostsService();
export default postsService;
