import React, { useState } from 'react';
import { users, currentUser } from '../data/socialData';
import { 
  X, Video, VideoOff, Mic, MicOff, Phone, Monitor, 
  MessageCircle, Users, Settings, Maximize, Grid,
  Hand, Smile, Share2, MoreHorizontal
} from 'lucide-react';

interface VirtualHangoutProps {
  isOpen: boolean;
  onClose: () => void;
}

const VirtualHangout: React.FC<VirtualHangoutProps> = ({ isOpen, onClose }) => {
  const [isVideoOn, setIsVideoOn] = useState(true);
  const [isMicOn, setIsMicOn] = useState(true);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [showParticipants, setShowParticipants] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'speaker'>('grid');
  const [chatMessages, setChatMessages] = useState([
    { user: users[1], message: 'Hey everyone! 👋', time: '10:30 AM' },
    { user: users[2], message: 'Great to see you all!', time: '10:31 AM' },
    { user: users[3], message: 'Let\'s get started!', time: '10:32 AM' }
  ]);
  const [newMessage, setNewMessage] = useState('');

  const participants = [currentUser, users[1], users[2], users[3], users[5], users[6]];

  const sendMessage = () => {
    if (newMessage.trim()) {
      setChatMessages([...chatMessages, {
        user: currentUser,
        message: newMessage,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
      setNewMessage('');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-gray-900 z-50 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-gray-800">
        <div className="flex items-center gap-4">
          <h2 className="text-white font-semibold">Virtual Hangout Room</h2>
          <div className="flex items-center gap-2 px-3 py-1 bg-red-500/20 rounded-full">
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
            <span className="text-red-400 text-sm">Live</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setViewMode(viewMode === 'grid' ? 'speaker' : 'grid')}
            className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg transition-colors"
          >
            <Grid className="w-5 h-5" />
          </button>
          <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg transition-colors">
            <Maximize className="w-5 h-5" />
          </button>
          <button className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg transition-colors">
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Video Grid */}
        <div className="flex-1 p-4">
          <div className={`h-full grid gap-3 ${
            viewMode === 'grid' 
              ? 'grid-cols-2 lg:grid-cols-3' 
              : 'grid-cols-1'
          }`}>
            {participants.map((participant, idx) => (
              <div 
                key={participant.id}
                className={`relative bg-gray-800 rounded-xl overflow-hidden ${
                  viewMode === 'speaker' && idx === 0 ? 'col-span-full row-span-2' : ''
                }`}
              >
                {/* Video/Avatar */}
                <div className="absolute inset-0 flex items-center justify-center">
                  {idx === 0 && !isVideoOn ? (
                    <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center">
                      <span className="text-4xl text-white font-bold">
                        {participant.name.charAt(0)}
                      </span>
                    </div>
                  ) : (
                    <img 
                      src={participant.avatar}
                      alt={participant.name}
                      className="w-full h-full object-cover"
                    />
                  )}
                </div>

                {/* Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

                {/* User Info */}
                <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-white text-sm font-medium">
                      {participant.id === currentUser.id ? 'You' : participant.name}
                    </span>
                    {idx === 0 && !isMicOn && (
                      <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center">
                        <MicOff className="w-3 h-3 text-white" />
                      </div>
                    )}
                  </div>
                  {participant.id !== currentUser.id && (
                    <button className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors">
                      <MoreHorizontal className="w-4 h-4 text-white" />
                    </button>
                  )}
                </div>

                {/* Speaking Indicator */}
                {idx === 1 && (
                  <div className="absolute top-3 left-3 flex items-center gap-1">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                    <span className="text-xs text-green-400">Speaking</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Side Panel - Chat/Participants */}
        {(showChat || showParticipants) && (
          <div className="w-80 bg-gray-800 flex flex-col">
            {/* Panel Tabs */}
            <div className="flex border-b border-gray-700">
              <button 
                onClick={() => { setShowChat(true); setShowParticipants(false); }}
                className={`flex-1 py-3 text-sm font-medium transition-colors ${
                  showChat ? 'text-white border-b-2 border-blue-500' : 'text-gray-400 hover:text-white'
                }`}
              >
                Chat
              </button>
              <button 
                onClick={() => { setShowParticipants(true); setShowChat(false); }}
                className={`flex-1 py-3 text-sm font-medium transition-colors ${
                  showParticipants ? 'text-white border-b-2 border-blue-500' : 'text-gray-400 hover:text-white'
                }`}
              >
                Participants ({participants.length})
              </button>
            </div>

            {/* Chat Content */}
            {showChat && (
              <>
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {chatMessages.map((msg, idx) => (
                    <div key={idx} className="flex gap-3">
                      <img 
                        src={msg.user.avatar}
                        alt={msg.user.name}
                        className="w-8 h-8 rounded-full object-cover"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-white text-sm font-medium">{msg.user.name}</span>
                          <span className="text-gray-500 text-xs">{msg.time}</span>
                        </div>
                        <p className="text-gray-300 text-sm">{msg.message}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="p-4 border-t border-gray-700">
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                      placeholder="Type a message..."
                      className="flex-1 px-4 py-2 bg-gray-700 rounded-full text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <button 
                      onClick={sendMessage}
                      className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors"
                    >
                      <Share2 className="w-5 h-5 text-white" />
                    </button>
                  </div>
                </div>
              </>
            )}

            {/* Participants Content */}
            {showParticipants && (
              <div className="flex-1 overflow-y-auto p-4 space-y-2">
                {participants.map((participant) => (
                  <div key={participant.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-700 transition-colors">
                    <div className="relative">
                      <img 
                        src={participant.avatar}
                        alt={participant.name}
                        className="w-10 h-10 rounded-full object-cover"
                      />
                      <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-gray-800" />
                    </div>
                    <div className="flex-1">
                      <p className="text-white text-sm font-medium">
                        {participant.id === currentUser.id ? 'You' : participant.name}
                      </p>
                      <p className="text-gray-500 text-xs">
                        {participant.id === currentUser.id ? 'Host' : 'Participant'}
                      </p>
                    </div>
                    {participant.id !== currentUser.id && (
                      <button className="text-gray-400 hover:text-white">
                        <MoreHorizontal className="w-5 h-5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="px-4 py-4 bg-gray-800 flex items-center justify-center gap-4">
        <button 
          onClick={() => setIsMicOn(!isMicOn)}
          className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
            isMicOn ? 'bg-gray-700 text-white hover:bg-gray-600' : 'bg-red-500 text-white'
          }`}
        >
          {isMicOn ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
        </button>
        <button 
          onClick={() => setIsVideoOn(!isVideoOn)}
          className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
            isVideoOn ? 'bg-gray-700 text-white hover:bg-gray-600' : 'bg-red-500 text-white'
          }`}
        >
          {isVideoOn ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
        </button>
        <button 
          onClick={() => setIsScreenSharing(!isScreenSharing)}
          className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
            isScreenSharing ? 'bg-green-500 text-white' : 'bg-gray-700 text-white hover:bg-gray-600'
          }`}
        >
          <Monitor className="w-5 h-5" />
        </button>
        <button className="w-12 h-12 bg-gray-700 rounded-full flex items-center justify-center text-white hover:bg-gray-600 transition-colors">
          <Hand className="w-5 h-5" />
        </button>
        <button className="w-12 h-12 bg-gray-700 rounded-full flex items-center justify-center text-white hover:bg-gray-600 transition-colors">
          <Smile className="w-5 h-5" />
        </button>
        <div className="w-px h-8 bg-gray-600 mx-2" />
        <button 
          onClick={() => { setShowChat(!showChat); setShowParticipants(false); }}
          className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
            showChat ? 'bg-blue-500 text-white' : 'bg-gray-700 text-white hover:bg-gray-600'
          }`}
        >
          <MessageCircle className="w-5 h-5" />
        </button>
        <button 
          onClick={() => { setShowParticipants(!showParticipants); setShowChat(false); }}
          className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
            showParticipants ? 'bg-blue-500 text-white' : 'bg-gray-700 text-white hover:bg-gray-600'
          }`}
        >
          <Users className="w-5 h-5" />
        </button>
        <div className="w-px h-8 bg-gray-600 mx-2" />
        <button 
          onClick={onClose}
          className="px-6 py-3 bg-red-500 text-white rounded-full font-medium hover:bg-red-600 transition-colors flex items-center gap-2"
        >
          <Phone className="w-5 h-5" />
          Leave
        </button>
      </div>
    </div>
  );
};

export default VirtualHangout;
