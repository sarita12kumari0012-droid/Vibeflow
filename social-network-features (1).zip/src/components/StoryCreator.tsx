import React, { useState, useRef } from 'react';
import { currentUser } from '../data/socialData';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { 
  X, Image, Type, Smile, Music, Palette, Sparkles,
  AlignLeft, AlignCenter, AlignRight, Bold, Italic,
  ChevronLeft, ChevronRight, Send, Loader2, Video,
  Camera, Sticker, Wand2
} from 'lucide-react';

interface StoryCreatorProps {
  isOpen: boolean;
  onClose: () => void;
  onPost: (story: { media: string; text?: string }) => void;
}

const StoryCreator: React.FC<StoryCreatorProps> = ({ isOpen, onClose, onPost }) => {
  const { isAuthenticated, profile } = useAuth();
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [mediaType, setMediaType] = useState<'image' | 'video'>('image');
  const [text, setText] = useState('');
  const [showTextEditor, setShowTextEditor] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [textStyle, setTextStyle] = useState({
    color: '#ffffff',
    align: 'center' as 'left' | 'center' | 'right',
    bold: false,
    italic: false
  });
  const [backgroundColor, setBackgroundColor] = useState('#1877F2');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const backgroundColors = [
    '#1877F2', '#E91E63', '#9C27B0', '#673AB7', '#3F51B5',
    '#00BCD4', '#009688', '#4CAF50', '#FF9800', '#FF5722',
    '#795548', '#607D8B', '#000000', '#FFFFFF'
  ];

  const gradientBackgrounds = [
    'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
    'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
    'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
    'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
    'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)',
    'linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)',
    'linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%)'
  ];

  const textColors = [
    '#ffffff', '#000000', '#FF0000', '#00FF00', '#0000FF',
    '#FFFF00', '#FF00FF', '#00FFFF', '#FFA500', '#800080'
  ];

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Check if it's a video
      if (file.type.startsWith('video/')) {
        setMediaType('video');
      } else {
        setMediaType('image');
      }
      
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setSelectedImage(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePost = async () => {
    if (!isAuthenticated) {
      alert('Please login to create stories');
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Not authenticated');

      let mediaUrl = '';
      
      // If there's a file, upload it
      if (selectedFile) {
        setUploadProgress(30);
        const fileName = `${Date.now()}_${selectedFile.name}`;
        const { data, error: uploadError } = await supabase.storage
          .from('media')
          .upload(`stories/${session.user.id}/${fileName}`, selectedFile, {
            cacheControl: '3600',
            upsert: false
          });

        if (uploadError) throw uploadError;
        setUploadProgress(60);

        const { data: { publicUrl } } = supabase.storage
          .from('media')
          .getPublicUrl(`stories/${session.user.id}/${fileName}`);
        
        mediaUrl = publicUrl;
      } else if (!selectedImage && text) {
        // Text-only story - create a placeholder
        mediaUrl = 'text-story';
      }

      setUploadProgress(80);

      // Save to database
      const { data, error } = await supabase.functions.invoke('media-service', {
        body: {
          action: 'create_story',
          media_url: mediaUrl,
          media_type: selectedFile ? mediaType : 'text',
          caption: text,
          background_color: !selectedImage ? backgroundColor : null,
          text_style: textStyle
        }
      });

      if (error) throw error;
      setUploadProgress(100);

      // Call the onPost callback
      onPost({
        media: mediaUrl || selectedImage || '',
        text: text
      });

      // Reset and close
      resetForm();
      alert('Story posted successfully!');

    } catch (error: any) {
      console.error('Story upload error:', error);
      alert('Failed to post story: ' + error.message);
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const resetForm = () => {
    setSelectedImage(null);
    setSelectedFile(null);
    setText('');
    setShowTextEditor(false);
    setBackgroundColor('#1877F2');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-gray-900 z-50 flex">
      {/* Left Panel - Tools */}
      <div className="w-80 bg-white p-4 flex flex-col overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <button 
            onClick={resetForm}
            className="w-10 h-10 rounded-full hover:bg-gray-100 flex items-center justify-center"
          >
            <X className="w-6 h-6 text-gray-600" />
          </button>
          <h2 className="text-xl font-bold text-gray-900">Create Story</h2>
          <div className="w-10" />
        </div>

        {/* User Info */}
        <div className="flex items-center gap-3 mb-6">
          <img 
            src={profile?.avatar_url || currentUser.avatar}
            alt={profile?.full_name || currentUser.name}
            className="w-12 h-12 rounded-full object-cover ring-2 ring-purple-500"
          />
          <div>
            <p className="font-semibold text-gray-900">{profile?.full_name || currentUser.name}</p>
            <p className="text-sm text-gray-500">Sharing to story</p>
          </div>
        </div>

        {/* Upload Options */}
        <div className="space-y-3 mb-6">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*,video/*"
            onChange={handleImageUpload}
            className="hidden"
          />
          
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="w-full flex items-center gap-3 p-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl hover:opacity-90 transition-opacity group"
          >
            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
              <Image className="w-6 h-6" />
            </div>
            <div className="text-left">
              <p className="font-semibold">Create a Photo Story</p>
              <p className="text-sm opacity-80">Share a photo from your gallery</p>
            </div>
          </button>

          <button 
            onClick={() => fileInputRef.current?.click()}
            className="w-full flex items-center gap-3 p-4 bg-gradient-to-r from-red-500 to-orange-500 text-white rounded-xl hover:opacity-90 transition-opacity group"
          >
            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
              <Video className="w-6 h-6" />
            </div>
            <div className="text-left">
              <p className="font-semibold">Create a Video Story</p>
              <p className="text-sm opacity-80">Share a video moment</p>
            </div>
          </button>

          <button 
            onClick={() => {
              setSelectedImage(null);
              setSelectedFile(null);
              setShowTextEditor(true);
            }}
            className="w-full flex items-center gap-3 p-4 bg-gradient-to-r from-blue-500 to-cyan-500 text-white rounded-xl hover:opacity-90 transition-opacity group"
          >
            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
              <Type className="w-6 h-6" />
            </div>
            <div className="text-left">
              <p className="font-semibold">Create a Text Story</p>
              <p className="text-sm opacity-80">Share what's on your mind</p>
            </div>
          </button>
        </div>

        {/* Text Editor Tools */}
        {(showTextEditor || selectedImage) && (
          <div className="border-t border-gray-200 pt-4 space-y-4">
            <h3 className="font-semibold text-gray-900">Add to your story</h3>
            
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setShowTextEditor(!showTextEditor)}
                className={`flex-1 flex items-center justify-center gap-2 p-2 rounded-lg transition-colors ${
                  showTextEditor ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <Type className="w-5 h-5" />
                <span className="text-sm font-medium">Text</span>
              </button>
              <button className="flex-1 flex items-center justify-center gap-2 p-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 transition-colors">
                <Sticker className="w-5 h-5" />
                <span className="text-sm font-medium">Stickers</span>
              </button>
              <button className="flex-1 flex items-center justify-center gap-2 p-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 transition-colors">
                <Music className="w-5 h-5" />
                <span className="text-sm font-medium">Music</span>
              </button>
            </div>

            {/* Background Colors */}
            {!selectedImage && (
              <div>
                <p className="text-sm text-gray-500 mb-2">Background</p>
                <div className="flex flex-wrap gap-2 mb-3">
                  {backgroundColors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setBackgroundColor(color)}
                      className={`w-8 h-8 rounded-full border-2 transition-transform hover:scale-110 ${
                        backgroundColor === color ? 'border-blue-500 scale-110 ring-2 ring-blue-200' : 'border-gray-200'
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
                <p className="text-sm text-gray-500 mb-2">Gradients</p>
                <div className="flex flex-wrap gap-2">
                  {gradientBackgrounds.map((gradient, idx) => (
                    <button
                      key={idx}
                      onClick={() => setBackgroundColor(gradient)}
                      className={`w-8 h-8 rounded-full border-2 transition-transform hover:scale-110 ${
                        backgroundColor === gradient ? 'border-blue-500 scale-110 ring-2 ring-blue-200' : 'border-gray-200'
                      }`}
                      style={{ background: gradient }}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Text Styling */}
            {showTextEditor && (
              <div className="space-y-3">
                <p className="text-sm text-gray-500">Text color</p>
                <div className="flex flex-wrap gap-2">
                  {textColors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setTextStyle({ ...textStyle, color })}
                      className={`w-8 h-8 rounded-full border-2 transition-transform hover:scale-110 ${
                        textStyle.color === color ? 'border-blue-500 scale-110 ring-2 ring-blue-200' : 'border-gray-200'
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => setTextStyle({ ...textStyle, align: 'left' })}
                    className={`p-2 rounded-lg transition-colors ${textStyle.align === 'left' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 hover:bg-gray-200'}`}
                  >
                    <AlignLeft className="w-5 h-5" />
                  </button>
                  <button 
                    onClick={() => setTextStyle({ ...textStyle, align: 'center' })}
                    className={`p-2 rounded-lg transition-colors ${textStyle.align === 'center' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 hover:bg-gray-200'}`}
                  >
                    <AlignCenter className="w-5 h-5" />
                  </button>
                  <button 
                    onClick={() => setTextStyle({ ...textStyle, align: 'right' })}
                    className={`p-2 rounded-lg transition-colors ${textStyle.align === 'right' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 hover:bg-gray-200'}`}
                  >
                    <AlignRight className="w-5 h-5" />
                  </button>
                  <div className="w-px h-6 bg-gray-200 mx-2" />
                  <button 
                    onClick={() => setTextStyle({ ...textStyle, bold: !textStyle.bold })}
                    className={`p-2 rounded-lg transition-colors ${textStyle.bold ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 hover:bg-gray-200'}`}
                  >
                    <Bold className="w-5 h-5" />
                  </button>
                  <button 
                    onClick={() => setTextStyle({ ...textStyle, italic: !textStyle.italic })}
                    className={`p-2 rounded-lg transition-colors ${textStyle.italic ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 hover:bg-gray-200'}`}
                  >
                    <Italic className="w-5 h-5" />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Upload Progress */}
        {isUploading && (
          <div className="mt-4 p-4 bg-purple-50 rounded-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-purple-700">Uploading story...</span>
              <span className="text-sm font-bold text-purple-700">{uploadProgress}%</span>
            </div>
            <div className="h-2 bg-purple-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-300"
                style={{ width: `${uploadProgress}%` }}
              />
            </div>
          </div>
        )}

        {/* Post Button */}
        <div className="mt-auto pt-4">
          <button 
            onClick={handlePost}
            disabled={(!selectedImage && !text) || isUploading}
            className={`w-full py-3 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all ${
              (selectedImage || text) && !isUploading
                ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:opacity-90 hover:shadow-lg'
                : 'bg-gray-200 text-gray-400 cursor-not-allowed'
            }`}
          >
            {isUploading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Posting...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                Share to Story
              </>
            )}
          </button>
        </div>
      </div>

      {/* Right Panel - Preview */}
      <div className="flex-1 flex items-center justify-center p-8 bg-gradient-to-br from-gray-800 to-gray-900">
        <div 
          className="relative w-[320px] h-[568px] rounded-3xl overflow-hidden shadow-2xl ring-4 ring-white/10"
          style={{ 
            backgroundColor: selectedImage ? '#000' : undefined,
            background: selectedImage ? undefined : backgroundColor
          }}
        >
          {selectedImage ? (
            mediaType === 'video' ? (
              <video 
                src={selectedImage}
                className="w-full h-full object-cover"
                autoPlay
                loop
                muted
              />
            ) : (
              <img 
                src={selectedImage}
                alt="Story preview"
                className="w-full h-full object-cover"
              />
            )
          ) : (
            <div className="w-full h-full flex items-center justify-center p-6">
              {showTextEditor ? (
                <textarea
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder="Start typing..."
                  className={`w-full bg-transparent resize-none focus:outline-none text-2xl placeholder-white/50 ${
                    textStyle.bold ? 'font-bold' : ''
                  } ${textStyle.italic ? 'italic' : ''}`}
                  style={{ 
                    color: textStyle.color,
                    textAlign: textStyle.align
                  }}
                  rows={8}
                />
              ) : (
                <div className="text-center text-white/50">
                  <Sparkles className="w-16 h-16 mx-auto mb-4 animate-pulse" />
                  <p className="text-lg">Select an option to create your story</p>
                </div>
              )}
            </div>
          )}

          {/* Text Overlay on Image */}
          {selectedImage && showTextEditor && (
            <div 
              className="absolute inset-x-4 bottom-20 p-4 bg-black/30 backdrop-blur-sm rounded-xl"
              style={{ textAlign: textStyle.align }}
            >
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Add text..."
                className={`w-full bg-transparent resize-none focus:outline-none text-lg placeholder-white/50 ${
                  textStyle.bold ? 'font-bold' : ''
                } ${textStyle.italic ? 'italic' : ''}`}
                style={{ color: textStyle.color }}
                rows={3}
              />
            </div>
          )}

          {/* User Avatar */}
          <div className="absolute top-4 left-4 flex items-center gap-2">
            <img 
              src={profile?.avatar_url || currentUser.avatar}
              alt={profile?.full_name || currentUser.name}
              className="w-10 h-10 rounded-full object-cover ring-2 ring-white shadow-lg"
            />
            <span className="text-white text-sm font-medium drop-shadow-lg">Your Story</span>
          </div>

          {/* Story indicators */}
          <div className="absolute top-2 left-2 right-2 h-1 bg-white/30 rounded-full overflow-hidden">
            <div className="h-full w-full bg-white rounded-full" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default StoryCreator;
