import React, { useState, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { currentUser } from '../data/socialData';
import { supabase } from '@/lib/supabase';
import { 
  Image, Video, Smile, MapPin, Users, Calendar, 
  X, Globe, ChevronDown, Hash, Sparkles, Mic, Bot, Loader2, Wand2
} from 'lucide-react';

interface CreatePostProps {
  onPost: (content: string, images: string[], privacy: string) => void;
  isModal?: boolean;
  onClose?: () => void;
  initialContent?: string;
}

const CreatePost: React.FC<CreatePostProps> = ({ onPost, isModal = false, onClose, initialContent = '' }) => {
  const { isAuthenticated, profile } = useAuth();
  const [content, setContent] = useState(initialContent);
  const [images, setImages] = useState<string[]>([]);
  const [privacy, setPrivacy] = useState('public');
  const [showPrivacyMenu, setShowPrivacyMenu] = useState(false);
  const [feeling, setFeeling] = useState('');
  const [showFeelings, setShowFeelings] = useState(false);
  const [isExpanded, setIsExpanded] = useState(isModal);
  const [showAIMenu, setShowAIMenu] = useState(false);
  const [isAILoading, setIsAILoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Get display user
  const displayUser = isAuthenticated && profile ? {
    name: profile.full_name || 'User',
    avatar: profile.avatar_url || currentUser.avatar
  } : currentUser;

  const feelings = [
    { emoji: '😊', label: 'happy' },
    { emoji: '😢', label: 'sad' },
    { emoji: '😍', label: 'loved' },
    { emoji: '🎉', label: 'excited' },
    { emoji: '😴', label: 'tired' },
    { emoji: '🤔', label: 'thoughtful' },
    { emoji: '😎', label: 'cool' },
    { emoji: '🥳', label: 'celebrating' }
  ];

  const aiActions = [
    { id: 'generate_post', label: 'Generate Post', desc: 'Create a new post from topic', icon: Sparkles },
    { id: 'improve_post', label: 'Improve Post', desc: 'Enhance your current text', icon: Wand2 },
    { id: 'generate_hashtags', label: 'Add Hashtags', desc: 'Get relevant hashtags', icon: Hash },
  ];

  const handleSubmit = () => {
    if (content.trim() || images.length > 0) {
      onPost(content, images, privacy);
      setContent('');
      setImages([]);
      setIsExpanded(false);
      if (onClose) onClose();
    }
  };

  const handleAIAction = async (action: string) => {
    if (!content.trim() && action !== 'generate_post') {
      setAiError('Please enter some text first');
      return;
    }

    setIsAILoading(true);
    setAiError(null);
    setShowAIMenu(false);

    try {
      const { data, error } = await supabase.functions.invoke('ai-assistant', {
        body: { 
          action, 
          prompt: content || 'something interesting and engaging',
          style: 'casual'
        }
      });

      if (error) throw error;

      if (data.success && data.content) {
        if (action === 'generate_hashtags') {
          setContent(prev => prev + '\n\n' + data.content);
        } else {
          setContent(data.content);
        }
      } else {
        throw new Error(data.error || 'Failed to generate content');
      }
    } catch (err: any) {
      console.error('AI error:', err);
      setAiError(err.message || 'Failed to generate content');
    } finally {
      setIsAILoading(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const newImages = Array.from(files).map(() => 
        `https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298743451_fdf3e0a7.png`
      );
      setImages([...images, ...newImages]);
    }
  };

  const removeImage = (index: number) => {
    setImages(images.filter((_, i) => i !== index));
  };

  const privacyOptions = [
    { value: 'public', label: 'Public', icon: Globe, desc: 'Anyone can see this post' },
    { value: 'friends', label: 'Friends', icon: Users, desc: 'Only friends can see' },
    { value: 'private', label: 'Only me', icon: () => <span>🔒</span>, desc: 'Only you can see' }
  ];

  const PostContent = () => (
    <div className={`bg-white rounded-xl shadow-sm ${isModal ? '' : 'p-4'}`}>
      {/* Header */}
      {isModal && (
        <div className="flex items-center justify-between p-4 border-b border-gray-100">
          <div className="w-10" />
          <h2 className="text-xl font-bold text-gray-900">Create Post</h2>
          <button 
            onClick={onClose}
            className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>
      )}

      {/* User Info */}
      <div className={`flex items-center gap-3 ${isModal ? 'p-4' : 'mb-3'}`}>
        <img 
          src={displayUser.avatar}
          alt={displayUser.name}
          className="w-11 h-11 rounded-full object-cover"
        />
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-gray-900">{displayUser.name}</h3>
            {feeling && (
              <span className="text-gray-500 text-sm">is feeling {feeling}</span>
            )}
          </div>
          <div className="relative">
            <button 
              onClick={() => setShowPrivacyMenu(!showPrivacyMenu)}
              className="flex items-center gap-1 px-2 py-0.5 bg-gray-100 rounded-md text-xs text-gray-600 hover:bg-gray-200 transition-colors"
            >
              {React.createElement(
                privacyOptions.find(p => p.value === privacy)?.icon || Globe,
                { className: 'w-3 h-3' }
              )}
              <span>{privacyOptions.find(p => p.value === privacy)?.label}</span>
              <ChevronDown className="w-3 h-3" />
            </button>
            {showPrivacyMenu && (
              <div className="absolute top-full left-0 mt-1 w-64 bg-white rounded-lg shadow-xl border border-gray-100 py-1 z-20">
                <p className="px-3 py-2 text-sm font-semibold text-gray-900">Who can see your post?</p>
                {privacyOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => {
                      setPrivacy(option.value);
                      setShowPrivacyMenu(false);
                    }}
                    className={`w-full px-3 py-2 flex items-center gap-3 hover:bg-gray-50 ${
                      privacy === option.value ? 'bg-blue-50' : ''
                    }`}
                  >
                    <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                      {typeof option.icon === 'function' ? (
                        <option.icon className="w-4 h-4 text-gray-600" />
                      ) : (
                        option.icon
                      )}
                    </div>
                    <div className="text-left">
                      <p className="font-medium text-gray-900">{option.label}</p>
                      <p className="text-xs text-gray-500">{option.desc}</p>
                    </div>
                    {privacy === option.value && (
                      <div className="ml-auto w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center">
                        <svg className="w-3 h-3 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                          <path d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Text Input */}
      <div className={isModal ? 'px-4' : ''}>
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          onFocus={() => !isModal && setIsExpanded(true)}
          placeholder={`What's on your mind, ${displayUser.name.split(' ')[0]}?`}
          className={`w-full resize-none focus:outline-none text-gray-900 placeholder-gray-500 ${
            isExpanded || isModal ? 'min-h-[120px] text-lg' : 'min-h-[40px]'
          }`}
          disabled={isAILoading}
        />
        {isAILoading && (
          <div className="flex items-center gap-2 text-violet-600 mt-2">
            <Loader2 className="w-4 h-4 animate-spin" />
            <span className="text-sm">AI is writing...</span>
          </div>
        )}
        {aiError && (
          <p className="text-sm text-red-500 mt-2">{aiError}</p>
        )}
      </div>

      {/* Image Preview */}
      {images.length > 0 && (
        <div className={`${isModal ? 'px-4' : ''} mt-3`}>
          <div className="relative border border-gray-200 rounded-lg p-2">
            <div className={`grid gap-2 ${images.length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
              {images.map((img, idx) => (
                <div key={idx} className="relative aspect-video">
                  <img 
                    src={img}
                    alt={`Upload ${idx + 1}`}
                    className="w-full h-full object-cover rounded-lg"
                  />
                  <button 
                    onClick={() => removeImage(idx)}
                    className="absolute top-2 right-2 w-7 h-7 bg-gray-800/70 rounded-full flex items-center justify-center hover:bg-gray-800 transition-colors"
                  >
                    <X className="w-4 h-4 text-white" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Feelings */}
      {showFeelings && (
        <div className={`${isModal ? 'px-4' : ''} mt-3`}>
          <div className="bg-gray-50 rounded-lg p-3">
            <p className="text-sm font-medium text-gray-700 mb-2">How are you feeling?</p>
            <div className="flex flex-wrap gap-2">
              {feelings.map((f) => (
                <button
                  key={f.label}
                  onClick={() => {
                    setFeeling(f.label);
                    setShowFeelings(false);
                  }}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-sm transition-colors ${
                    feeling === f.label 
                      ? 'bg-blue-100 text-blue-600' 
                      : 'bg-white hover:bg-gray-100 text-gray-700'
                  }`}
                >
                  <span>{f.emoji}</span>
                  <span>{f.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* AI Menu */}
      {showAIMenu && (
        <div className={`${isModal ? 'px-4' : ''} mt-3`}>
          <div className="bg-gradient-to-r from-violet-50 to-purple-50 rounded-lg p-3 border border-violet-100">
            <div className="flex items-center gap-2 mb-3">
              <Bot className="w-5 h-5 text-violet-600" />
              <p className="text-sm font-medium text-violet-900">AI Writing Assistant</p>
            </div>
            <div className="space-y-2">
              {aiActions.map((action) => (
                <button
                  key={action.id}
                  onClick={() => handleAIAction(action.id)}
                  disabled={isAILoading}
                  className="w-full flex items-center gap-3 p-2 bg-white rounded-lg hover:bg-violet-50 transition-colors disabled:opacity-50"
                >
                  <action.icon className="w-5 h-5 text-violet-600" />
                  <div className="text-left">
                    <p className="font-medium text-gray-900 text-sm">{action.label}</p>
                    <p className="text-xs text-gray-500">{action.desc}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className={`${isModal ? 'p-4' : 'mt-3'}`}>
        <div className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
          <span className="text-sm font-medium text-gray-700">Add to your post</span>
          <div className="flex items-center gap-1">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={handleImageUpload}
              className="hidden"
            />
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="w-9 h-9 rounded-full hover:bg-gray-100 flex items-center justify-center transition-colors"
              title="Photo/Video"
            >
              <Image className="w-6 h-6 text-green-500" />
            </button>
            <button 
              className="w-9 h-9 rounded-full hover:bg-gray-100 flex items-center justify-center transition-colors"
              title="Tag People"
            >
              <Users className="w-6 h-6 text-blue-500" />
            </button>
            <button 
              onClick={() => setShowFeelings(!showFeelings)}
              className="w-9 h-9 rounded-full hover:bg-gray-100 flex items-center justify-center transition-colors"
              title="Feeling/Activity"
            >
              <Smile className="w-6 h-6 text-yellow-500" />
            </button>
            <button 
              className="w-9 h-9 rounded-full hover:bg-gray-100 flex items-center justify-center transition-colors"
              title="Check In"
            >
              <MapPin className="w-6 h-6 text-red-500" />
            </button>
            <button 
              onClick={() => setShowAIMenu(!showAIMenu)}
              className={`w-9 h-9 rounded-full flex items-center justify-center transition-colors ${
                showAIMenu ? 'bg-violet-100' : 'hover:bg-gray-100'
              }`}
              title="AI Assistant"
            >
              <Bot className="w-6 h-6 text-violet-500" />
            </button>
          </div>
        </div>

        {/* Post Button */}
        <button
          onClick={handleSubmit}
          disabled={(!content.trim() && images.length === 0) || isAILoading}
          className={`w-full mt-3 py-2.5 rounded-lg font-semibold transition-all ${
            (content.trim() || images.length > 0) && !isAILoading
              ? 'bg-blue-500 text-white hover:bg-blue-600'
              : 'bg-gray-200 text-gray-400 cursor-not-allowed'
          }`}
        >
          {isAILoading ? 'Generating...' : 'Post'}
        </button>
      </div>
    </div>
  );

  if (isModal) {
    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div className="w-full max-w-lg bg-white rounded-xl shadow-2xl animate-fadeIn">
          <PostContent />
        </div>
      </div>
    );
  }

  return <PostContent />;
};

export default CreatePost;
