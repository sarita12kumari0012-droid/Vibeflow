import React, { useState } from 'react';
import { users } from '../data/socialData';
import { 
  Search, Home, PlayCircle, Bookmark, Clock, Settings,
  ThumbsUp, MessageCircle, Share2, MoreHorizontal, Volume2, VolumeX,
  Maximize, Play, Pause, ChevronRight
} from 'lucide-react';

interface WatchPageProps {
  onBack: () => void;
}

const WatchPage: React.FC<WatchPageProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [playingVideo, setPlayingVideo] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState(true);

  const tabs = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'live', label: 'Live', icon: PlayCircle },
    { id: 'reels', label: 'Reels', icon: PlayCircle },
    { id: 'saved', label: 'Saved Videos', icon: Bookmark },
    { id: 'watch-later', label: 'Watch Later', icon: Clock }
  ];

  const videos = [
    {
      id: 'v1',
      title: 'Amazing Sunset Timelapse in 4K',
      thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298743451_fdf3e0a7.png',
      creator: users[2],
      views: '1.2M views',
      duration: '5:32',
      likes: 45000,
      comments: 1200,
      timestamp: '2 days ago'
    },
    {
      id: 'v2',
      title: 'Morning Workout Routine for Beginners',
      thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298672761_8e473f6e.jpg',
      creator: users[3],
      views: '890K views',
      duration: '12:45',
      likes: 32000,
      comments: 890,
      timestamp: '1 week ago'
    },
    {
      id: 'v3',
      title: 'How to Build a Startup in 2025',
      thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298773815_6b3b8d77.png',
      creator: users[7],
      views: '2.5M views',
      duration: '18:20',
      likes: 89000,
      comments: 3400,
      timestamp: '3 days ago'
    },
    {
      id: 'v4',
      title: 'Epic Mountain Hiking Adventure',
      thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298748674_67ccb172.png',
      creator: users[11],
      views: '567K views',
      duration: '8:15',
      likes: 23000,
      comments: 567,
      timestamp: '5 days ago'
    },
    {
      id: 'v5',
      title: 'Delicious Homemade Pasta Recipe',
      thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298687191_91fbdc32.png',
      creator: users[4],
      views: '1.8M views',
      duration: '10:30',
      likes: 67000,
      comments: 2100,
      timestamp: '1 day ago'
    },
    {
      id: 'v6',
      title: 'Behind the Scenes: Music Production',
      thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681505_56062067.png',
      creator: users[5],
      views: '3.2M views',
      duration: '15:45',
      likes: 120000,
      comments: 4500,
      timestamp: '4 days ago'
    }
  ];

  const reels = [
    {
      id: 'r1',
      thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298743519_6c3f2456.jpg',
      creator: users[6],
      views: '5.2M',
      likes: 234000
    },
    {
      id: 'r2',
      thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298750501_53b91201.png',
      creator: users[8],
      views: '2.8M',
      likes: 156000
    },
    {
      id: 'r3',
      thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681347_8aa2cbbc.png',
      creator: users[9],
      views: '1.5M',
      likes: 89000
    },
    {
      id: 'r4',
      thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298672761_8e473f6e.jpg',
      creator: users[1],
      views: '4.1M',
      likes: 198000
    }
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm p-4 sticky top-20">
              <div className="flex items-center justify-between mb-4">
                <h1 className="text-2xl font-bold text-gray-900">Watch</h1>
                <button className="w-9 h-9 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors">
                  <Settings className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              {/* Search */}
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search videos"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-gray-100 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Navigation */}
              <nav className="space-y-1">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                      activeTab === tab.id 
                        ? 'bg-blue-50 text-blue-600' 
                        : 'hover:bg-gray-100 text-gray-700'
                    }`}
                  >
                    <div className={`w-9 h-9 rounded-full flex items-center justify-center ${
                      activeTab === tab.id ? 'bg-blue-100' : 'bg-gray-100'
                    }`}>
                      <tab.icon className="w-5 h-5" />
                    </div>
                    <span className="font-medium">{tab.label}</span>
                  </button>
                ))}
              </nav>

              {/* Followed Creators */}
              <div className="mt-6 pt-4 border-t border-gray-200">
                <h3 className="font-semibold text-gray-500 text-sm mb-3">Creators you follow</h3>
                <div className="space-y-2">
                  {users.slice(0, 5).map((user) => (
                    <button
                      key={user.id}
                      className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100 transition-colors"
                    >
                      <div className="relative">
                        <img 
                          src={user.avatar}
                          alt={user.name}
                          className="w-9 h-9 rounded-full object-cover"
                        />
                        {user.isOnline && (
                          <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-white" />
                        )}
                      </div>
                      <span className="font-medium text-gray-700 text-sm truncate">{user.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Reels Section */}
            <div className="bg-white rounded-xl shadow-sm p-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold text-gray-900">Reels and short videos</h2>
                <button className="flex items-center gap-1 text-blue-500 hover:underline text-sm">
                  See all
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {reels.map((reel) => (
                  <div 
                    key={reel.id}
                    className="relative aspect-[9/16] rounded-xl overflow-hidden group cursor-pointer"
                  >
                    <img 
                      src={reel.thumbnail}
                      alt=""
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="w-14 h-14 bg-white/30 backdrop-blur-sm rounded-full flex items-center justify-center">
                        <Play className="w-8 h-8 text-white fill-white" />
                      </div>
                    </div>
                    <div className="absolute bottom-3 left-3 right-3">
                      <div className="flex items-center gap-2 mb-2">
                        <img 
                          src={reel.creator.avatar}
                          alt={reel.creator.name}
                          className="w-6 h-6 rounded-full object-cover"
                        />
                        <span className="text-white text-xs font-medium truncate">{reel.creator.name}</span>
                      </div>
                      <div className="flex items-center gap-2 text-white text-xs">
                        <span>{reel.views} views</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Videos Feed */}
            <div className="space-y-4">
              {videos.map((video) => (
                <div key={video.id} className="bg-white rounded-xl shadow-sm overflow-hidden">
                  {/* Video Player */}
                  <div 
                    className="relative aspect-video bg-gray-900 cursor-pointer group"
                    onClick={() => setPlayingVideo(playingVideo === video.id ? null : video.id)}
                  >
                    <img 
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-full h-full object-cover"
                    />
                    {playingVideo !== video.id && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-16 h-16 bg-black/50 rounded-full flex items-center justify-center group-hover:bg-black/70 transition-colors">
                          <Play className="w-8 h-8 text-white fill-white ml-1" />
                        </div>
                      </div>
                    )}
                    <div className="absolute bottom-3 right-3 px-2 py-1 bg-black/80 rounded text-white text-xs font-medium">
                      {video.duration}
                    </div>
                    {playingVideo === video.id && (
                      <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/80 to-transparent">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <button onClick={(e) => { e.stopPropagation(); setPlayingVideo(null); }}>
                              <Pause className="w-6 h-6 text-white" />
                            </button>
                            <div className="flex-1 h-1 bg-white/30 rounded-full w-48">
                              <div className="h-full w-1/3 bg-blue-500 rounded-full" />
                            </div>
                            <span className="text-white text-xs">1:45 / {video.duration}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <button onClick={(e) => { e.stopPropagation(); setIsMuted(!isMuted); }}>
                              {isMuted ? (
                                <VolumeX className="w-5 h-5 text-white" />
                              ) : (
                                <Volume2 className="w-5 h-5 text-white" />
                              )}
                            </button>
                            <button>
                              <Maximize className="w-5 h-5 text-white" />
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Video Info */}
                  <div className="p-4">
                    <div className="flex gap-3">
                      <img 
                        src={video.creator.avatar}
                        alt={video.creator.name}
                        className="w-10 h-10 rounded-full object-cover"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900 line-clamp-2">{video.title}</h3>
                        <div className="flex items-center gap-2 text-sm text-gray-500 mt-1">
                          <span className="font-medium text-gray-700 hover:underline cursor-pointer">
                            {video.creator.name}
                          </span>
                          {video.creator.isVerified && (
                            <svg className="w-4 h-4 text-blue-500" viewBox="0 0 24 24" fill="currentColor">
                              <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/>
                            </svg>
                          )}
                          <span>·</span>
                          <span>{video.views}</span>
                          <span>·</span>
                          <span>{video.timestamp}</span>
                        </div>
                      </div>
                      <button className="w-10 h-10 rounded-full hover:bg-gray-100 flex items-center justify-center">
                        <MoreHorizontal className="w-5 h-5 text-gray-500" />
                      </button>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100">
                      <div className="flex items-center gap-6">
                        <button className="flex items-center gap-2 text-gray-600 hover:text-blue-500 transition-colors">
                          <ThumbsUp className="w-5 h-5" />
                          <span className="font-medium">{(video.likes / 1000).toFixed(0)}K</span>
                        </button>
                        <button className="flex items-center gap-2 text-gray-600 hover:text-blue-500 transition-colors">
                          <MessageCircle className="w-5 h-5" />
                          <span className="font-medium">{video.comments.toLocaleString()}</span>
                        </button>
                        <button className="flex items-center gap-2 text-gray-600 hover:text-blue-500 transition-colors">
                          <Share2 className="w-5 h-5" />
                          <span className="font-medium">Share</span>
                        </button>
                      </div>
                      <button className="text-gray-600 hover:text-blue-500 transition-colors">
                        <Bookmark className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WatchPage;
