import React, { useState, useEffect } from 'react';
import { notifications as staticNotifications, users } from '../data/socialData';
import { 
  X, Settings, MoreHorizontal, Heart, MessageCircle, UserPlus, 
  AtSign, Cake, Check, Bell, BellOff, Volume2, VolumeX,
  DollarSign, Crown, Gift, Trash2
} from 'lucide-react';

interface NotificationsPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

interface NotificationSettings {
  soundEnabled: boolean;
  likesEnabled: boolean;
  commentsEnabled: boolean;
  friendRequestsEnabled: boolean;
  messagesEnabled: boolean;
  mentionsEnabled: boolean;
}

const NotificationsPanel: React.FC<NotificationsPanelProps> = ({ isOpen, onClose }) => {
  const [filter, setFilter] = useState<'all' | 'unread'>('all');
  const [notificationsList, setNotificationsList] = useState(staticNotifications);
  const [showSettings, setShowSettings] = useState(false);
  const [settings, setSettings] = useState<NotificationSettings>({
    soundEnabled: true,
    likesEnabled: true,
    commentsEnabled: true,
    friendRequestsEnabled: true,
    messagesEnabled: true,
    mentionsEnabled: true,
  });
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    setUnreadCount(notificationsList.filter(n => !n.read).length);
  }, [notificationsList]);

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'like':
        return <Heart className="w-4 h-4 text-white" />;
      case 'comment':
        return <MessageCircle className="w-4 h-4 text-white" />;
      case 'friend_request':
        return <UserPlus className="w-4 h-4 text-white" />;
      case 'mention':
        return <AtSign className="w-4 h-4 text-white" />;
      case 'birthday':
        return <Cake className="w-4 h-4 text-white" />;
      case 'tip':
        return <DollarSign className="w-4 h-4 text-white" />;
      case 'subscription':
        return <Crown className="w-4 h-4 text-white" />;
      default:
        return <Bell className="w-4 h-4 text-white" />;
    }
  };

  const getIconBg = (type: string) => {
    switch (type) {
      case 'like':
        return 'bg-red-500';
      case 'comment':
        return 'bg-green-500';
      case 'friend_request':
        return 'bg-blue-500';
      case 'mention':
        return 'bg-purple-500';
      case 'birthday':
        return 'bg-pink-500';
      case 'tip':
        return 'bg-emerald-500';
      case 'subscription':
        return 'bg-yellow-500';
      default:
        return 'bg-gray-500';
    }
  };

  const markAsRead = (id: string) => {
    setNotificationsList(prev => 
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    );
  };

  const markAllAsRead = () => {
    setNotificationsList(prev => prev.map(n => ({ ...n, read: true })));
  };

  const deleteNotification = (id: string) => {
    setNotificationsList(prev => prev.filter(n => n.id !== id));
  };

  const clearAll = () => {
    setNotificationsList([]);
  };

  const toggleSetting = (key: keyof NotificationSettings) => {
    setSettings(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const playNotificationSound = () => {
    if (settings.soundEnabled) {
      try {
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        oscillator.frequency.value = 800;
        oscillator.type = 'sine';
        
        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
        
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.3);
      } catch (e) {
        console.log('Could not play notification sound');
      }
    }
  };

  const filteredNotifications = filter === 'unread' 
    ? notificationsList.filter(n => !n.read)
    : notificationsList;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-start justify-end p-4 pt-16">
      <div className="w-full max-w-md bg-white rounded-xl shadow-2xl overflow-hidden animate-fadeIn">
        {/* Header */}
        <div className="p-4 border-b border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <h2 className="text-2xl font-bold text-gray-900">Notifications</h2>
              {unreadCount > 0 && (
                <span className="px-2 py-0.5 bg-red-500 text-white text-xs font-bold rounded-full">
                  {unreadCount}
                </span>
              )}
            </div>
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setShowSettings(!showSettings)}
                className={`w-9 h-9 rounded-full flex items-center justify-center transition-colors ${
                  showSettings ? 'bg-blue-100 text-blue-600' : 'hover:bg-gray-100 text-gray-600'
                }`}
              >
                <Settings className="w-5 h-5" />
              </button>
              <button 
                onClick={onClose}
                className="w-9 h-9 rounded-full hover:bg-gray-100 flex items-center justify-center"
              >
                <X className="w-5 h-5 text-gray-600" />
              </button>
            </div>
          </div>

          {/* Settings Panel */}
          {showSettings && (
            <div className="mb-4 p-4 bg-gray-50 rounded-xl space-y-3 animate-fadeIn">
              <h3 className="font-semibold text-gray-900 mb-3">Notification Settings</h3>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {settings.soundEnabled ? <Volume2 className="w-4 h-4 text-gray-600" /> : <VolumeX className="w-4 h-4 text-gray-400" />}
                  <span className="text-sm text-gray-700">Sound</span>
                </div>
                <button
                  onClick={() => toggleSetting('soundEnabled')}
                  className={`w-10 h-6 rounded-full relative transition-colors ${
                    settings.soundEnabled ? 'bg-blue-500' : 'bg-gray-300'
                  }`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${
                    settings.soundEnabled ? 'right-1' : 'left-1'
                  }`} />
                </button>
              </div>

              {[
                { key: 'likesEnabled', label: 'Likes', icon: Heart },
                { key: 'commentsEnabled', label: 'Comments', icon: MessageCircle },
                { key: 'friendRequestsEnabled', label: 'Friend Requests', icon: UserPlus },
                { key: 'messagesEnabled', label: 'Messages', icon: MessageCircle },
                { key: 'mentionsEnabled', label: 'Mentions', icon: AtSign },
              ].map((item) => (
                <div key={item.key} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <item.icon className={`w-4 h-4 ${settings[item.key as keyof NotificationSettings] ? 'text-gray-600' : 'text-gray-400'}`} />
                    <span className="text-sm text-gray-700">{item.label}</span>
                  </div>
                  <button
                    onClick={() => toggleSetting(item.key as keyof NotificationSettings)}
                    className={`w-10 h-6 rounded-full relative transition-colors ${
                      settings[item.key as keyof NotificationSettings] ? 'bg-blue-500' : 'bg-gray-300'
                    }`}
                  >
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${
                      settings[item.key as keyof NotificationSettings] ? 'right-1' : 'left-1'
                    }`} />
                  </button>
                </div>
              ))}

              <button
                onClick={() => playNotificationSound()}
                className="w-full mt-2 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
              >
                Test Notification Sound
              </button>
            </div>
          )}
          
          {/* Filter Tabs */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setFilter('all')}
              className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
                filter === 'all' 
                  ? 'bg-blue-100 text-blue-600' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilter('unread')}
              className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
                filter === 'unread' 
                  ? 'bg-blue-100 text-blue-600' 
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              Unread
            </button>
            <div className="ml-auto flex items-center gap-2">
              <button
                onClick={markAllAsRead}
                className="text-sm text-blue-500 hover:underline"
              >
                Mark all read
              </button>
              <button
                onClick={clearAll}
                className="text-sm text-red-500 hover:underline"
              >
                Clear all
              </button>
            </div>
          </div>
        </div>

        {/* Notifications List */}
        <div className="max-h-[60vh] overflow-y-auto">
          {filteredNotifications.length === 0 ? (
            <div className="p-8 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="w-8 h-8 text-gray-400" />
              </div>
              <p className="text-gray-500 font-medium">All caught up!</p>
              <p className="text-sm text-gray-400 mt-1">No notifications to show</p>
            </div>
          ) : (
            <div>
              {/* New Notifications */}
              {filteredNotifications.filter(n => !n.read).length > 0 && (
                <>
                  <div className="px-4 py-2 bg-gray-50">
                    <h3 className="font-semibold text-gray-900 text-sm">New</h3>
                  </div>
                  {filteredNotifications.filter(n => !n.read).map((notification) => (
                    <div
                      key={notification.id}
                      className="relative group w-full flex items-start gap-3 px-4 py-3 hover:bg-gray-50 transition-colors bg-blue-50/50"
                    >
                      <button
                        onClick={() => markAsRead(notification.id)}
                        className="flex-1 flex items-start gap-3"
                      >
                        <div className="relative flex-shrink-0">
                          <img 
                            src={notification.user.avatar}
                            alt={notification.user.name}
                            className="w-14 h-14 rounded-full object-cover"
                          />
                          <div className={`absolute -bottom-1 -right-1 w-6 h-6 ${getIconBg(notification.type)} rounded-full flex items-center justify-center border-2 border-white`}>
                            {getNotificationIcon(notification.type)}
                          </div>
                        </div>
                        <div className="flex-1 text-left">
                          <p className="text-sm text-gray-900">
                            <span className="font-semibold">{notification.user.name}</span>{' '}
                            {notification.content}
                          </p>
                          <p className="text-xs mt-1 text-blue-500 font-medium">
                            {notification.timestamp}
                          </p>
                          
                          {notification.type === 'friend_request' && (
                            <div className="flex items-center gap-2 mt-2">
                              <button className="px-4 py-1.5 bg-blue-500 text-white text-sm font-medium rounded-md hover:bg-blue-600 transition-colors">
                                Confirm
                              </button>
                              <button className="px-4 py-1.5 bg-gray-200 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-300 transition-colors">
                                Delete
                              </button>
                            </div>
                          )}
                        </div>
                      </button>
                      <button 
                        onClick={() => deleteNotification(notification.id)}
                        className="opacity-0 group-hover:opacity-100 w-8 h-8 rounded-full hover:bg-red-100 flex items-center justify-center transition-all"
                      >
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </button>
                      <div className="w-3 h-3 bg-blue-500 rounded-full flex-shrink-0 mt-2" />
                    </div>
                  ))}
                </>
              )}

              {/* Earlier Notifications */}
              {filteredNotifications.filter(n => n.read).length > 0 && (
                <>
                  <div className="px-4 py-2 bg-gray-50 border-t border-gray-100">
                    <h3 className="font-semibold text-gray-900 text-sm">Earlier</h3>
                  </div>
                  {filteredNotifications.filter(n => n.read).map((notification) => (
                    <div
                      key={notification.id}
                      className="relative group w-full flex items-start gap-3 px-4 py-3 hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex-1 flex items-start gap-3">
                        <div className="relative flex-shrink-0">
                          <img 
                            src={notification.user.avatar}
                            alt={notification.user.name}
                            className="w-14 h-14 rounded-full object-cover"
                          />
                          <div className={`absolute -bottom-1 -right-1 w-6 h-6 ${getIconBg(notification.type)} rounded-full flex items-center justify-center border-2 border-white`}>
                            {getNotificationIcon(notification.type)}
                          </div>
                        </div>
                        <div className="flex-1 text-left">
                          <p className="text-sm text-gray-900">
                            <span className="font-semibold">{notification.user.name}</span>{' '}
                            {notification.content}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            {notification.timestamp}
                          </p>
                        </div>
                      </div>
                      <button 
                        onClick={() => deleteNotification(notification.id)}
                        className="opacity-0 group-hover:opacity-100 w-8 h-8 rounded-full hover:bg-red-100 flex items-center justify-center transition-all"
                      >
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </button>
                    </div>
                  ))}
                </>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-100 bg-gray-50">
          <div className="flex items-center justify-between">
            <button 
              onClick={() => toggleSetting('soundEnabled')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition-colors ${
                settings.soundEnabled 
                  ? 'bg-blue-100 text-blue-600' 
                  : 'bg-gray-200 text-gray-600'
              }`}
            >
              {settings.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              Sound {settings.soundEnabled ? 'On' : 'Off'}
            </button>
            <button className="text-blue-500 font-medium text-sm hover:underline">
              See all notifications
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotificationsPanel;
