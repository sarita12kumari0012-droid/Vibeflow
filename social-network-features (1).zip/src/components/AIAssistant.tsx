import React, { useState, useRef, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { 
  Sparkles, Send, X, Loader2, Copy, Check, RefreshCw, 
  Wand2, MessageSquare, Hash, FileText, Globe, Lightbulb,
  TrendingUp, User, ChevronDown, ChevronUp, Bot
} from 'lucide-react';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface AIAssistantProps {
  isOpen: boolean;
  onClose: () => void;
  onInsertContent?: (content: string) => void;
}

const AIAssistant: React.FC<AIAssistantProps> = ({ isOpen, onClose, onInsertContent }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'chat' | 'tools'>('tools');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const callAI = async (action: string, prompt: string, style?: string) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const { data, error: fnError } = await supabase.functions.invoke('ai-assistant', {
        body: { action, prompt, style }
      });

      if (fnError) throw fnError;
      
      if (!data.success) {
        throw new Error(data.error || 'AI generation failed');
      }

      return data.content;
    } catch (err: any) {
      console.error('AI error:', err);
      setError(err.message || 'Failed to generate content. Please try again.');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');

    const response = await callAI('chat_assistant', input);
    
    if (response) {
      const assistantMessage: Message = {
        id: `msg-${Date.now()}-ai`,
        role: 'assistant',
        content: response,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, assistantMessage]);
    }
  };

  const handleQuickAction = async (action: string, customPrompt?: string) => {
    const prompt = customPrompt || input;
    if (!prompt.trim()) {
      setError('Please enter some text first');
      return;
    }

    const response = await callAI(action, prompt);
    
    if (response) {
      const assistantMessage: Message = {
        id: `msg-${Date.now()}-ai`,
        role: 'assistant',
        content: response,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, assistantMessage]);
      setActiveTab('chat');
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const quickTools = [
    { 
      id: 'generate_post', 
      icon: FileText, 
      label: 'Generate Post', 
      desc: 'Create engaging social media posts',
      color: 'from-blue-500 to-blue-600'
    },
    { 
      id: 'improve_post', 
      icon: Wand2, 
      label: 'Improve Post', 
      desc: 'Enhance your existing content',
      color: 'from-purple-500 to-purple-600'
    },
    { 
      id: 'generate_caption', 
      icon: MessageSquare, 
      label: 'Photo Caption', 
      desc: 'Write captions for your photos',
      color: 'from-pink-500 to-pink-600'
    },
    { 
      id: 'generate_hashtags', 
      icon: Hash, 
      label: 'Hashtags', 
      desc: 'Get trending hashtags',
      color: 'from-green-500 to-green-600'
    },
    { 
      id: 'content_suggestions', 
      icon: Lightbulb, 
      label: 'Content Ideas', 
      desc: 'Get content inspiration',
      color: 'from-yellow-500 to-orange-500'
    },
    { 
      id: 'analyze_engagement', 
      icon: TrendingUp, 
      label: 'Analyze Content', 
      desc: 'Get engagement insights',
      color: 'from-cyan-500 to-cyan-600'
    },
    { 
      id: 'translate_post', 
      icon: Globe, 
      label: 'Translate', 
      desc: 'Translate your content',
      color: 'from-indigo-500 to-indigo-600'
    },
    { 
      id: 'generate_bio', 
      icon: User, 
      label: 'Create Bio', 
      desc: 'Generate profile bio',
      color: 'from-rose-500 to-rose-600'
    },
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden animate-fadeIn">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-blue-600 p-4 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                <Bot className="w-6 h-6" />
              </div>
              <div>
                <h2 className="font-bold text-lg">AI Assistant</h2>
                <p className="text-sm text-white/80">Powered by Gemini</p>
              </div>
            </div>
            <button 
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          
          {/* Tabs */}
          <div className="flex gap-2 mt-4">
            <button
              onClick={() => setActiveTab('tools')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'tools' 
                  ? 'bg-white text-purple-600' 
                  : 'bg-white/20 text-white hover:bg-white/30'
              }`}
            >
              <Sparkles className="w-4 h-4 inline mr-2" />
              AI Tools
            </button>
            <button
              onClick={() => setActiveTab('chat')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === 'chat' 
                  ? 'bg-white text-purple-600' 
                  : 'bg-white/20 text-white hover:bg-white/30'
              }`}
            >
              <MessageSquare className="w-4 h-4 inline mr-2" />
              Chat
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4">
          {activeTab === 'tools' ? (
            <div className="space-y-4">
              {/* Input for tools */}
              <div className="bg-gray-50 rounded-xl p-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Enter your topic or content
                </label>
                <textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="E.g., 'My morning coffee routine' or paste your existing post to improve..."
                  className="w-full p-3 border border-gray-200 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-purple-500"
                  rows={3}
                />
              </div>

              {/* Quick Tools Grid */}
              <div className="grid grid-cols-2 gap-3">
                {quickTools.map((tool) => (
                  <button
                    key={tool.id}
                    onClick={() => handleQuickAction(tool.id)}
                    disabled={isLoading}
                    className={`p-4 rounded-xl bg-gradient-to-br ${tool.color} text-white text-left hover:opacity-90 transition-opacity disabled:opacity-50`}
                  >
                    <tool.icon className="w-6 h-6 mb-2" />
                    <p className="font-semibold">{tool.label}</p>
                    <p className="text-xs text-white/80">{tool.desc}</p>
                  </button>
                ))}
              </div>

              {error && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-red-600 text-sm">
                  {error}
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {/* Chat Messages */}
              {messages.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <Bot className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                  <p className="font-medium">Start a conversation</p>
                  <p className="text-sm">Ask me anything about social media!</p>
                </div>
              ) : (
                messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[85%] rounded-2xl p-4 ${
                        msg.role === 'user'
                          ? 'bg-gradient-to-br from-purple-600 to-blue-600 text-white'
                          : 'bg-gray-100 text-gray-800'
                      }`}
                    >
                      <p className="whitespace-pre-wrap text-sm">{msg.content}</p>
                      {msg.role === 'assistant' && (
                        <div className="flex items-center gap-2 mt-3 pt-2 border-t border-gray-200">
                          <button
                            onClick={() => copyToClipboard(msg.content, msg.id)}
                            className="flex items-center gap-1 text-xs text-gray-500 hover:text-gray-700"
                          >
                            {copiedId === msg.id ? (
                              <Check className="w-3 h-3" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                            {copiedId === msg.id ? 'Copied!' : 'Copy'}
                          </button>
                          {onInsertContent && (
                            <button
                              onClick={() => {
                                onInsertContent(msg.content);
                                onClose();
                              }}
                              className="flex items-center gap-1 text-xs text-purple-600 hover:text-purple-700"
                            >
                              <FileText className="w-3 h-3" />
                              Use this
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-gray-100 rounded-2xl p-4">
                    <Loader2 className="w-5 h-5 animate-spin text-purple-600" />
                  </div>
                </div>
              )}
              {error && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-red-600 text-sm">
                  {error}
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Chat Input */}
        {activeTab === 'chat' && (
          <div className="p-4 border-t border-gray-100">
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Ask me anything..."
                className="flex-1 px-4 py-3 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-purple-500"
                disabled={isLoading}
              />
              <button
                onClick={handleSendMessage}
                disabled={isLoading || !input.trim()}
                className="w-12 h-12 bg-gradient-to-br from-purple-600 to-blue-600 rounded-full flex items-center justify-center text-white hover:opacity-90 transition-opacity disabled:opacity-50"
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Send className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AIAssistant;
