import React, { useState } from 'react';
import { 
  ArrowLeft, Calendar, Clock, Share2, Heart, MessageCircle,
  ChevronLeft, ChevronRight, Sparkles, Image, Video, Users,
  MapPin, Gift, Star, MoreHorizontal, Bookmark
} from 'lucide-react';
import { users, currentUser } from '../data/socialData';

interface Memory {
  id: string;
  type: 'post' | 'photo' | 'friendship' | 'event' | 'checkin';
  date: string;
  yearsAgo: number;
  content?: string;
  images?: string[];
  friend?: typeof users[0];
  location?: string;
  likes: number;
  comments: number;
}

interface MemoriesPageProps {
  onBack: () => void;
}

const MemoriesPage: React.FC<MemoriesPageProps> = ({ onBack }) => {
  const [selectedYear, setSelectedYear] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState('today');

  const memories: Memory[] = [
    {
      id: 'm1',
      type: 'post',
      date: 'December 9, 2023',
      yearsAgo: 1,
      content: 'What an amazing year it has been! Grateful for all the wonderful moments and people in my life. Here\'s to more adventures! 🎉',
      images: ['https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298672761_8e473f6e.jpg'],
      likes: 234,
      comments: 45
    },
    {
      id: 'm2',
      type: 'friendship',
      date: 'December 9, 2022',
      yearsAgo: 2,
      friend: users[3],
      likes: 89,
      comments: 12
    },
    {
      id: 'm3',
      type: 'photo',
      date: 'December 9, 2021',
      yearsAgo: 3,
      content: 'Throwback to this beautiful sunset! Nature never fails to amaze me.',
      images: [
        'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298743451_fdf3e0a7.png',
        'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681347_8aa2cbbc.png'
      ],
      likes: 567,
      comments: 78
    },
    {
      id: 'm4',
      type: 'checkin',
      date: 'December 9, 2020',
      yearsAgo: 4,
      content: 'Having the best time!',
      location: 'Central Park, New York',
      images: ['https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298770024_3c3895be.jpg'],
      likes: 123,
      comments: 23
    },
    {
      id: 'm5',
      type: 'event',
      date: 'December 9, 2019',
      yearsAgo: 5,
      content: 'Birthday celebration with the best people! 🎂',
      images: ['https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681505_56062067.png'],
      likes: 456,
      comments: 89
    }
  ];

  const tabs = [
    { id: 'today', label: 'On This Day' },
    { id: 'recaps', label: 'Recaps' },
    { id: 'highlights', label: 'Highlights' }
  ];

  const years = [2023, 2022, 2021, 2020, 2019, 2018];

  const filteredMemories = selectedYear 
    ? memories.filter(m => m.yearsAgo === new Date().getFullYear() - selectedYear)
    : memories;

  const renderMemoryCard = (memory: Memory) => {
    return (
      <div key={memory.id} className="bg-white rounded-xl shadow-sm overflow-hidden">
        {/* Header */}
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
              <Clock className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="font-semibold text-gray-900">{memory.yearsAgo} {memory.yearsAgo === 1 ? 'Year' : 'Years'} Ago</p>
              <p className="text-sm text-gray-500">{memory.date}</p>
            </div>
          </div>
          <button className="w-8 h-8 hover:bg-gray-100 rounded-full flex items-center justify-center">
            <MoreHorizontal className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Content based on type */}
        {memory.type === 'friendship' && memory.friend && (
          <div className="px-4 pb-4">
            <div className="bg-gradient-to-r from-pink-50 to-purple-50 rounded-xl p-4 flex items-center gap-4">
              <div className="relative">
                <img 
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-16 h-16 rounded-full object-cover border-4 border-white"
                />
                <img 
                  src={memory.friend.avatar}
                  alt={memory.friend.name}
                  className="w-16 h-16 rounded-full object-cover border-4 border-white absolute -right-8 top-0"
                />
              </div>
              <div className="ml-8">
                <div className="flex items-center gap-2 mb-1">
                  <Users className="w-5 h-5 text-pink-500" />
                  <span className="font-semibold text-gray-900">Became Friends</span>
                </div>
                <p className="text-sm text-gray-600">You and {memory.friend.name} became friends</p>
              </div>
            </div>
          </div>
        )}

        {memory.type === 'checkin' && (
          <div className="px-4">
            <div className="flex items-center gap-2 text-blue-600 mb-2">
              <MapPin className="w-4 h-4" />
              <span className="font-medium text-sm">{memory.location}</span>
            </div>
          </div>
        )}

        {memory.content && memory.type !== 'friendship' && (
          <div className="px-4 pb-3">
            <p className="text-gray-800">{memory.content}</p>
          </div>
        )}

        {memory.images && memory.images.length > 0 && (
          <div className={`grid ${memory.images.length > 1 ? 'grid-cols-2' : 'grid-cols-1'} gap-1`}>
            {memory.images.map((img, idx) => (
              <img 
                key={idx}
                src={img}
                alt="Memory"
                className="w-full h-64 object-cover"
              />
            ))}
          </div>
        )}

        {/* Actions */}
        <div className="p-4 border-t flex items-center justify-between">
          <div className="flex items-center gap-6">
            <button className="flex items-center gap-2 text-gray-600 hover:text-red-500 transition-colors">
              <Heart className="w-5 h-5" />
              <span className="text-sm font-medium">{memory.likes}</span>
            </button>
            <button className="flex items-center gap-2 text-gray-600 hover:text-blue-500 transition-colors">
              <MessageCircle className="w-5 h-5" />
              <span className="text-sm font-medium">{memory.comments}</span>
            </button>
          </div>
          <div className="flex items-center gap-2">
            <button className="px-4 py-2 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors flex items-center gap-2">
              <Share2 className="w-4 h-4" />
              Share
            </button>
            <button className="w-10 h-10 hover:bg-gray-100 rounded-full flex items-center justify-center">
              <Bookmark className="w-5 h-5 text-gray-500" />
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-3xl mx-auto px-4">
          <div className="flex items-center h-16">
            <button 
              onClick={onBack}
              className="w-10 h-10 flex items-center justify-center hover:bg-gray-100 rounded-full transition-colors mr-4"
            >
              <ArrowLeft className="w-6 h-6 text-gray-700" />
            </button>
            <h1 className="text-2xl font-bold text-gray-900">Memories</h1>
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 py-6">
        {/* Hero Banner */}
        <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 rounded-2xl p-6 mb-6 text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/10 rounded-full translate-y-1/2 -translate-x-1/2" />
          
          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-14 h-14 bg-white/20 rounded-full flex items-center justify-center">
                <Sparkles className="w-7 h-7" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">On This Day</h2>
                <p className="text-blue-100">December 9th</p>
              </div>
            </div>
            <p className="text-blue-100 mb-4">
              Look back at photos and memories from this day over the years.
            </p>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                <span>{memories.length} Memories</span>
              </div>
              <div className="flex items-center gap-2">
                <Image className="w-5 h-5" />
                <span>{memories.filter(m => m.images).length} Photos</span>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-6 py-2.5 rounded-full font-medium whitespace-nowrap transition-colors ${
                activeTab === tab.id
                  ? 'bg-blue-500 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Year Filter */}
        <div className="bg-white rounded-xl shadow-sm p-4 mb-6">
          <h3 className="font-semibold text-gray-900 mb-3">Filter by Year</h3>
          <div className="flex gap-2 overflow-x-auto pb-2">
            <button
              onClick={() => setSelectedYear(null)}
              className={`px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition-colors ${
                selectedYear === null
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              All Years
            </button>
            {years.map(year => (
              <button
                key={year}
                onClick={() => setSelectedYear(year)}
                className={`px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition-colors ${
                  selectedYear === year
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {year}
              </button>
            ))}
          </div>
        </div>

        {/* Memories List */}
        <div className="space-y-6">
          {filteredMemories.length > 0 ? (
            filteredMemories.map(renderMemoryCard)
          ) : (
            <div className="bg-white rounded-xl shadow-sm p-8 text-center">
              <Clock className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No Memories Found</h3>
              <p className="text-gray-500">No memories from {selectedYear} on this day.</p>
            </div>
          )}
        </div>

        {/* Care Section */}
        <div className="mt-8 bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
              <Gift className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Friends to Celebrate</h3>
              <p className="text-sm text-gray-500">Birthdays and friendaversaries this month</p>
            </div>
          </div>
          <div className="space-y-3">
            {users.slice(0, 3).map(user => (
              <div key={user.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <img 
                    src={user.avatar}
                    alt={user.name}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <p className="font-medium text-gray-900">{user.name}</p>
                    <p className="text-sm text-gray-500">Birthday on Dec 15</p>
                  </div>
                </div>
                <button className="px-4 py-2 bg-blue-500 text-white rounded-lg font-medium text-sm hover:bg-blue-600 transition-colors">
                  Send Wishes
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MemoriesPage;
