import React, { useState } from 'react';
import { 
  ArrowLeft, Gamepad2, Play, Users, Eye, Heart, MessageCircle,
  Trophy, Star, Clock, TrendingUp, Zap, Crown, Gift, Search,
  ChevronRight, Volume2, VolumeX, Maximize2
} from 'lucide-react';
import { users } from '../data/socialData';

interface Game {
  id: string;
  name: string;
  cover: string;
  category: string;
  players: number;
  rating: number;
}

interface Stream {
  id: string;
  streamer: typeof users[0];
  title: string;
  game: string;
  thumbnail: string;
  viewers: number;
  isLive: boolean;
}

interface GamingPageProps {
  onBack: () => void;
}

const GamingPage: React.FC<GamingPageProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState('browse');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStream, setSelectedStream] = useState<Stream | null>(null);
  const [isMuted, setIsMuted] = useState(false);

  const games: Game[] = [
    { id: 'g1', name: 'Fortnite', cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298773815_6b3b8d77.png', category: 'Battle Royale', players: 2500000, rating: 4.5 },
    { id: 'g2', name: 'Minecraft', cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681347_8aa2cbbc.png', category: 'Sandbox', players: 1800000, rating: 4.8 },
    { id: 'g3', name: 'Call of Duty', cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298770024_3c3895be.jpg', category: 'FPS', players: 3200000, rating: 4.3 },
    { id: 'g4', name: 'League of Legends', cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298743451_fdf3e0a7.png', category: 'MOBA', players: 4500000, rating: 4.6 },
    { id: 'g5', name: 'Valorant', cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681505_56062067.png', category: 'FPS', players: 2100000, rating: 4.4 },
    { id: 'g6', name: 'Apex Legends', cover: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298748674_67ccb172.png', category: 'Battle Royale', players: 1500000, rating: 4.2 }
  ];

  const streams: Stream[] = [
    { id: 's1', streamer: users[9], title: 'Pro Tournament Finals! Road to Champion', game: 'Fortnite', thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298773815_6b3b8d77.png', viewers: 45200, isLive: true },
    { id: 's2', streamer: users[1], title: 'Chill Minecraft Building Stream', game: 'Minecraft', thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681347_8aa2cbbc.png', viewers: 12300, isLive: true },
    { id: 's3', streamer: users[5], title: 'Ranked Grind to Diamond!', game: 'Valorant', thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681505_56062067.png', viewers: 8900, isLive: true },
    { id: 's4', streamer: users[3], title: 'Learning New Champions', game: 'League of Legends', thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298743451_fdf3e0a7.png', viewers: 23400, isLive: true },
    { id: 's5', streamer: users[7], title: 'Warzone with Viewers!', game: 'Call of Duty', thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298770024_3c3895be.jpg', viewers: 15600, isLive: true },
    { id: 's6', streamer: users[11], title: 'Apex Ranked Push', game: 'Apex Legends', thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298748674_67ccb172.png', viewers: 6700, isLive: true }
  ];

  const tournaments = [
    { id: 't1', name: 'Winter Championship', game: 'Fortnite', prize: '$50,000', date: 'Dec 20-22', participants: 256 },
    { id: 't2', name: 'Pro League Finals', game: 'Valorant', prize: '$25,000', date: 'Dec 18', participants: 64 },
    { id: 't3', name: 'World Series', game: 'League of Legends', prize: '$100,000', date: 'Jan 5-7', participants: 16 }
  ];

  const formatNumber = (num: number): string => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const tabs = [
    { id: 'browse', label: 'Browse', icon: Gamepad2 },
    { id: 'live', label: 'Live', icon: Play },
    { id: 'tournaments', label: 'Tournaments', icon: Trophy },
    { id: 'following', label: 'Following', icon: Heart }
  ];

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <div className="bg-gray-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <button 
                onClick={onBack}
                className="w-10 h-10 flex items-center justify-center hover:bg-gray-700 rounded-full transition-colors"
              >
                <ArrowLeft className="w-6 h-6" />
              </button>
              <div className="flex items-center gap-2">
                <Gamepad2 className="w-8 h-8 text-purple-500" />
                <h1 className="text-2xl font-bold">Gaming</h1>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="relative hidden md:block">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search games, streamers..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-64 pl-10 pr-4 py-2 bg-gray-700 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
              <button className="px-4 py-2 bg-purple-600 rounded-lg font-medium hover:bg-purple-700 transition-colors flex items-center gap-2">
                <Play className="w-5 h-5" />
                Go Live
              </button>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex items-center gap-1 pb-3 overflow-x-auto">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium text-sm whitespace-nowrap transition-colors ${
                  activeTab === tab.id
                    ? 'bg-purple-600 text-white'
                    : 'text-gray-400 hover:bg-gray-700 hover:text-white'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Featured Stream */}
        {activeTab === 'browse' && !selectedStream && (
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <Zap className="w-6 h-6 text-yellow-500" />
                Featured Stream
              </h2>
            </div>
            <div 
              className="relative rounded-2xl overflow-hidden cursor-pointer group"
              onClick={() => setSelectedStream(streams[0])}
            >
              <img 
                src={streams[0].thumbnail}
                alt={streams[0].title}
                className="w-full h-[400px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
              <div className="absolute top-4 left-4 flex items-center gap-2">
                <span className="px-2 py-1 bg-red-600 rounded text-xs font-bold flex items-center gap-1">
                  <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
                  LIVE
                </span>
                <span className="px-2 py-1 bg-black/50 rounded text-xs font-medium flex items-center gap-1">
                  <Eye className="w-3 h-3" />
                  {formatNumber(streams[0].viewers)}
                </span>
              </div>
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <div className="flex items-center gap-3 mb-3">
                  <img 
                    src={streams[0].streamer.avatar}
                    alt={streams[0].streamer.name}
                    className="w-12 h-12 rounded-full border-2 border-purple-500 object-cover"
                  />
                  <div>
                    <h3 className="font-bold text-lg">{streams[0].streamer.name}</h3>
                    <p className="text-sm text-gray-300">{streams[0].game}</p>
                  </div>
                </div>
                <p className="text-xl font-semibold">{streams[0].title}</p>
              </div>
              <div className="absolute inset-0 bg-purple-600/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <div className="w-20 h-20 bg-purple-600 rounded-full flex items-center justify-center">
                  <Play className="w-10 h-10 ml-1" />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Stream Player */}
        {selectedStream && (
          <div className="mb-8">
            <div className="relative rounded-2xl overflow-hidden bg-black">
              <img 
                src={selectedStream.thumbnail}
                alt={selectedStream.title}
                className="w-full h-[500px] object-cover"
              />
              <div className="absolute top-4 left-4 flex items-center gap-2">
                <span className="px-2 py-1 bg-red-600 rounded text-xs font-bold flex items-center gap-1">
                  <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
                  LIVE
                </span>
                <span className="px-2 py-1 bg-black/50 rounded text-xs font-medium flex items-center gap-1">
                  <Eye className="w-3 h-3" />
                  {formatNumber(selectedStream.viewers)}
                </span>
              </div>
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => setIsMuted(!isMuted)}
                    className="w-10 h-10 bg-black/50 rounded-full flex items-center justify-center hover:bg-black/70"
                  >
                    {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                  </button>
                </div>
                <div className="flex items-center gap-2">
                  <button className="w-10 h-10 bg-black/50 rounded-full flex items-center justify-center hover:bg-black/70">
                    <Maximize2 className="w-5 h-5" />
                  </button>
                  <button 
                    onClick={() => setSelectedStream(null)}
                    className="px-4 py-2 bg-red-600 rounded-lg font-medium hover:bg-red-700"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
            <div className="bg-gray-800 rounded-b-2xl p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img 
                    src={selectedStream.streamer.avatar}
                    alt={selectedStream.streamer.name}
                    className="w-12 h-12 rounded-full border-2 border-purple-500 object-cover"
                  />
                  <div>
                    <h3 className="font-bold">{selectedStream.streamer.name}</h3>
                    <p className="text-sm text-gray-400">{selectedStream.title}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button className="px-4 py-2 bg-purple-600 rounded-lg font-medium hover:bg-purple-700 flex items-center gap-2">
                    <Heart className="w-5 h-5" />
                    Follow
                  </button>
                  <button className="px-4 py-2 bg-yellow-500 text-black rounded-lg font-medium hover:bg-yellow-400 flex items-center gap-2">
                    <Gift className="w-5 h-5" />
                    Subscribe
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Live Streams */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <Play className="w-6 h-6 text-red-500" />
              Live Now
            </h2>
            <button className="text-purple-400 hover:text-purple-300 flex items-center gap-1 text-sm font-medium">
              See All <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {streams.map(stream => (
              <div 
                key={stream.id}
                className="bg-gray-800 rounded-xl overflow-hidden hover:ring-2 hover:ring-purple-500 transition-all cursor-pointer"
                onClick={() => setSelectedStream(stream)}
              >
                <div className="relative">
                  <img 
                    src={stream.thumbnail}
                    alt={stream.title}
                    className="w-full h-40 object-cover"
                  />
                  <div className="absolute top-2 left-2 flex items-center gap-2">
                    <span className="px-2 py-0.5 bg-red-600 rounded text-xs font-bold flex items-center gap-1">
                      <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
                      LIVE
                    </span>
                    <span className="px-2 py-0.5 bg-black/50 rounded text-xs font-medium flex items-center gap-1">
                      <Eye className="w-3 h-3" />
                      {formatNumber(stream.viewers)}
                    </span>
                  </div>
                </div>
                <div className="p-3">
                  <div className="flex items-start gap-3">
                    <img 
                      src={stream.streamer.avatar}
                      alt={stream.streamer.name}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-sm truncate">{stream.title}</h3>
                      <p className="text-sm text-gray-400">{stream.streamer.name}</p>
                      <p className="text-xs text-gray-500">{stream.game}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Popular Games */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-green-500" />
              Popular Games
            </h2>
            <button className="text-purple-400 hover:text-purple-300 flex items-center gap-1 text-sm font-medium">
              See All <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {games.map(game => (
              <div 
                key={game.id}
                className="bg-gray-800 rounded-xl overflow-hidden hover:ring-2 hover:ring-purple-500 transition-all cursor-pointer group"
              >
                <div className="relative">
                  <img 
                    src={game.cover}
                    alt={game.name}
                    className="w-full h-32 object-cover group-hover:scale-105 transition-transform"
                  />
                </div>
                <div className="p-3">
                  <h3 className="font-semibold text-sm truncate">{game.name}</h3>
                  <p className="text-xs text-gray-400">{game.category}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="text-xs text-gray-500 flex items-center gap-1">
                      <Users className="w-3 h-3" />
                      {formatNumber(game.players)}
                    </span>
                    <span className="text-xs text-yellow-500 flex items-center gap-1">
                      <Star className="w-3 h-3 fill-current" />
                      {game.rating}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Tournaments */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <Trophy className="w-6 h-6 text-yellow-500" />
              Upcoming Tournaments
            </h2>
            <button className="text-purple-400 hover:text-purple-300 flex items-center gap-1 text-sm font-medium">
              See All <ChevronRight className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {tournaments.map(tournament => (
              <div 
                key={tournament.id}
                className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-4 border border-gray-700 hover:border-purple-500 transition-colors"
              >
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-lg flex items-center justify-center">
                    <Trophy className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold">{tournament.name}</h3>
                    <p className="text-sm text-gray-400">{tournament.game}</p>
                  </div>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Prize Pool</span>
                    <span className="font-bold text-green-400">{tournament.prize}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Date</span>
                    <span className="font-medium">{tournament.date}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-400">Teams</span>
                    <span className="font-medium">{tournament.participants}</span>
                  </div>
                </div>
                <button className="w-full mt-4 py-2 bg-purple-600 rounded-lg font-medium hover:bg-purple-700 transition-colors">
                  Register Now
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default GamingPage;
