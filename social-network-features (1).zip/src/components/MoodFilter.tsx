import React, { useState } from 'react';
import { Sparkles, X, Smile, Heart, Zap, Coffee, Moon, Sun, Music, Briefcase } from 'lucide-react';

interface MoodFilterProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectMood: (mood: string | null) => void;
  currentMood: string | null;
}

const MoodFilter: React.FC<MoodFilterProps> = ({ isOpen, onClose, onSelectMood, currentMood }) => {
  const moods = [
    { id: 'happy', label: 'Happy Vibes', icon: Smile, color: 'from-yellow-400 to-orange-400', emoji: '😊' },
    { id: 'inspiring', label: 'Inspiring', icon: Zap, color: 'from-purple-400 to-pink-400', emoji: '✨' },
    { id: 'relaxing', label: 'Relaxing', icon: Coffee, color: 'from-green-400 to-teal-400', emoji: '🌿' },
    { id: 'romantic', label: 'Romantic', icon: Heart, color: 'from-red-400 to-pink-400', emoji: '💕' },
    { id: 'energetic', label: 'Energetic', icon: Sun, color: 'from-orange-400 to-red-400', emoji: '🔥' },
    { id: 'chill', label: 'Chill', icon: Moon, color: 'from-blue-400 to-indigo-400', emoji: '🌙' },
    { id: 'creative', label: 'Creative', icon: Music, color: 'from-pink-400 to-purple-400', emoji: '🎨' },
    { id: 'productive', label: 'Productive', icon: Briefcase, color: 'from-gray-400 to-gray-600', emoji: '💼' }
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden animate-fadeIn">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-purple-500 to-pink-500 text-white">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                <Sparkles className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-xl font-bold">Mood-Based Feed</h2>
                <p className="text-sm opacity-80">Customize your experience</p>
              </div>
            </div>
            <button 
              onClick={onClose}
              className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <p className="text-sm opacity-90">
            Select a mood to filter your feed and see content that matches how you're feeling right now.
          </p>
        </div>

        {/* Mood Options */}
        <div className="p-6">
          <div className="grid grid-cols-2 gap-3">
            {moods.map((mood) => (
              <button
                key={mood.id}
                onClick={() => {
                  onSelectMood(currentMood === mood.id ? null : mood.id);
                }}
                className={`relative p-4 rounded-xl border-2 transition-all ${
                  currentMood === mood.id
                    ? 'border-purple-500 bg-purple-50'
                    : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                }`}
              >
                <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${mood.color} flex items-center justify-center mb-3 mx-auto`}>
                  <span className="text-2xl">{mood.emoji}</span>
                </div>
                <p className="font-semibold text-gray-900 text-center">{mood.label}</p>
                {currentMood === mood.id && (
                  <div className="absolute top-2 right-2 w-6 h-6 bg-purple-500 rounded-full flex items-center justify-center">
                    <svg className="w-4 h-4 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                      <path d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                )}
              </button>
            ))}
          </div>

          {/* Current Selection */}
          {currentMood && (
            <div className="mt-6 p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{moods.find(m => m.id === currentMood)?.emoji}</span>
                  <div>
                    <p className="font-semibold text-gray-900">
                      {moods.find(m => m.id === currentMood)?.label} mode active
                    </p>
                    <p className="text-sm text-gray-500">Your feed is now filtered</p>
                  </div>
                </div>
                <button 
                  onClick={() => onSelectMood(null)}
                  className="text-sm text-purple-600 font-medium hover:underline"
                >
                  Clear
                </button>
              </div>
            </div>
          )}

          {/* Apply Button */}
          <button 
            onClick={onClose}
            className="w-full mt-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl font-semibold hover:opacity-90 transition-opacity"
          >
            Apply Filter
          </button>
        </div>
      </div>
    </div>
  );
};

export default MoodFilter;
