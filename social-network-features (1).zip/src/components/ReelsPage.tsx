import React, { useState, useRef, useEffect } from 'react';
import { 
  ArrowLeft, Heart, MessageCircle, Share2, Bookmark, 
  MoreHorizontal, Music2, Volume2, VolumeX, Play, Pause,
  ThumbsUp, Send, Plus, Sparkles, TrendingUp,
  Upload, X, Loader2, Video, Camera, Film, Wand2, Hash, AtSign
} from 'lucide-react';
import { users, currentUser } from '../data/socialData';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';

interface Reel {
  id: string;
  user: {
    id: string;
    name: string;
    username: string;
    avatar: string;
    isVerified?: boolean;
  };
  video: string;
  thumbnail: string;
  caption: string;
  music: string;
  likes: number;
  comments: number;
  shares: number;
  isLiked: boolean;
  isSaved: boolean;
}

interface ReelsPageProps {
  onBack: () => void;
}

const ReelsPage: React.FC<ReelsPageProps> = ({ onBack }) => {
  const { isAuthenticated, profile } = useAuth();
  const [currentReelIndex, setCurrentReelIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isPlaying, setIsPlaying] = useState(true);
  const [showComments, setShowComments] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [activeTab, setActiveTab] = useState('For You');
  const [uploadStep, setUploadStep] = useState(1);
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Touch handling for swipe
  const touchStartY = useRef(0);
  const touchEndY = useRef(0);
  
  // Upload form state
  const [uploadForm, setUploadForm] = useState({
    videoFile: null as File | null,
    thumbnailFile: null as File | null,
    caption: '',
    music: 'Original Audio',
    videoPreview: '',
    thumbnailPreview: '',
    hashtags: [] as string[],
    mentions: [] as string[]
  });

  const [reels, setReels] = useState<Reel[]>([
    {
      id: 'r1',
      user: users[3],
      video: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298770024_3c3895be.jpg',
      thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298770024_3c3895be.jpg',
      caption: 'Morning workout routine! Start your day right with these exercises. #fitness #workout #motivation',
      music: 'Original Audio - @mikethompson',
      likes: 45200,
      comments: 1230,
      shares: 890,
      isLiked: false,
      isSaved: false
    },
    {
      id: 'r2',
      user: users[5],
      video: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681347_8aa2cbbc.png',
      thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681347_8aa2cbbc.png',
      caption: 'New beat drop! What do you think? #music #producer #beats',
      music: 'New Track Preview - @davidpark',
      likes: 89500,
      comments: 3450,
      shares: 2100,
      isLiked: true,
      isSaved: false
    },
    {
      id: 'r3',
      user: users[2],
      video: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298743451_fdf3e0a7.png',
      thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298743451_fdf3e0a7.png',
      caption: 'Golden hour magic #photography #sunset #nature',
      music: 'Sunset Vibes - Chill Mix',
      likes: 67800,
      comments: 2100,
      shares: 1500,
      isLiked: false,
      isSaved: true
    },
    {
      id: 'r4',
      user: users[6],
      video: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681505_56062067.png',
      thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298681505_56062067.png',
      caption: 'Fashion week highlights! #fashion #style #runway',
      music: 'Runway Music - Fashion Week',
      likes: 123000,
      comments: 5600,
      shares: 3200,
      isLiked: false,
      isSaved: false
    },
    {
      id: 'r5',
      user: users[4],
      video: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298672761_8e473f6e.jpg',
      thumbnail: 'https://d64gsuwffb70l.cloudfront.net/6938513f5e699aa38bd90114_1765298672761_8e473f6e.jpg',
      caption: 'Recipe of the day: Perfect brunch! #food #cooking #recipe',
      music: 'Cooking Time - Kitchen Beats',
      likes: 34500,
      comments: 890,
      shares: 670,
      isLiked: false,
      isSaved: false
    }
  ]);

  const currentReel = reels[currentReelIndex];

  const formatNumber = (num: number): string => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const handleLike = () => {
    setReels(reels.map((reel, idx) => {
      if (idx === currentReelIndex) {
        return {
          ...reel,
          isLiked: !reel.isLiked,
          likes: reel.isLiked ? reel.likes - 1 : reel.likes + 1
        };
      }
      return reel;
    }));
  };

  const handleSave = () => {
    setReels(reels.map((reel, idx) => {
      if (idx === currentReelIndex) {
        return { ...reel, isSaved: !reel.isSaved };
      }
      return reel;
    }));
  };

  const handleShare = () => {
    setReels(reels.map((reel, idx) => {
      if (idx === currentReelIndex) {
        return { ...reel, shares: reel.shares + 1 };
      }
      return reel;
    }));
    
    navigator.clipboard.writeText(`https://socialite.app/reels/${currentReel.id}`);
    alert('Link copied to clipboard!');
  };

  const goToNextReel = () => {
    if (currentReelIndex < reels.length - 1) {
      setCurrentReelIndex(currentReelIndex + 1);
    }
  };

  const goToPrevReel = () => {
    if (currentReelIndex > 0) {
      setCurrentReelIndex(currentReelIndex - 1);
    }
  };

  // Handle tap on screen - top half goes previous, bottom half goes next
  const handleScreenTap = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const tapY = e.clientY - rect.top;
    const screenHeight = rect.height;
    
    // Ignore if tapping on action buttons area (right side)
    const tapX = e.clientX - rect.left;
    if (tapX > rect.width - 80) return;
    
    if (tapY < screenHeight / 2) {
      goToPrevReel();
    } else {
      goToNextReel();
    }
  };

  // Touch handlers for swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndY.current = e.touches[0].clientY;
  };

  const handleTouchEnd = () => {
    const diff = touchStartY.current - touchEndY.current;
    const threshold = 50;
    
    if (diff > threshold) {
      goToNextReel();
    } else if (diff < -threshold) {
      goToPrevReel();
    }
  };

  // Mouse wheel scroll
  const handleScroll = (e: React.WheelEvent) => {
    if (e.deltaY > 0) {
      goToNextReel();
    } else {
      goToPrevReel();
    }
  };

  const handleComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (commentText.trim()) {
      setReels(reels.map((reel, idx) => {
        if (idx === currentReelIndex) {
          return { ...reel, comments: reel.comments + 1 };
        }
        return reel;
      }));
      setCommentText('');
    }
  };

  // Video file selection
  const handleVideoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 100 * 1024 * 1024) {
        alert('Video file size must be less than 100MB');
        return;
      }
      
      const videoUrl = URL.createObjectURL(file);
      setUploadForm(prev => ({
        ...prev,
        videoFile: file,
        videoPreview: videoUrl
      }));
      setUploadStep(2);
    }
  };

  // Thumbnail file selection
  const handleThumbnailSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      setUploadForm(prev => ({
        ...prev,
        thumbnailFile: file,
        thumbnailPreview: imageUrl
      }));
    }
  };

  // Extract hashtags from caption
  const extractHashtags = (text: string) => {
    const hashtags = text.match(/#\w+/g) || [];
    return hashtags.map(tag => tag.slice(1));
  };

  // Upload reel
  const handleUploadReel = async () => {
    if (!uploadForm.videoFile) {
      alert('Please select a video file');
      return;
    }

    if (!isAuthenticated) {
      alert('Please login to upload reels');
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Not authenticated');

      setUploadProgress(20);
      const videoFileName = `${Date.now()}_${uploadForm.videoFile.name}`;
      const { data: videoData, error: videoError } = await supabase.storage
        .from('media')
        .upload(`reels/${session.user.id}/${videoFileName}`, uploadForm.videoFile, {
          cacheControl: '3600',
          upsert: false
        });

      if (videoError) throw videoError;
      setUploadProgress(50);

      const { data: { publicUrl: videoUrl } } = supabase.storage
        .from('media')
        .getPublicUrl(`reels/${session.user.id}/${videoFileName}`);

      let thumbnailUrl = videoUrl;
      if (uploadForm.thumbnailFile) {
        const thumbFileName = `${Date.now()}_thumb_${uploadForm.thumbnailFile.name}`;
        const { data: thumbData, error: thumbError } = await supabase.storage
          .from('media')
          .upload(`reels/${session.user.id}/${thumbFileName}`, uploadForm.thumbnailFile, {
            cacheControl: '3600',
            upsert: false
          });

        if (!thumbError) {
          const { data: { publicUrl } } = supabase.storage
            .from('media')
            .getPublicUrl(`reels/${session.user.id}/${thumbFileName}`);
          thumbnailUrl = publicUrl;
        }
      }
      setUploadProgress(70);

      const { data, error } = await supabase.functions.invoke('media-service', {
        body: {
          action: 'create_reel',
          video_url: videoUrl,
          thumbnail_url: thumbnailUrl,
          caption: uploadForm.caption,
          music: uploadForm.music || 'Original Audio'
        }
      });

      if (error) throw error;
      setUploadProgress(100);

      const newReel: Reel = {
        id: data.reel.id,
        user: {
          id: profile?.user_id || '',
          name: profile?.full_name || 'You',
          username: profile?.username || 'user',
          avatar: profile?.avatar_url || currentUser.avatar,
          isVerified: profile?.is_verified
        },
        video: videoUrl,
        thumbnail: thumbnailUrl,
        caption: uploadForm.caption,
        music: uploadForm.music || 'Original Audio',
        likes: 0,
        comments: 0,
        shares: 0,
        isLiked: false,
        isSaved: false
      };

      setReels([newReel, ...reels]);
      setCurrentReelIndex(0);
      
      resetUploadForm();
      alert('Reel uploaded successfully!');

    } catch (error: any) {
      console.error('Upload error:', error);
      alert('Failed to upload reel: ' + error.message);
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const resetUploadForm = () => {
    setUploadForm({
      videoFile: null,
      thumbnailFile: null,
      caption: '',
      music: 'Original Audio',
      videoPreview: '',
      thumbnailPreview: '',
      hashtags: [],
      mentions: []
    });
    setUploadStep(1);
    setShowUploadModal(false);
  };

  // Modern Upload Modal
  const UploadModal = () => (
    <div className="fixed inset-0 bg-black z-50 flex items-center justify-center">
      <div className="w-full h-full md:w-[900px] md:h-[600px] md:rounded-2xl bg-gradient-to-br from-gray-900 via-purple-900/20 to-gray-900 flex overflow-hidden">
        
        {/* Left Side - Video Preview */}
        <div className="hidden md:flex w-[350px] bg-black/50 items-center justify-center p-6 border-r border-white/10">
          {uploadForm.videoPreview ? (
            <div className="relative w-full aspect-[9/16] bg-black rounded-2xl overflow-hidden shadow-2xl ring-2 ring-white/20">
              <video 
                src={uploadForm.videoPreview}
                className="w-full h-full object-cover"
                autoPlay
                loop
                muted
              />
              <div className="absolute bottom-4 left-4 right-4">
                <div className="flex items-center gap-2 text-white text-sm">
                  <Music2 className="w-4 h-4" />
                  <span className="truncate">{uploadForm.music || 'Original Audio'}</span>
                </div>
                {uploadForm.caption && (
                  <p className="text-white text-sm mt-2 line-clamp-2">{uploadForm.caption}</p>
                )}
              </div>
            </div>
          ) : (
            <div className="w-full aspect-[9/16] bg-gray-800/50 rounded-2xl border-2 border-dashed border-gray-600 flex flex-col items-center justify-center">
              <Film className="w-16 h-16 text-gray-500 mb-4" />
              <p className="text-gray-400 text-center">Video preview<br/>will appear here</p>
            </div>
          )}
        </div>

        {/* Right Side - Upload Form */}
        <div className="flex-1 flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-white/10">
            <button 
              onClick={resetUploadForm}
              className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
            >
              <X className="w-5 h-5 text-white" />
            </button>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1">
                {[1, 2, 3].map((step) => (
                  <div 
                    key={step}
                    className={`w-8 h-1 rounded-full transition-colors ${
                      uploadStep >= step ? 'bg-gradient-to-r from-purple-500 to-pink-500' : 'bg-white/20'
                    }`}
                  />
                ))}
              </div>
            </div>
            <div className="w-10" />
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-6">
            {uploadStep === 1 && (
              <div className="h-full flex flex-col items-center justify-center">
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full max-w-md aspect-video bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-2xl border-2 border-dashed border-purple-500/50 flex flex-col items-center justify-center cursor-pointer hover:border-purple-400 hover:bg-purple-500/30 transition-all group"
                >
                  <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <Upload className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-2">Select video to upload</h3>
                  <p className="text-gray-400 text-sm text-center">
                    Or drag and drop a file<br/>
                    MP4 or WebM • 720x1280 or higher • Up to 60 seconds
                  </p>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="video/*"
                  onChange={handleVideoSelect}
                  className="hidden"
                />
                
                <div className="flex items-center gap-4 mt-8">
                  <button className="flex items-center gap-2 px-6 py-3 bg-white/10 rounded-full text-white hover:bg-white/20 transition-colors">
                    <Camera className="w-5 h-5" />
                    Record
                  </button>
                  <button className="flex items-center gap-2 px-6 py-3 bg-white/10 rounded-full text-white hover:bg-white/20 transition-colors">
                    <Wand2 className="w-5 h-5" />
                    Use Template
                  </button>
                </div>
              </div>
            )}

            {uploadStep === 2 && (
              <div className="space-y-6">
                {/* Mobile Video Preview */}
                <div className="md:hidden">
                  {uploadForm.videoPreview && (
                    <div className="relative aspect-video bg-black rounded-xl overflow-hidden mb-4">
                      <video 
                        src={uploadForm.videoPreview}
                        className="w-full h-full object-cover"
                        controls
                      />
                      <button 
                        onClick={() => {
                          setUploadForm(prev => ({ ...prev, videoFile: null, videoPreview: '' }));
                          setUploadStep(1);
                        }}
                        className="absolute top-2 right-2 p-2 bg-black/50 rounded-full text-white"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>

                {/* Caption */}
                <div>
                  <label className="flex items-center gap-2 text-white font-medium mb-3">
                    <span className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center text-sm">1</span>
                    Caption
                  </label>
                  <div className="relative">
                    <textarea
                      value={uploadForm.caption}
                      onChange={(e) => setUploadForm(prev => ({ ...prev, caption: e.target.value }))}
                      placeholder="Write an engaging caption... Use #hashtags and @mentions"
                      rows={4}
                      className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
                    />
                    <div className="absolute bottom-3 right-3 flex items-center gap-2">
                      <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
                        <Hash className="w-5 h-5 text-gray-400" />
                      </button>
                      <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
                        <AtSign className="w-5 h-5 text-gray-400" />
                      </button>
                    </div>
                  </div>
                  <p className="text-gray-400 text-sm mt-2">{uploadForm.caption.length}/2200</p>
                </div>

                {/* Cover Photo */}
                <div>
                  <label className="flex items-center gap-2 text-white font-medium mb-3">
                    <span className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center text-sm">2</span>
                    Cover Photo
                  </label>
                  <div className="flex items-center gap-4">
                    {uploadForm.thumbnailPreview ? (
                      <div className="relative w-24 h-24 rounded-xl overflow-hidden">
                        <img 
                          src={uploadForm.thumbnailPreview}
                          alt="Thumbnail"
                          className="w-full h-full object-cover"
                        />
                        <button 
                          onClick={() => setUploadForm(prev => ({ ...prev, thumbnailFile: null, thumbnailPreview: '' }))}
                          className="absolute top-1 right-1 p-1 bg-black/50 rounded-full text-white"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ) : (
                      <label className="w-24 h-24 bg-white/10 border border-white/20 rounded-xl flex flex-col items-center justify-center cursor-pointer hover:bg-white/20 transition-colors">
                        <Camera className="w-6 h-6 text-gray-400 mb-1" />
                        <span className="text-xs text-gray-400">Add cover</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleThumbnailSelect}
                          className="hidden"
                        />
                      </label>
                    )}
                    <p className="text-gray-400 text-sm flex-1">
                      Choose a cover image that represents your reel. This will be shown in your profile grid.
                    </p>
                  </div>
                </div>

                {/* Music */}
                <div>
                  <label className="flex items-center gap-2 text-white font-medium mb-3">
                    <span className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center text-sm">3</span>
                    Add Music
                  </label>
                  <div className="flex items-center gap-3 p-4 bg-white/10 border border-white/20 rounded-xl">
                    <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                      <Music2 className="w-6 h-6 text-white" />
                    </div>
                    <input
                      type="text"
                      value={uploadForm.music}
                      onChange={(e) => setUploadForm(prev => ({ ...prev, music: e.target.value }))}
                      placeholder="Search for music..."
                      className="flex-1 bg-transparent text-white placeholder-gray-400 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Upload Progress */}
                {isUploading && (
                  <div className="space-y-3 p-4 bg-white/10 rounded-xl">
                    <div className="flex items-center justify-between">
                      <span className="text-white font-medium">Uploading your reel...</span>
                      <span className="text-purple-400 font-bold">{uploadProgress}%</span>
                    </div>
                    <div className="h-2 bg-white/20 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-300"
                        style={{ width: `${uploadProgress}%` }}
                      />
                    </div>
                    <p className="text-gray-400 text-sm">Please don't close this window</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-white/10">
            <div className="flex items-center gap-3">
              {uploadStep > 1 && (
                <button
                  onClick={() => setUploadStep(uploadStep - 1)}
                  className="px-6 py-3 bg-white/10 text-white rounded-xl font-medium hover:bg-white/20 transition-colors"
                >
                  Back
                </button>
              )}
              <button
                onClick={uploadStep === 2 ? handleUploadReel : () => setUploadStep(uploadStep + 1)}
                disabled={uploadStep === 1 ? !uploadForm.videoFile : isUploading}
                className="flex-1 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl font-semibold hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isUploading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Uploading...
                  </>
                ) : uploadStep === 2 ? (
                  <>
                    <Sparkles className="w-5 h-5" />
                    Post Reel
                  </>
                ) : (
                  'Continue'
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-b from-black/80 to-transparent">
        <div className="flex items-center justify-between px-4 py-3">
          <button 
            onClick={onBack}
            className="w-10 h-10 flex items-center justify-center text-white hover:bg-white/10 rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-bold text-white">Reels</h1>
          <button 
            onClick={() => setShowUploadModal(true)}
            className="w-10 h-10 flex items-center justify-center text-white hover:bg-white/10 rounded-full transition-colors"
          >
            <Plus className="w-6 h-6" />
          </button>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-4 px-4 pb-3 overflow-x-auto scrollbar-hide">
          {['For You', 'Following', 'Trending', 'Music', 'Comedy', 'Sports'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                activeTab === tab 
                  ? 'bg-white text-black' 
                  : 'bg-white/20 text-white hover:bg-white/30'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Reels Container - Tap to navigate */}
      <div 
        ref={containerRef}
        className="h-screen snap-y snap-mandatory overflow-hidden scrollbar-hide cursor-pointer select-none"
        onClick={handleScreenTap}
        onWheel={handleScroll}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {reels.map((reel, idx) => (
          <div 
            key={reel.id}
            className={`h-screen snap-start relative flex items-center justify-center ${
              idx === currentReelIndex ? 'block' : 'hidden'
            }`}
          >
            {/* Video/Image Background */}
            <div 
              className="absolute inset-0 bg-cover bg-center"
              style={{ backgroundImage: `url(${reel.thumbnail})` }}
            >
              <div className="absolute inset-0 bg-black/30" />
            </div>

            {/* Play/Pause Overlay */}
            <button 
              onClick={(e) => {
                e.stopPropagation();
                setIsPlaying(!isPlaying);
              }}
              className="absolute inset-0 flex items-center justify-center z-10"
            >
              {!isPlaying && (
                <div className="w-20 h-20 bg-black/50 rounded-full flex items-center justify-center">
                  <Play className="w-10 h-10 text-white ml-1" />
                </div>
              )}
            </button>

            {/* Right Actions */}
            <div className="absolute right-4 bottom-32 flex flex-col items-center gap-6 z-20">
              {/* User Avatar */}
              <div className="relative">
                <img 
                  src={reel.user.avatar}
                  alt={reel.user.name}
                  className="w-12 h-12 rounded-full border-2 border-white object-cover"
                />
                <button 
                  onClick={(e) => e.stopPropagation()}
                  className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center"
                >
                  <Plus className="w-4 h-4 text-white" />
                </button>
              </div>

              {/* Like */}
              <button onClick={(e) => { e.stopPropagation(); handleLike(); }} className="flex flex-col items-center gap-1">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                  reel.isLiked ? 'bg-red-500' : 'bg-white/20'
                }`}>
                  <Heart className={`w-6 h-6 ${reel.isLiked ? 'text-white fill-white' : 'text-white'}`} />
                </div>
                <span className="text-white text-xs font-medium">{formatNumber(reel.likes)}</span>
              </button>

              {/* Comment */}
              <button onClick={(e) => { e.stopPropagation(); setShowComments(true); }} className="flex flex-col items-center gap-1">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                  <MessageCircle className="w-6 h-6 text-white" />
                </div>
                <span className="text-white text-xs font-medium">{formatNumber(reel.comments)}</span>
              </button>

              {/* Share */}
              <button onClick={(e) => { e.stopPropagation(); handleShare(); }} className="flex flex-col items-center gap-1">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                  <Share2 className="w-6 h-6 text-white" />
                </div>
                <span className="text-white text-xs font-medium">{formatNumber(reel.shares)}</span>
              </button>

              {/* Save */}
              <button onClick={(e) => { e.stopPropagation(); handleSave(); }} className="flex flex-col items-center gap-1">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                  reel.isSaved ? 'bg-yellow-500' : 'bg-white/20'
                }`}>
                  <Bookmark className={`w-6 h-6 ${reel.isSaved ? 'text-white fill-white' : 'text-white'}`} />
                </div>
              </button>

              {/* More */}
              <button onClick={(e) => e.stopPropagation()} className="flex flex-col items-center gap-1">
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                  <MoreHorizontal className="w-6 h-6 text-white" />
                </div>
              </button>

              {/* Music Disc */}
              <div className="w-10 h-10 rounded-full border-2 border-white overflow-hidden animate-spin-slow">
                <img 
                  src={reel.user.avatar}
                  alt="Music"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {/* Bottom Info */}
            <div className="absolute left-4 right-20 bottom-8 z-20">
              {/* User Info */}
              <div className="flex items-center gap-3 mb-3">
                <span className="font-bold text-white">{reel.user.name}</span>
                {reel.user.isVerified && (
                  <svg className="w-4 h-4 text-blue-400" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/>
                  </svg>
                )}
                <button 
                  onClick={(e) => e.stopPropagation()}
                  className="px-3 py-1 border border-white text-white text-sm rounded-md hover:bg-white/10 transition-colors"
                >
                  Follow
                </button>
              </div>

              {/* Caption */}
              <p className="text-white text-sm mb-3 line-clamp-2">{reel.caption}</p>

              {/* Music */}
              <div className="flex items-center gap-2 text-white text-sm">
                <Music2 className="w-4 h-4" />
                <span className="truncate">{reel.music}</span>
              </div>
            </div>

            {/* Tap hint indicator */}
            <div className="absolute left-4 top-1/2 -translate-y-1/2 flex flex-col items-center gap-2 opacity-30 pointer-events-none">
              <div className="text-white text-xs">Tap top</div>
              <div className="w-px h-8 bg-white/50" />
              <div className="text-white text-xs">Tap bottom</div>
            </div>

            {/* Mute Button */}
            <button 
              onClick={(e) => { e.stopPropagation(); setIsMuted(!isMuted); }}
              className="absolute top-24 right-4 w-10 h-10 bg-white/20 rounded-full flex items-center justify-center z-20"
            >
              {isMuted ? (
                <VolumeX className="w-5 h-5 text-white" />
              ) : (
                <Volume2 className="w-5 h-5 text-white" />
              )}
            </button>

            {/* Progress Indicator */}
            <div className="absolute top-20 left-4 right-4 flex gap-1 z-20">
              {reels.map((_, i) => (
                <div 
                  key={i}
                  className={`h-1 flex-1 rounded-full ${
                    i === currentReelIndex ? 'bg-white' : 'bg-white/30'
                  }`}
                />
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Comments Modal */}
      {showComments && (
        <div className="fixed inset-0 z-50 flex items-end" onClick={() => setShowComments(false)}>
          <div className="absolute inset-0 bg-black/50" />
          <div 
            className="relative w-full bg-white rounded-t-3xl max-h-[70vh] flex flex-col animate-slideUp"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="font-bold text-lg">Comments ({formatNumber(currentReel.comments)})</h3>
              <button 
                onClick={() => setShowComments(false)}
                className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center"
              >
                <X className="w-4 h-4 text-gray-500" />
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {[
                { user: users[1], text: 'This is amazing!', likes: 234, time: '2h' },
                { user: users[3], text: 'Love this content!', likes: 89, time: '3h' },
                { user: users[5], text: 'Keep it up!', likes: 156, time: '5h' },
                { user: users[7], text: 'Incredible work!', likes: 45, time: '6h' },
                { user: users[9], text: 'This made my day!', likes: 78, time: '8h' }
              ].map((comment, idx) => (
                <div key={idx} className="flex gap-3">
                  <img 
                    src={comment.user.avatar}
                    alt={comment.user.name}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm">{comment.user.name}</span>
                      <span className="text-xs text-gray-500">{comment.time}</span>
                    </div>
                    <p className="text-sm text-gray-800 mt-1">{comment.text}</p>
                    <div className="flex items-center gap-4 mt-2">
                      <button className="flex items-center gap-1 text-xs text-gray-500">
                        <ThumbsUp className="w-3 h-3" />
                        {comment.likes}
                      </button>
                      <button className="text-xs text-gray-500">Reply</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Comment Input */}
            <form onSubmit={handleComment} className="p-4 border-t flex items-center gap-3">
              <img 
                src={profile?.avatar_url || currentUser.avatar}
                alt="You"
                className="w-10 h-10 rounded-full object-cover"
              />
              <input
                type="text"
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="Add a comment..."
                className="flex-1 px-4 py-2 bg-gray-100 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button 
                type="submit"
                disabled={!commentText.trim()}
                className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white disabled:opacity-50"
              >
                <Send className="w-5 h-5" />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Upload Modal */}
      {showUploadModal && <UploadModal />}

      {/* Custom Styles */}
      <style>{`
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-spin-slow {
          animation: spin-slow 3s linear infinite;
        }
        @keyframes slideUp {
          from { transform: translateY(100%); }
          to { transform: translateY(0); }
        }
        .animate-slideUp {
          animation: slideUp 0.3s ease-out;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
};

export default ReelsPage;
